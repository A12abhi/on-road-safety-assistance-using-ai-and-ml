import React, { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check localStorage on mount
    const storedUser = localStorage.getItem("currentUser");
    const storedIsAdmin = localStorage.getItem("isAdmin");

    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    if (storedIsAdmin === "true") {
      setIsAdmin(true);
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    // Admin Hardcoded Check
    if (email === "admin@onroad.com" && password === "Admin@123") {
      const adminUser = { name: "Admin User", email };
      setCurrentUser(adminUser);
      setIsAdmin(true);
      localStorage.setItem("currentUser", JSON.stringify(adminUser));
      localStorage.setItem("isAdmin", "true");
      return { success: true, isAdmin: true };
    }

    // Regular User Check from LocalStorage
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find((u) => u.email === email && u.password === password);

    if (user) {
      setCurrentUser(user);
      setIsAdmin(false);
      localStorage.setItem("currentUser", JSON.stringify(user));
      localStorage.setItem("isAdmin", "false");
      return { success: true, isAdmin: false };
    }

    return { success: false, message: "Invalid email or password" };
  };

  const signup = (userData) => {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    // Check if email exists
    if (users.some((u) => u.email === userData.email)) {
      return { success: false, message: "Email already registered" };
    }
    const newUser = {
      ...userData,
      userId: Date.now().toString(),
      registeredAt: new Date().toISOString(),
      activity: []
    };
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));
    return { success: true };
  };

  const addUserActivity = (userId, activity) => {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const userIndex = users.findIndex(u => u.userId === userId || u.email === currentUser?.email);
    if (userIndex !== -1) {
      if (!users[userIndex].activity) {
        users[userIndex].activity = [];
      }
      users[userIndex].activity.push({
        type: activity.type,
        description: activity.description,
        timestamp: new Date().toISOString()
      });
      localStorage.setItem("users", JSON.stringify(users));
    }
  };

  const trackConversation = (email, messages) => {
    const conversations = JSON.parse(localStorage.getItem("userConversations") || "{}");
    if (!conversations[email]) {
      conversations[email] = [];
    }
    conversations[email].push({
      timestamp: new Date().toISOString(),
      messages: messages,
      messageCount: messages.length
    });
    localStorage.setItem("userConversations", JSON.stringify(conversations));
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAdmin(false);
    localStorage.removeItem("currentUser");
    localStorage.removeItem("isAdmin");
  };

  const value = {
    currentUser,
    isAdmin,
    login,
    signup,
    logout,
    addUserActivity,
    trackConversation,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
