import React from 'react';
import { cn } from '@/lib/utils';
import { Bot, User } from 'lucide-react';

export default function ChatBubble({ message, isBot }) {
  return (
    <div className={cn("flex w-full gap-3", isBot ? "justify-start" : "justify-end")}>
      {isBot && (
        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
          <Bot className="w-5 h-5 text-primary" />
        </div>
      )}
      
      <div className={cn(
        "max-w-[80%] rounded-2xl px-4 py-3 text-sm shadow-sm",
        isBot 
          ? "bg-card border border-white/10 text-gray-200 rounded-tl-none" 
          : "bg-primary text-white rounded-tr-none"
      )}>
        {message}
      </div>

      {!isBot && (
        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center shrink-0">
          <User className="w-5 h-5 text-white" />
        </div>
      )}
    </div>
  );
}
