import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, MapPin, Wrench } from 'lucide-react';

export default function MechanicCard({ mechanic, onConnect }) {
  return (
    <Card className="glass-card border-white/5 hover:border-primary/30 transition-all hover:-translate-y-1">
      <CardContent className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-bold text-white">{mechanic.name}</h3>
            <div className="flex items-center text-sm text-gray-400 mt-1">
              <MapPin className="w-3 h-3 mr-1" /> {mechanic.distance} km away
            </div>
          </div>
          <div className="flex items-center bg-yellow-500/20 px-2 py-1 rounded text-yellow-400 text-xs font-bold">
            <Star className="w-3 h-3 mr-1 fill-yellow-400" /> {mechanic.rating}
          </div>
        </div>

        <div className="mb-4">
          <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">Specialization</div>
          <div className="flex flex-wrap gap-2">
            {mechanic.specialization.map((spec, i) => (
              <span key={i} className="text-xs bg-white/5 text-gray-300 px-2 py-1 rounded border border-white/5">
                {spec}
              </span>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
          <div className={`text-xs font-medium ${mechanic.available ? 'text-green-400' : 'text-red-400'}`}>
            {mechanic.available ? '● Available Now' : '● Busy'}
          </div>
          <Button 
            size="sm" 
            className="bg-primary hover:bg-blue-600" 
            onClick={() => onConnect(mechanic)}
            disabled={!mechanic.available}
          >
            {mechanic.available ? 'Connect' : 'Busy'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
