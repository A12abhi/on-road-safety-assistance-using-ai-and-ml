import React from 'react';
import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-card border-t border-white/10 py-8 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-display font-bold text-white mb-4">ON<span className="text-primary">ROAD</span></h3>
            <p className="text-gray-400 text-sm">
              AI-Powered Smart Emergency Assistance System. 
              Providing reliable breakdown support, fuel assistance, and vehicle health monitoring 24/7.
            </p>
          </div>
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-primary transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Services</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Contact</a></li>
              <li><a href="/admin/login" className="hover:text-primary transition-colors">Admin Access</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Emergency Contact</h4>
            <p className="text-gray-400 text-sm mb-2">Toll Free: 1800-ON-ROAD</p>
            <p className="text-gray-400 text-sm">Email: help@onroad.com</p>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-white/5 text-center text-sm text-gray-500 flex items-center justify-center gap-1">
          © {new Date().getFullYear()} OnRoad. Made with <Heart className="w-4 h-4 text-red-500 fill-red-500" /> for safe journeys.
        </div>
      </div>
    </footer>
  );
}
