import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from "@/components/ui/toaster";

// Components
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProtectedRoute from "@/components/ProtectedRoute";
import AdminProtectedRoute from "@/components/AdminProtectedRoute";
import NotFound from "@/pages/not-found";

// Pages
import LandingPage from "@/pages/LandingPage";
import LoginPage from "@/pages/LoginPage";
import SignupPage from "@/pages/SignupPage";
import ForgotPassword from "@/pages/ForgotPassword";
import Dashboard from "@/pages/Dashboard";

// Modules
import EmergencyRequest from "@/pages/EmergencyRequest";
import AIChatbot from "@/pages/AIChatbot";
import MapView from "@/pages/MapView";
import MechanicFinder from "@/pages/MechanicFinder";
import VehicleHealthAI from "@/pages/VehicleHealthAI";
import SmartMaintenanceAI from "@/pages/SmartMaintenanceAI";
import HistoryPage from "@/pages/HistoryPage";
import EcoDrivingCoachAI from "@/pages/EcoDrivingCoachAI";
import AccidentEscapeAI from "@/pages/AccidentEscapeAI";
import PanicPredictorAI from "@/pages/PanicPredictorAI";
import AntiRageDrivingMode from "@/pages/AntiRageDrivingMode";
import ReportsPage from "@/pages/ReportsPage";
import FastagPage from "@/pages/FastagPage";
import InsurancePage from "@/pages/InsurancePage";
import EmissionTestingPage from "@/pages/EmissionTestingPage";
import FuelAssistantPage from "@/pages/FuelAssistantPage";

// Admin
import AdminLogin from "@/pages/admin/AdminLogin";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminMechanicPanel from "@/pages/admin/AdminMechanicPanel";

function App() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground font-sans antialiased selection:bg-primary selection:text-primary-foreground">
      <Navbar />
      
      <div className="flex-1">
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/admin/login" element={<AdminLogin />} />

          {/* Protected User Routes */}
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/emergency" element={<ProtectedRoute><EmergencyRequest /></ProtectedRoute>} />
          <Route path="/chatbot" element={<ProtectedRoute><AIChatbot /></ProtectedRoute>} />
          <Route path="/map" element={<ProtectedRoute><MapView /></ProtectedRoute>} />
          <Route path="/mechanics" element={<ProtectedRoute><MechanicFinder /></ProtectedRoute>} />
          <Route path="/health" element={<ProtectedRoute><VehicleHealthAI /></ProtectedRoute>} />
          <Route path="/maintenance-ai" element={<ProtectedRoute><SmartMaintenanceAI /></ProtectedRoute>} />
          <Route path="/history" element={<ProtectedRoute><HistoryPage /></ProtectedRoute>} />
          <Route path="/eco-drive" element={<ProtectedRoute><EcoDrivingCoachAI /></ProtectedRoute>} />
          <Route path="/fastag" element={<ProtectedRoute><FastagPage /></ProtectedRoute>} />
          <Route path="/insurance" element={<ProtectedRoute><InsurancePage /></ProtectedRoute>} />
          <Route path="/emission" element={<ProtectedRoute><EmissionTestingPage /></ProtectedRoute>} />
          <Route path="/fuel" element={<ProtectedRoute><FuelAssistantPage /></ProtectedRoute>} />
          <Route path="/escape-ai" element={<ProtectedRoute><AccidentEscapeAI /></ProtectedRoute>} />
          <Route path="/panic-predictor" element={<ProtectedRoute><PanicPredictorAI /></ProtectedRoute>} />
          <Route path="/anti-rage" element={<ProtectedRoute><AntiRageDrivingMode /></ProtectedRoute>} />
          <Route path="/reports" element={<ProtectedRoute><ReportsPage /></ProtectedRoute>} />

          {/* Protected Admin Routes */}
          <Route path="/admin/dashboard" element={<AdminProtectedRoute><AdminDashboard /></AdminProtectedRoute>} />
          <Route path="/admin/mechanics" element={<AdminProtectedRoute><AdminMechanicPanel /></AdminProtectedRoute>} />

          {/* 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>

      <Footer />
      <Toaster />
    </div>
  );
}

export default App;
