import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldAlert, AlertTriangle, Clock } from 'lucide-react';

export default function RiskRouteMap() {
  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-5xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-display font-bold text-white">High Risk Route Map</h1>
        <p className="text-gray-400">AI-Predicted dangerous zones based on accident history & time.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Risk List */}
        <div className="md:col-span-1 space-y-4">
          <Card className="bg-red-900/10 border-red-500/30">
            <CardHeader>
              <CardTitle className="text-red-400 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5" /> High Risk Zones
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { name: "NH-44 Night Stretch", reason: "Poor Lighting, Wildlife", time: "10 PM - 4 AM" },
                { name: "Ghat Section Curve 7", reason: "Landslide Prone", time: "Monsoon" },
                { name: "Old City Bypass", reason: "High Crime Rate", time: "Post Midnight" }
              ].map((zone, i) => (
                <div key={i} className="p-3 rounded bg-red-500/10 border border-red-500/10">
                  <h4 className="font-bold text-red-300">{zone.name}</h4>
                  <p className="text-xs text-red-200/70 mt-1">{zone.reason}</p>
                  <div className="flex items-center gap-1 mt-2 text-xs text-red-400">
                    <Clock className="w-3 h-3" /> {zone.time}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-yellow-900/10 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-yellow-400 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" /> Moderate Risk
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-3 rounded bg-yellow-500/10 border border-yellow-500/10">
                <h4 className="font-bold text-yellow-300">City Ring Road</h4>
                <p className="text-xs text-yellow-200/70 mt-1">Construction Work Ongoing</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Visual Map Placeholder */}
        <div className="md:col-span-2">
          <Card className="h-full min-h-[500px] glass-card border-white/10 relative overflow-hidden group">
            <div className="absolute inset-0 bg-[url('https://assets.website-files.com/63a9fb94e473f36dbe99c1b1/63a9fb94e473f3b57e99c232_map-dark.jpg')] bg-cover bg-center opacity-50 grayscale group-hover:grayscale-0 transition-all duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
            
            {/* Simulated Risk Overlays */}
            <div className="absolute top-1/4 left-1/3 w-32 h-32 bg-red-500/30 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-1/3 right-1/4 w-24 h-24 bg-yellow-500/30 rounded-full blur-2xl" />

            <div className="relative z-10 p-6 h-full flex flex-col justify-end">
              <h3 className="text-2xl font-bold text-white">Live Risk Heatmap</h3>
              <p className="text-gray-300">Data updated every 15 minutes from police & user reports.</p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
