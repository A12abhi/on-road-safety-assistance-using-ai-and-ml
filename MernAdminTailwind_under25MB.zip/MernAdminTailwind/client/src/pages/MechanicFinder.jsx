import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import MechanicCard from '@/components/MechanicCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const DUMMY_MECHANICS = [
  { id: 1, name: "Quick Fix Garage", distance: 1.2, rating: 4.5, specialization: ["Engine", "Tyre"], available: true },
  { id: 2, name: "Auto Care Pro", distance: 2.5, rating: 4.8, specialization: ["Battery", "Electric"], available: true },
  { id: 3, name: "Roadside Heroes", distance: 0.8, rating: 4.2, specialization: ["Towing", "Fuel"], available: false },
  { id: 4, name: "City Motors", distance: 3.5, rating: 4.6, specialization: ["General", "AC"], available: true },
  { id: 5, name: "Bike Expertz", distance: 1.8, rating: 4.9, specialization: ["Bike", "Engine"], available: true },
];

export default function MechanicFinder() {
  const [searchParams] = useSearchParams();
  const aiIssue = searchParams.get('issue');
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [mechanics, setMechanics] = useState(DUMMY_MECHANICS);

  const handleConnect = (mechanic) => {
    // Update emergency request with assigned mechanic
    const requests = JSON.parse(localStorage.getItem('emergencyRequests') || '[]');
    if (requests.length > 0) {
      // Update the latest request
      requests[requests.length - 1].assignedMechanic = mechanic.name;
      requests[requests.length - 1].status = 'Mechanic Assigned';
      localStorage.setItem('emergencyRequests', JSON.stringify(requests));
    }

    toast({
      title: "Mechanic Connected!",
      description: `${mechanic.name} has been assigned to your request.`,
    });
  };

  const filteredMechanics = mechanics.filter(m => 
    m.name.toLowerCase().includes(search.toLowerCase()) || 
    m.specialization.some(s => s.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Find Mechanics</h1>
          <p className="text-gray-400">Locate trusted professionals nearby.</p>
          {aiIssue && (
            <div className="mt-2 bg-blue-500/10 text-blue-400 px-3 py-1 rounded text-sm border border-blue-500/20 inline-flex items-center">
              Diagnosis from AI: {aiIssue}
            </div>
          )}
        </div>
        
        <div className="flex gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input 
              placeholder="Search mechanics..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-white/5 border-white/10 text-white"
            />
          </div>
          <Button className="bg-white/10 hover:bg-white/20">
            <MapPin className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMechanics.map(mechanic => (
          <MechanicCard key={mechanic.id} mechanic={mechanic} onConnect={handleConnect} />
        ))}
      </div>
    </div>
  );
}
