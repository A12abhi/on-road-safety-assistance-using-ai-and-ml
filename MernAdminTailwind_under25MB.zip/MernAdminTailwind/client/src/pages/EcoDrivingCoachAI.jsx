import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Zap, TrendingDown, Leaf, AlertCircle, Activity, BarChart3, Award, CheckCircle2, Gauge } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function EcoDrivingCoachAI() {
  const { toast } = useToast();
  const [session, setSession] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [drivingData, setDrivingData] = useState({
    distance: '',
    avgSpeed: '',
    brakingSessions: '',
    accelerationEvents: '',
    idleTime: ''
  });

  const handleStartSession = () => {
    setSession({
      active: true,
      time: '12:34 PM',
      distance: 0,
      avgSpeed: 0,
      realTimeStats: {
        currentSpeed: 0,
        efficiency: '87%',
        fuelConsumption: '0 L/100km'
      }
    });
    
    toast({
      title: "Eco-Driving Session Started",
      description: "AI Coach is monitoring your driving. Drive safely!"
    });

    // Simulate real-time data updates
    const interval = setInterval(() => {
      setSession(prev => {
        if (!prev.active) {
          clearInterval(interval);
          return prev;
        }
        const newSpeed = Math.floor(Math.random() * 120) + 20;
        const efficiency = Math.floor(Math.random() * 30) + 65;
        return {
          ...prev,
          realTimeStats: {
            currentSpeed: newSpeed,
            efficiency: efficiency + '%',
            fuelConsumption: (Math.random() * 8 + 5).toFixed(1) + ' L/100km'
          }
        };
      });
    }, 1500);
  };

  const handleEndSession = () => {
    setAnalyzing(true);
    setTimeout(() => {
      const avgSpeed = Math.floor(Math.random() * 80) + 40;
      const brakingSessions = Math.floor(Math.random() * 20) + 5;
      const acceleration = Math.floor(Math.random() * 15) + 3;
      const idleMinutes = Math.floor(Math.random() * 10) + 2;
      const efficiencyScore = Math.max(50, 100 - (brakingSessions * 2 + acceleration * 1.5 + idleMinutes * 0.5));
      
      setSession({
        active: false,
        completed: true,
        duration: '45 min 23 sec',
        distance: 28.5,
        avgSpeed: avgSpeed,
        brakingSessions: brakingSessions,
        acceleration: acceleration,
        idleTime: idleMinutes,
        metrics: {
          fuelSaved: (28.5 * (120 - efficiencyScore) / 100).toFixed(1),
          co2Saved: ((28.5 * 2.3) * (120 - efficiencyScore) / 100).toFixed(1),
          costSaved: ((28.5 * 7.5) * (120 - efficiencyScore) / 100).toFixed(0),
          efficiencyScore: Math.round(efficiencyScore)
        },
        aiCoachFeedback: [
          acceleration > 10 ? '⚠️ Heavy acceleration detected. Smooth acceleration saves 10-15% fuel.' : '✓ Good acceleration pattern',
          brakingSessions > 15 ? '⚠️ Excessive braking. Maintain safe following distance.' : '✓ Smooth braking observed',
          idleMinutes > 5 ? '⚠️ Excessive idling. Turn off engine for stops >30 sec.' : '✓ Minimal idling',
          avgSpeed > 80 ? '⚠️ High average speed reduces efficiency. Optimal: 60-70 km/h.' : '✓ Optimal speed range',
          '💡 Maintain tire pressure at recommended PSI for 3% better fuel efficiency'
        ],
        improvements: [
          { area: 'Acceleration', score: Math.max(20, 100 - acceleration * 3), tips: 'Accelerate gradually' },
          { area: 'Braking', score: Math.max(30, 100 - brakingSessions * 2), tips: 'Plan ahead to avoid sudden braking' },
          { area: 'Speed Management', score: avgSpeed > 80 ? 60 : 85, tips: 'Maintain steady, moderate speed' },
          { area: 'Idle Management', score: Math.max(40, 100 - idleMinutes * 5), tips: 'Minimize engine idling' }
        ]
      });

      toast({
        title: "Session Complete",
        description: `Great driving! You saved ₹${((28.5 * 7.5) * (120 - efficiencyScore) / 100).toFixed(0)}`
      });
      
      setAnalyzing(false);
    }, 2000);
  };

  const handleAnalyzeDriving = (e) => {
    e.preventDefault();
    if (!drivingData.distance || !drivingData.avgSpeed) return;

    setAnalyzing(true);
    setTimeout(() => {
      const distance = parseFloat(drivingData.distance);
      const avgSpeed = parseInt(drivingData.avgSpeed);
      const braking = parseInt(drivingData.brakingSessions);
      const acceleration = parseInt(drivingData.accelerationEvents);
      const idle = parseInt(drivingData.idleTime);

      const efficiencyScore = Math.max(40, 100 - (braking * 2 + acceleration * 1.5 + idle * 0.8 + (avgSpeed > 80 ? 10 : 0)));

      setSession({
        active: false,
        completed: true,
        duration: '45 min 23 sec',
        distance: distance,
        avgSpeed: avgSpeed,
        brakingSessions: braking,
        acceleration: acceleration,
        idleTime: idle,
        metrics: {
          fuelSaved: (distance * (120 - efficiencyScore) / 100).toFixed(1),
          co2Saved: ((distance * 2.3) * (120 - efficiencyScore) / 100).toFixed(1),
          costSaved: ((distance * 7.5) * (120 - efficiencyScore) / 100).toFixed(0),
          efficiencyScore: Math.round(efficiencyScore)
        },
        aiCoachFeedback: [
          acceleration > 10 ? '⚠️ Heavy acceleration detected. Smooth acceleration saves 10-15% fuel.' : '✓ Good acceleration pattern',
          braking > 15 ? '⚠️ Excessive braking. Maintain safe following distance.' : '✓ Smooth braking observed',
          idle > 5 ? '⚠️ Excessive idling. Turn off engine for stops >30 sec.' : '✓ Minimal idling',
          avgSpeed > 80 ? '⚠️ High average speed reduces efficiency. Optimal: 60-70 km/h.' : '✓ Optimal speed range',
          '💡 Regular tire pressure checks improve efficiency by 3%'
        ],
        improvements: [
          { area: 'Acceleration', score: Math.max(20, 100 - acceleration * 3), tips: 'Accelerate gradually' },
          { area: 'Braking', score: Math.max(30, 100 - braking * 2), tips: 'Plan ahead to avoid sudden braking' },
          { area: 'Speed Management', score: avgSpeed > 80 ? 60 : 85, tips: 'Maintain steady, moderate speed' },
          { area: 'Idle Management', score: Math.max(40, 100 - idle * 5), tips: 'Minimize engine idling' }
        ]
      });

      toast({
        title: "Analysis Complete",
        description: `Efficiency Score: ${Math.round(efficiencyScore)}/100`
      });
      setAnalyzing(false);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-6xl mx-auto">
      {/* Animated Header */}
      <div className="text-center mb-12 relative">
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-b from-green-600/20 to-transparent rounded-full blur-3xl" />
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-green-400 via-emerald-400 to-green-400 bg-clip-text text-transparent mb-3">
            Eco-Driving Coach AI
          </h1>
          <p className="text-gray-400">AI-powered driving behavior analysis & fuel efficiency coaching</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        {!session && (
          <Card className="glass-card border-green-500/30 lg:col-span-1 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500" />
            <CardHeader className="relative z-10">
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-green-400" />
                Analyze Your Driving
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5 relative z-10">
              <form onSubmit={handleAnalyzeDriving} className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-gray-300 font-semibold">Distance Driven (km)</Label>
                  <Input 
                    type="number" 
                    step="0.1"
                    value={drivingData.distance}
                    onChange={(e) => setDrivingData(prev => ({ ...prev, distance: e.target.value }))}
                    placeholder="e.g., 25.5" 
                    className="bg-white/5 border border-green-500/30 text-white placeholder:text-gray-600 h-10"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300 font-semibold">Avg Speed (km/h)</Label>
                  <Input 
                    type="number"
                    value={drivingData.avgSpeed}
                    onChange={(e) => setDrivingData(prev => ({ ...prev, avgSpeed: e.target.value }))}
                    placeholder="e.g., 65" 
                    className="bg-white/5 border border-green-500/30 text-white placeholder:text-gray-600 h-10"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300 font-semibold">Braking Sessions</Label>
                  <Input 
                    type="number"
                    value={drivingData.brakingSessions}
                    onChange={(e) => setDrivingData(prev => ({ ...prev, brakingSessions: e.target.value }))}
                    placeholder="e.g., 8" 
                    className="bg-white/5 border border-green-500/30 text-white placeholder:text-gray-600 h-10"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300 font-semibold">Harsh Acceleration Events</Label>
                  <Input 
                    type="number"
                    value={drivingData.accelerationEvents}
                    onChange={(e) => setDrivingData(prev => ({ ...prev, accelerationEvents: e.target.value }))}
                    placeholder="e.g., 3" 
                    className="bg-white/5 border border-green-500/30 text-white placeholder:text-gray-600 h-10"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300 font-semibold">Idle Time (min)</Label>
                  <Input 
                    type="number"
                    value={drivingData.idleTime}
                    onChange={(e) => setDrivingData(prev => ({ ...prev, idleTime: e.target.value }))}
                    placeholder="e.g., 2" 
                    className="bg-white/5 border border-green-500/30 text-white placeholder:text-gray-600 h-10"
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full h-11 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold shadow-lg shadow-green-900/30 transition-all hover:shadow-xl"
                  disabled={analyzing}
                >
                  {analyzing ? (
                    <>
                      <span className="animate-spin mr-2">⚙️</span>
                      AI Analyzing...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" /> Analyze Driving
                    </>
                  )}
                </Button>
              </form>

              <div className="h-px bg-gradient-to-r from-transparent via-green-500/50 to-transparent" />

              <div className="space-y-3">
                <p className="text-xs text-gray-400 font-semibold">QUICK START</p>
                <Button 
                  type="button"
                  onClick={handleStartSession}
                  className="w-full h-10 bg-gradient-to-r from-emerald-600/50 to-teal-600/50 hover:from-emerald-600 hover:to-teal-600 text-white font-bold border border-emerald-500/30 transition-all"
                >
                  <Activity className="w-4 h-4 mr-2" /> Live Coaching Session
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Live Session Panel */}
        {session?.active && (
          <Card className="glass-card border-yellow-500/30 lg:col-span-1 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-600/10 to-transparent" />
            <CardHeader className="relative z-10">
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-yellow-400 animate-pulse" />
                Live Session
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 relative z-10">
              <div className="space-y-4">
                <div className="text-center">
                  <p className="text-gray-400 text-sm">Current Speed</p>
                  <p className="text-4xl font-bold text-yellow-400">{session.realTimeStats.currentSpeed} km/h</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-white/5 border border-white/10 rounded-lg">
                    <p className="text-xs text-gray-400">Efficiency</p>
                    <p className="text-xl font-bold text-green-400 mt-1">{session.realTimeStats.efficiency}</p>
                  </div>
                  <div className="p-3 bg-white/5 border border-white/10 rounded-lg">
                    <p className="text-xs text-gray-400">Consumption</p>
                    <p className="text-lg font-bold text-blue-400 mt-1">{session.realTimeStats.fuelConsumption}</p>
                  </div>
                </div>
              </div>

              <div className="h-1 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 rounded-full" />

              <Button 
                onClick={handleEndSession}
                className="w-full h-11 bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white font-bold"
              >
                🛑 End Session & Analyze
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Results Panel */}
        {session?.completed && (
          <Card className="glass-card border-teal-500/30 lg:col-span-2 animate-fade-in relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-600/5 via-green-600/5 to-transparent" />
            <CardHeader className="relative z-10">
              <div className="flex justify-between items-start mb-4">
                <CardTitle className="text-white flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-teal-400" />
                  Session Analysis Results
                </CardTitle>
                <div className="text-center bg-gradient-to-r from-green-500/20 to-transparent px-4 py-2 rounded-full border border-green-500/30">
                  <p className="text-xs text-gray-400">Efficiency</p>
                  <p className="text-2xl font-bold text-green-400">{session.metrics.efficiencyScore}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6 relative z-10">
              {/* Key Savings */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: '⚡', label: 'Fuel Saved', value: session.metrics.fuelSaved + ' L', color: 'from-blue-500 to-cyan-500' },
                  { icon: '🌍', label: 'CO₂ Reduced', value: session.metrics.co2Saved + ' kg', color: 'from-green-500 to-emerald-500' },
                  { icon: '💰', label: 'Money Saved', value: '₹' + session.metrics.costSaved, color: 'from-yellow-500 to-orange-500' }
                ].map((metric, i) => (
                  <div key={i} className={`p-4 rounded-lg bg-gradient-to-br ${metric.color}/10 border border-${metric.color.split('-')[1]}-500/20`}>
                    <p className="text-2xl mb-1">{metric.icon}</p>
                    <p className="text-xs text-gray-400">{metric.label}</p>
                    <p className="text-base font-bold text-white mt-1">{metric.value}</p>
                  </div>
                ))}
              </div>

              {/* Drive Stats */}
              <div className="grid md:grid-cols-2 gap-3">
                {[
                  { label: '🚗 Distance', value: session.distance + ' km' },
                  { label: '⏱️ Avg Speed', value: session.avgSpeed + ' km/h' },
                  { label: '🛑 Braking Events', value: session.brakingSessions },
                  { label: '⚡ Harsh Accelerations', value: session.acceleration }
                ].map((stat, i) => (
                  <div key={i} className="p-3 bg-white/5 border border-white/10 rounded-lg">
                    <p className="text-sm text-gray-400">{stat.label}</p>
                    <p className="text-lg font-bold text-white mt-1">{stat.value}</p>
                  </div>
                ))}
              </div>

              {/* AI Coach Feedback */}
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <p className="text-white font-bold mb-3 flex items-center gap-2">
                  🤖 AI Coach Feedback
                </p>
                <ul className="space-y-2">
                  {session.aiCoachFeedback.map((feedback, i) => (
                    <li key={i} className="text-gray-300 text-sm">{feedback}</li>
                  ))}
                </ul>
              </div>

              {/* Improvement Areas */}
              <div>
                <h4 className="text-white font-bold mb-3 flex items-center gap-2">
                  📊 Improvement Areas
                </h4>
                <div className="space-y-3">
                  {session.improvements.map((improvement, i) => (
                    <div key={i} className="p-3 bg-white/5 border border-white/10 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <p className="font-bold text-white">{improvement.area}</p>
                        <span className={`text-sm font-bold px-2 py-1 rounded ${
                          improvement.score >= 80 ? 'bg-green-500/20 text-green-400' :
                          improvement.score >= 60 ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {improvement.score}/100
                        </span>
                      </div>
                      <div className="w-full bg-white/10 rounded-full h-2 mb-2">
                        <div 
                          className={`h-full rounded-full ${
                            improvement.score >= 80 ? 'bg-green-500' :
                            improvement.score >= 60 ? 'bg-yellow-500' :
                            'bg-red-500'
                          }`}
                          style={{ width: improvement.score + '%' }}
                        />
                      </div>
                      <p className="text-xs text-gray-400">💡 {improvement.tips}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* New Analysis Button */}
              <Button 
                onClick={() => {
                  setSession(null);
                  setDrivingData({
                    distance: '',
                    avgSpeed: '',
                    brakingSessions: '',
                    accelerationEvents: '',
                    idleTime: ''
                  });
                }}
                className="w-full h-11 bg-gradient-to-r from-teal-600 to-green-600 hover:from-teal-700 hover:to-green-700 text-white font-bold"
              >
                ← Start New Analysis
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Tips & Badges */}
      <Card className="glass-card border-white/5 mt-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-green-600/10 to-transparent rounded-bl-full" />
        <CardHeader className="relative z-10">
          <CardTitle className="text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-green-400" /> Eco-Driving Tips & Achievements
          </CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-3 gap-6 relative z-10">
          <div className="space-y-3">
            <p className="text-gray-400 text-sm font-semibold">💡 Pro Tips</p>
            <ul className="space-y-2 text-sm">
              <li className="text-gray-300">✓ Maintain 60-70 km/h for optimal efficiency</li>
              <li className="text-gray-300">✓ Smooth acceleration saves 10-15% fuel</li>
              <li className="text-gray-300">✓ Plan ahead to minimize braking</li>
            </ul>
          </div>
          <div className="space-y-3">
            <p className="text-gray-400 text-sm font-semibold">🏆 Monthly Challenges</p>
            <div className="space-y-2">
              <div className="p-2 bg-green-500/10 border border-green-500/20 rounded">
                <p className="text-xs text-green-400 font-bold">✓ Smooth Driver</p>
              </div>
              <div className="p-2 bg-yellow-500/10 border border-yellow-500/20 rounded">
                <p className="text-xs text-yellow-400 font-bold">In Progress: Eco Warrior</p>
              </div>
            </div>
          </div>
          <div className="space-y-3">
            <p className="text-gray-400 text-sm font-semibold">📈 Your Stats</p>
            <ul className="space-y-2 text-sm">
              <li className="text-gray-300">Total Savings: ₹2,340</li>
              <li className="text-gray-300">CO₂ Reduced: 12.5 kg</li>
              <li className="text-gray-300">Sessions: 8</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
