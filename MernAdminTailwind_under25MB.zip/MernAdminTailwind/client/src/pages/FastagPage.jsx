import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, ArrowRight, History, Zap, Leaf, Plus, Check, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import jsPDF from 'jspdf';

export default function FastagPage() {
  const { toast } = useToast();
  const [balance, setBalance] = useState(450);
  const [amount, setAmount] = useState("");
  const [isPollutionFree, setIsPollutionFree] = useState(false);
  const [registeredFastag, setRegisteredFastag] = useState(null);
  const [registeredDuration, setRegisteredDuration] = useState(null);
  const [downloadingId, setDownloadingId] = useState(null);

  const handleRecharge = (e) => {
    e.preventDefault();
    const val = parseInt(amount);
    if (val > 0) {
      setBalance(prev => prev + val);
      setAmount("");
      toast({ 
        title: "Recharge Successful", 
        description: `Added ₹${val} to your FASTag wallet. New balance: ₹${balance + val}` 
      });
    }
  };

  const analyzeVehicle = () => {
    setIsPollutionFree(true);
    toast({
      title: "Vehicle Analysis Complete",
      description: "Your vehicle meets pollution-free standards! Speed limit: 100 km/h recommended."
    });
  };

  const handleFastTagOption = (speed, benefit) => {
    toast({
      title: "FASTag Option Selected",
      description: `Speed: ${speed} km/h | Benefit: ${benefit}`
    });
  };

  const handleRegisterFastag = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const selectedDurationValue = formData.get('duration');
    const selectedPlanValue = formData.get('plan');
    
    setRegisteredDuration(selectedDurationValue);
    setRegisteredFastag(selectedPlanValue);
    
    const durationLabel = {
      '1year': '1 Year',
      '2year': '2 Years',
      '3year': '3 Years',
      '5year': '5 Years'
    }[selectedDurationValue];

    // Store in localStorage for Reports module
    const fastagData = {
      plan: selectedPlanValue,
      duration: durationLabel,
      registrationNumber: formData.get('regNumber'),
      vehicleType: formData.get('vehicleType'),
      ownerName: formData.get('ownerName'),
      contactNumber: formData.get('contactNumber'),
      registeredDate: new Date().toLocaleDateString(),
      fastagId: `FT-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      initialBalance: 500
    };

    const existingReports = JSON.parse(localStorage.getItem('fastagReports') || '[]');
    existingReports.push(fastagData);
    localStorage.setItem('fastagReports', JSON.stringify(existingReports));

    toast({
      title: "FASTag Registered!",
      description: `${selectedPlanValue} plan for ${durationLabel} registered successfully.`
    });

    e.target.reset();
  };

  const generateFastagPDF = () => {
    setDownloadingId('fastag');
    setTimeout(() => {
      const pdf = new jsPDF();
      const pageWidth = pdf.internal.pageSize.getWidth();
      
      pdf.setFillColor(99, 102, 241);
      pdf.rect(0, 0, pageWidth, 40, 'F');
      
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(20);
      pdf.text('FASTag Account Report', 20, 25);
      
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(12);
      pdf.text('Current Account Status', 20, 55);
      
      pdf.setFontSize(10);
      const accountDetails = [
        ['Wallet Balance', '₹450'],
        ['Total Trips', '12'],
        ['Total Toll Cost', '₹1,240'],
        ['Total Fuel Cost', '₹3,450'],
        ['Distance Covered', '520 km'],
        ['Average Cost per KM', '₹3.85'],
        ['FASTag Savings', '₹340'],
        ['Last Transaction', 'Today']
      ];

      let yPosition = 70;
      accountDetails.forEach(([label, value]) => {
        pdf.text(`${label}:`, 20, yPosition);
        pdf.text(value, 120, yPosition);
        yPosition += 10;
      });

      pdf.setFontSize(11);
      pdf.text('Recent Transactions:', 20, yPosition + 10);
      yPosition += 20;

      const transactions = [
        'Electronic City Toll - ₹45 (Today, 10:30 AM)',
        'Airport Expressway - ₹120 (Yesterday, 6:15 PM)',
        'Wallet Recharge - +₹500 (28 Nov, 9:00 AM)'
      ];

      transactions.forEach((tx) => {
        pdf.text(`• ${tx}`, 25, yPosition);
        yPosition += 8;
      });

      pdf.save('FASTag-Report.pdf');
      toast({
        title: "Report Downloaded",
        description: "FASTag report saved as PDF"
      });
      setDownloadingId(null);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 via-background to-blue-600/20" />
      </div>

      <div className="relative z-10 pt-24 px-4 pb-12 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-display font-bold text-white flex items-center justify-center gap-3">
            <CreditCard className="w-8 h-8 text-indigo-500" />
            Smart FASTag Assistant
          </h1>
          <p className="text-gray-400">Seamless toll payments with AI-powered vehicle optimization</p>
        </div>

        <Tabs defaultValue="current" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white/5 mb-8">
            <TabsTrigger value="current">Current Account</TabsTrigger>
            <TabsTrigger value="register" className="flex items-center gap-2">
              <Plus className="w-4 h-4" /> New Registration
            </TabsTrigger>
          </TabsList>

          {/* Current Account Tab */}
          <TabsContent value="current">
            <div className="grid lg:grid-cols-3 gap-8">
              
              {/* Balance & Recharge */}
              <Card className="glass-card border-indigo-500/30 shadow-[0_0_30px_rgba(99,102,241,0.15)]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center justify-between">
                    <span>Wallet Balance</span>
                    <CreditCard className="w-6 h-6 text-indigo-500" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-5xl font-bold text-white mb-2">₹{balance}</div>
                  <p className={`text-sm mb-6 ${balance < 200 ? 'text-red-400' : 'text-green-400'}`}>
                    {balance < 200 ? '⚠ Low Balance! Recharge recommended.' : '✓ Balance sufficient for ~200km trip'}
                  </p>

                  <form onSubmit={handleRecharge} className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-gray-300">Recharge Amount</Label>
                      <div className="flex gap-2">
                        <Input 
                          type="number" 
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          placeholder="500" 
                          className="bg-white/5 border-white/10 text-white"
                        />
                        <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                          Add
                        </Button>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {[100, 500, 1000].map(val => (
                        <button 
                          key={val} 
                          type="button"
                          onClick={() => setAmount(val.toString())}
                          className="flex-1 px-3 py-2 rounded text-xs border border-white/10 hover:bg-white/10 text-gray-300 transition-all"
                        >
                          +₹{val}
                        </button>
                      ))}
                    </div>
                  </form>

                  <Button onClick={generateFastagPDF} className="w-full mt-4 bg-green-600 hover:bg-green-700 h-10" disabled={downloadingId === 'fastag'}>
                    {downloadingId === 'fastag' ? (
                      <>
                        <span className="animate-spin mr-2">⚙️</span>
                        Generating...
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4 mr-2" /> Download Report
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Vehicle Analysis */}
              <Card className="glass-card border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Leaf className="w-5 h-5 text-green-500" /> Vehicle Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!isPollutionFree ? (
                    <>
                      <p className="text-gray-400 text-sm">Analyze your vehicle to check pollution status and get optimal speed recommendations.</p>
                      <Button onClick={analyzeVehicle} className="w-full bg-green-600 hover:bg-green-700">
                        <Leaf className="mr-2 w-4 h-4" /> Analyze Vehicle
                      </Button>
                    </>
                  ) : (
                    <div className="space-y-3">
                      <div className="bg-green-500/10 border border-green-500/20 p-3 rounded text-center">
                        <p className="text-green-400 font-bold text-sm">✓ Pollution-Free Vehicle</p>
                        <p className="text-xs text-gray-400 mt-1">Zero emissions detected</p>
                      </div>
                      <div className="bg-blue-500/10 border border-blue-500/20 p-3 rounded">
                        <p className="text-blue-400 text-xs font-bold">RECOMMENDED SPEED</p>
                        <p className="text-white font-bold text-lg mt-1">100 km/h</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* FASTag Speed Options */}
              <Card className="glass-card border-white/5">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-500" /> FASTag Options
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { speed: '80 km/h', benefit: '20% discount', icon: '🐢' },
                    { speed: '100 km/h', benefit: '15% discount', icon: '🚗' },
                    { speed: '120 km/h', benefit: '5% discount', icon: '🏎️' }
                  ].map((option, i) => (
                    <Button
                      key={i}
                      onClick={() => handleFastTagOption(option.speed, option.benefit)}
                      className="w-full justify-between bg-white/5 hover:bg-white/10 text-white border border-white/10 h-auto py-3"
                    >
                      <span className="text-lg">{option.icon}</span>
                      <div className="text-center flex-1">
                        <p className="font-bold text-sm">{option.speed}</p>
                        <p className="text-xs text-green-400">{option.benefit}</p>
                      </div>
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Recent Transactions */}
            <Card className="glass-card border-white/5 mt-8">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <History className="w-5 h-5" /> Recent Toll Transactions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Electronic City Toll", amount: -45, date: "Today, 10:30 AM", speed: "95 km/h" },
                    { name: "Airport Expressway", amount: -120, date: "Yesterday, 6:15 PM", speed: "110 km/h" },
                    { name: "Wallet Recharge", amount: 500, date: "28 Nov, 9:00 AM", speed: "-" }
                  ].map((tx, i) => (
                    <div key={i} className="flex justify-between items-center p-4 bg-white/5 rounded hover:bg-white/10 transition-all">
                      <div>
                        <p className="font-medium text-white text-sm">{tx.name}</p>
                        <p className="text-xs text-gray-500">{tx.date}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {tx.amount > 0 ? '+' : ''}₹{Math.abs(tx.amount)}
                        </p>
                        <p className="text-xs text-gray-400">{tx.speed}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Registration Tab */}
          <TabsContent value="register">
            <Card className="glass-card border-indigo-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Plus className="w-5 h-5 text-indigo-400" /> Register New FASTag
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRegisterFastag} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-gray-300">Vehicle Registration Number</Label>
                      <Input name="regNumber" placeholder="KA-01-AB-1234" className="bg-white/5 border-white/10 text-white" required />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-gray-300">Vehicle Type</Label>
                      <Select defaultValue="car">
                        <SelectTrigger name="vehicleType" className="bg-white/5 border-white/10 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="car">Car</SelectItem>
                          <SelectItem value="bike">Bike</SelectItem>
                          <SelectItem value="truck">Truck</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-gray-300">Owner Name</Label>
                      <Input name="ownerName" placeholder="John Doe" className="bg-white/5 border-white/10 text-white" required />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-gray-300">Contact Number</Label>
                      <Input name="contactNumber" placeholder="+91-XXXXXXXXXX" className="bg-white/5 border-white/10 text-white" required />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label className="text-white font-bold">Select FASTag Plan</Label>
                    <div className="grid grid-cols-3 gap-3">
                      {['Standard', 'Plus', 'Premium'].map((plan) => (
                        <label key={plan} className="flex items-center gap-2 p-3 bg-white/5 border border-white/10 rounded-lg cursor-pointer hover:bg-white/10">
                          <input type="radio" name="plan" value={plan} required className="w-4 h-4" />
                          <span className="text-sm text-white">{plan}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                    <Label className="text-white font-bold block mb-4">Validity Period</Label>
                    <div className="grid grid-cols-4 gap-3">
                      {[
                        { value: '1year', label: '1 Year' },
                        { value: '2year', label: '2 Years' },
                        { value: '3year', label: '3 Years' },
                        { value: '5year', label: '5 Years' }
                      ].map((opt) => (
                        <label key={opt.value} className="flex items-center gap-2 p-3 bg-white/5 border border-white/10 rounded-lg cursor-pointer hover:bg-white/10">
                          <input type="radio" name="duration" value={opt.value} required className="w-4 h-4" />
                          <span className="text-sm text-white">{opt.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold h-11">
                    <CreditCard className="w-4 h-4 mr-2" /> Register FASTag
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
