import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { AlertCircle, Heart, Brain } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const colorConfig = {
  green: {
    border: 'border-green-500/30',
    bg: 'bg-green-500/10',
    text: 'text-green-400',
    gradient: 'from-green-500 to-emerald-500'
  },
  yellow: {
    border: 'border-yellow-500/30',
    bg: 'bg-yellow-500/10',
    text: 'text-yellow-400',
    gradient: 'from-yellow-500 to-orange-500'
  },
  orange: {
    border: 'border-orange-500/30',
    bg: 'bg-orange-500/10',
    text: 'text-orange-400',
    gradient: 'from-orange-500 to-red-500'
  },
  red: {
    border: 'border-red-500/30',
    bg: 'bg-red-500/10',
    text: 'text-red-400',
    gradient: 'from-red-500 to-red-600'
  }
};

export default function PanicPredictorAI() {
  const { toast } = useToast();
  const [metrics, setMetrics] = useState({
    hornPatterns: 3,
    laneChanges: 2,
    brakingFrequency: 4,
    clusteringTightness: 5
  });
  const [analysis, setAnalysis] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const analyzePanic = () => {
    setAnalyzing(true);
    setTimeout(() => {
      const hornScore = metrics.hornPatterns * 8;
      const laneScore = metrics.laneChanges * 10;
      const brakeScore = metrics.brakingFrequency * 7;
      const clusterScore = metrics.clusteringTightness * 6;
      
      const totalScore = (hornScore + laneScore + brakeScore + clusterScore) / 4;

      let dangerLevel = 'Low';
      let colorKey = 'green';
      let advice = [];

      if (totalScore < 30) {
        dangerLevel = 'Low';
        colorKey = 'green';
        advice = [
          '✓ Calm driving detected. Continue maintaining focus.',
          '💚 Your stress levels are normal. Stay alert and aware.',
          '🎵 Keep music at moderate volume. Stay connected to road sounds.'
        ];
      } else if (totalScore < 60) {
        dangerLevel = 'Medium';
        colorKey = 'yellow';
        advice = [
          '⚠️ Moderate stress signals detected. Take deep breaths.',
          '🚗 Your driving shows some tension. Slow down and relax grip.',
          '🎧 Consider taking a 5-minute break if possible.'
        ];
      } else if (totalScore < 85) {
        dangerLevel = 'High';
        colorKey = 'orange';
        advice = [
          '🚨 High panic indicators detected. Pull over safely.',
          '😰 Your horn usage and braking are erratic. Calm yourself first.',
          '📍 Find nearest safe location and take a 10-minute break.'
        ];
      } else {
        dangerLevel = 'Critical';
        colorKey = 'red';
        advice = [
          '🆘 CRITICAL PANIC LEVEL! Emergency assistance recommended.',
          '⛔ STOP the vehicle immediately in safe location.',
          '📞 Contact emergency services. You need immediate support.'
        ];
      }

      setAnalysis({
        dangerLevel,
        colorKey,
        score: Math.round(totalScore),
        hornAnalysis: {
          score: hornScore,
          interpretation: metrics.hornPatterns > 5 ? 'Excessive horn usage - sign of high stress' : 'Normal horn usage'
        },
        laneAnalysis: {
          score: laneScore,
          interpretation: metrics.laneChanges > 4 ? 'Frequent lane changes - erratic behavior' : 'Controlled lane changes'
        },
        brakingAnalysis: {
          score: brakeScore,
          interpretation: metrics.brakingFrequency > 5 ? 'Harsh/frequent braking - loss of control' : 'Smooth braking patterns'
        },
        clusterAnalysis: {
          score: clusterScore,
          interpretation: metrics.clusteringTightness > 6 ? 'Too close to other vehicles - risky' : 'Safe following distance'
        },
        advice
      });

      toast({
        title: "Panic Analysis Complete",
        description: `Danger Level: ${dangerLevel}`
      });
      setAnalyzing(false);
    }, 2000);
  };

  const getColorClasses = (colorKey) => colorConfig[colorKey] || colorConfig.green;

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12 relative">
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-b from-purple-600/20 to-transparent rounded-full blur-3xl" />
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent mb-3">
            🧠 AI Panic Proximity Predictor
          </h1>
          <p className="text-gray-400">Real-time stress and panic detection while driving</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <Card className="glass-card border-purple-500/30 lg:col-span-1 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-transparent" />
          <CardHeader className="relative z-10">
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              Driving Behavior Metrics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 relative z-10">
            <form onSubmit={(e) => { e.preventDefault(); analyzePanic(); }} className="space-y-4">
              {/* Horn Patterns */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex justify-between">
                  <span>Horn Usage (last 10 min)</span>
                  <span className="text-purple-400 font-bold">{metrics.hornPatterns}x</span>
                </label>
                <Slider 
                  value={[metrics.hornPatterns]} 
                  onValueChange={(val) => setMetrics(prev => ({ ...prev, hornPatterns: val[0] }))}
                  min={0}
                  max={10}
                />
                <p className="text-xs text-gray-400">Normal: 0-2x | Moderate: 3-5x | Excessive: 6+x</p>
              </div>

              {/* Lane Changes */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex justify-between">
                  <span>Lane Changes (last 10 min)</span>
                  <span className="text-purple-400 font-bold">{metrics.laneChanges}x</span>
                </label>
                <Slider 
                  value={[metrics.laneChanges]} 
                  onValueChange={(val) => setMetrics(prev => ({ ...prev, laneChanges: val[0] }))}
                  min={0}
                  max={10}
                />
                <p className="text-xs text-gray-400">Controlled: 0-2x | Moderate: 3-5x | Erratic: 6+x</p>
              </div>

              {/* Braking Frequency */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex justify-between">
                  <span>Braking Frequency (per km)</span>
                  <span className="text-purple-400 font-bold">{metrics.brakingFrequency}x</span>
                </label>
                <Slider 
                  value={[metrics.brakingFrequency]} 
                  onValueChange={(val) => setMetrics(prev => ({ ...prev, brakingFrequency: val[0] }))}
                  min={0}
                  max={10}
                />
                <p className="text-xs text-gray-400">Smooth: 0-3x | Normal: 4-6x | Harsh: 7+x</p>
              </div>

              {/* Clustering Tightness */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex justify-between">
                  <span>Clustering Tightness (distance)</span>
                  <span className="text-purple-400 font-bold">{metrics.clusteringTightness}</span>
                </label>
                <Slider 
                  value={[metrics.clusteringTightness]} 
                  onValueChange={(val) => setMetrics(prev => ({ ...prev, clusteringTightness: val[0] }))}
                  min={0}
                  max={10}
                />
                <p className="text-xs text-gray-400">Safe (3m+): 1-3 | Risky (1-2m): 4-7 | Dangerous: 8+</p>
              </div>

              <div className="h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent" />

              <Button 
                type="submit"
                className="w-full h-11 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold"
                disabled={analyzing}
              >
                {analyzing ? (
                  <>
                    <span className="animate-spin mr-2">⚙️</span>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 mr-2" /> Analyze Panic Level
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Results Panel */}
        {analysis && (
          <Card className={`glass-card ${getColorClasses(analysis.colorKey).border} lg:col-span-2 relative overflow-hidden animate-fade-in`}>
            <div className={`absolute inset-0 bg-gradient-to-br ${analysis.colorKey === 'green' ? 'from-green-600/10' : analysis.colorKey === 'yellow' ? 'from-yellow-600/10' : analysis.colorKey === 'orange' ? 'from-orange-600/10' : 'from-red-600/10'} to-transparent`} />
            <CardHeader className="relative z-10">
              <CardTitle className="text-white flex items-center gap-2">
                <Heart className="w-5 h-5 text-pink-400" />
                Real-Time Panic Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 relative z-10">
              {/* Danger Level Badge */}
              <div className="grid grid-cols-2 gap-4">
                <div className={`p-6 rounded-lg ${getColorClasses(analysis.colorKey).bg} border ${getColorClasses(analysis.colorKey).border} text-center`}>
                  <p className="text-gray-400 text-sm mb-2">Danger Level</p>
                  <p className={`text-4xl font-bold ${getColorClasses(analysis.colorKey).text}`}>{analysis.dangerLevel}</p>
                </div>
                <div className="p-6 rounded-lg bg-purple-500/10 border border-purple-500/30 text-center">
                  <p className="text-gray-400 text-sm mb-2">Panic Score</p>
                  <p className="text-4xl font-bold text-purple-400">{analysis.score}/100</p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="space-y-2">
                <p className="text-sm font-bold text-gray-300">Overall Risk</p>
                <div className="w-full bg-white/10 rounded-full h-3">
                  <div 
                    className={`h-full bg-gradient-to-r ${getColorClasses(analysis.colorKey).gradient} rounded-full`}
                    style={{ width: analysis.score + '%' }}
                  />
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Horn', data: analysis.hornAnalysis },
                  { label: 'Lane Changes', data: analysis.laneAnalysis },
                  { label: 'Braking', data: analysis.brakingAnalysis },
                  { label: 'Clustering', data: analysis.clusterAnalysis }
                ].map((metric, i) => (
                  <div key={i} className="p-3 bg-white/5 border border-white/10 rounded-lg">
                    <p className="text-sm font-bold text-white">{metric.label}</p>
                    <p className="text-xs text-gray-400 mt-1">{metric.data.interpretation}</p>
                    <p className="text-lg font-bold text-purple-400 mt-1">{Math.round(metric.data.score)}/100</p>
                  </div>
                ))}
              </div>

              {/* Advice */}
              <div className={`p-4 rounded-lg ${getColorClasses(analysis.colorKey).bg} border ${getColorClasses(analysis.colorKey).border} space-y-2`}>
                <p className="font-bold text-white">AI Recommendations:</p>
                {analysis.advice.map((tip, i) => (
                  <p key={i} className="text-sm text-gray-200 leading-relaxed">{tip}</p>
                ))}
              </div>

              <Button onClick={() => {
                toast({
                  title: "Emergency Call Initiated",
                  description: "Connecting to emergency services..."
                });
              }} className={`w-full h-10 text-white font-bold ${analysis.colorKey === 'green' ? 'bg-green-600 hover:bg-green-700' : analysis.colorKey === 'yellow' ? 'bg-yellow-600 hover:bg-yellow-700' : analysis.colorKey === 'orange' ? 'bg-orange-600 hover:bg-orange-700' : 'bg-red-600 hover:bg-red-700'}`}>
                📞 Call Emergency Assistance
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
