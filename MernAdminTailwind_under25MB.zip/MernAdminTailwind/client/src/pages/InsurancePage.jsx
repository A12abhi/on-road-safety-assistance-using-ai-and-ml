import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield, Check, Download, Phone, Star, Zap, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import jsPDF from 'jspdf';

export default function InsurancePage() {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [registeredPlan, setRegisteredPlan] = useState(null);
  const [registeredDuration, setRegisteredDuration] = useState(null);
  const [downloadingId, setDownloadingId] = useState(null);

  const handleSelectPlan = (plan) => {
    setSelectedPlan(plan.name);
    toast({
      title: "Plan Selected!",
      description: `${plan.name} has been selected. Proceeding to checkout.`
    });
  };

  const handleRegisterInsurance = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const selectedDurationValue = formData.get('duration');
    const selectedRegisteredPlanValue = formData.get('plan');
    
    setRegisteredDuration(selectedDurationValue);
    setRegisteredPlan(selectedRegisteredPlanValue);
    
    const durationLabel = {
      '1year': '1 Year',
      '2year': '2 Years',
      '3year': '3 Years',
      '5year': '5 Years'
    }[selectedDurationValue];

    // Store in localStorage for Reports module
    const insuranceData = {
      plan: selectedRegisteredPlanValue,
      duration: durationLabel,
      registrationNumber: formData.get('regNumber'),
      vehicleType: formData.get('vehicleType'),
      ownerName: formData.get('ownerName'),
      contactNumber: formData.get('contactNumber'),
      registeredDate: new Date().toLocaleDateString(),
      policyNumber: `POL-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    };

    const existingReports = JSON.parse(localStorage.getItem('insuranceReports') || '[]');
    existingReports.push(insuranceData);
    localStorage.setItem('insuranceReports', JSON.stringify(existingReports));

    toast({
      title: "Insurance Registered!",
      description: `${selectedRegisteredPlanValue} plan for ${durationLabel} registered successfully.`
    });

    e.target.reset();
  };

  const generatePDF = (isCurrentPolicy = false) => {
    setDownloadingId('current');
    setTimeout(() => {
      const pdf = new jsPDF();
      const pageWidth = pdf.internal.pageSize.getWidth();
      
      pdf.setFillColor(30, 100, 200);
      pdf.rect(0, 0, pageWidth, 40, 'F');
      
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(20);
      pdf.text('Insurance Policy Document', 20, 25);
      
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(12);
      pdf.text('Current Policy Summary', 20, 55);
      
      pdf.setFontSize(10);
      const policyDetails = [
        ['Policy Number', 'POL-8829-XJ-21'],
        ['Insurer', 'SafeDrive Assurance'],
        ['Coverage Type', 'Comprehensive + Zero Depreciation'],
        ['Policy Amount', '₹5,00,000'],
        ['Premium', '₹12,500/year'],
        ['Expiry Date', '12 Dec 2026'],
        ['Claims History', '0 claims filed'],
        ['Risk Score', 'Low (15/100)']
      ];

      let yPosition = 70;
      policyDetails.forEach(([label, value]) => {
        pdf.text(`${label}:`, 20, yPosition);
        pdf.text(value, 120, yPosition);
        yPosition += 10;
      });

      pdf.setFontSize(11);
      pdf.text('Coverage Details:', 20, yPosition + 10);
      yPosition += 20;

      const coverageItems = [
        'Third Party Liability Coverage',
        'Own Damage Coverage',
        'Theft Coverage',
        'Natural Calamity Coverage',
        'Cashless Repair Network',
        'Zero Depreciation Benefit',
        '24/7 Roadside Assistance'
      ];

      coverageItems.forEach((item) => {
        pdf.text(`✓ ${item}`, 25, yPosition);
        yPosition += 8;
      });

      pdf.save('Insurance-Policy.pdf');
      toast({
        title: "Policy Downloaded",
        description: "Insurance policy saved as PDF"
      });
      setDownloadingId(null);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-background to-purple-600/20" />
      </div>

      <div className="relative z-10 pt-24 px-4 pb-12 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-display font-bold text-white">Insurance Vault</h1>
          <p className="text-gray-400">AI-Recommended Plans - Choose the Best Protection</p>
        </div>

        <Tabs defaultValue="current" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white/5 mb-8">
            <TabsTrigger value="current">Current Policy</TabsTrigger>
            <TabsTrigger value="register" className="flex items-center gap-2">
              <Plus className="w-4 h-4" /> New Registration
            </TabsTrigger>
          </TabsList>

          {/* Current Policy Tab */}
          <TabsContent value="current">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Active Policy */}
              <Card className="lg:col-span-1 glass-card border-emerald-500/30 shadow-[0_0_30px_rgba(16,185,129,0.1)]">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-emerald-400 text-xl">Current Policy</CardTitle>
                      <p className="text-xs text-gray-400 mt-1">Expires: 12 Dec 2026</p>
                    </div>
                    <Shield className="w-8 h-8 text-emerald-500" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-gray-500 uppercase">Policy Number</p>
                      <p className="text-white font-mono font-bold">POL-8829-XJ-21</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 uppercase">Insurer</p>
                      <p className="text-white font-medium">SafeDrive Assurance</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 uppercase">Coverage</p>
                      <p className="text-white font-medium">Comprehensive + Zero Dep</p>
                    </div>
                  </div>

                  <div className="flex gap-2 flex-col">
                    <Button onClick={() => generatePDF(true)} className="w-full bg-emerald-600 hover:bg-emerald-700 h-9 text-sm" disabled={downloadingId === 'current'}>
                      {downloadingId === 'current' ? (
                        <>
                          <span className="animate-spin mr-2">⚙️</span>
                          Generating...
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4 mr-2" /> Download Policy
                        </>
                      )}
                    </Button>
                    <Button className="w-full bg-white/10 hover:bg-white/20 h-9 text-sm text-white border border-white/10">
                      <Phone className="w-4 h-4 mr-2" /> Call Agent
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* AI Recommended Plans */}
              {[
                { name: "Basic Plus", price: "₹2,999/yr", features: ["Third Party", "Legal Support", "Roadside Help"], rating: 3.5 },
                { name: "AI Smart Comprehensive", price: "₹9,999/yr", features: ["Own Damage", "Theft", "Natural Calamity", "Cashless Repair", "0% Depreciation"], rating: 4.9, recommended: true },
                { name: "Premium Elite", price: "₹14,999/yr", features: ["All Benefits", "Personal Accident", "Home Repair", "24/7 Concierge"], rating: 4.8 }
              ].map((plan, i) => (
                <Card key={i} className={`glass-card ${plan.recommended ? 'border-blue-500/50 bg-blue-900/10 ring-2 ring-blue-500/30' : 'border-white/10'}`}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white text-lg flex items-center gap-2">
                          {plan.name}
                          {plan.recommended && <Zap className="w-4 h-4 text-blue-400" />}
                        </CardTitle>
                        <div className="flex items-center gap-1 mt-2">
                          {[...Array(5)].map((_, j) => (
                            <Star key={j} className={`w-3 h-3 ${j < Math.floor(plan.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'}`} />
                          ))}
                          <span className="text-xs text-gray-400 ml-1">{plan.rating}</span>
                        </div>
                      </div>
                      {plan.recommended && <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded-full font-bold">AI BEST</span>}
                    </div>
                    <div className="text-2xl font-bold text-white mt-3">{plan.price}</div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <ul className="space-y-2">
                      {plan.features.map((f, j) => (
                        <li key={j} className="text-xs text-gray-300 flex items-center gap-2">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0" /> {f}
                        </li>
                      ))}
                    </ul>
                    {plan.recommended && (
                      <div className="bg-blue-500/10 border border-blue-500/20 p-2 rounded text-xs text-blue-300">
                        AI suggests this based on your vehicle type and usage pattern
                      </div>
                    )}
                    <Button
                      onClick={() => handleSelectPlan(plan)}
                      className={`w-full h-9 text-sm ${plan.recommended ? 'bg-blue-600 hover:bg-blue-700' : 'bg-white/10 hover:bg-white/20 text-white border border-white/10'}`}
                      disabled={selectedPlan === plan.name}
                    >
                      {selectedPlan === plan.name ? '✓ Selected' : 'Select Plan'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* New Registration Tab */}
          <TabsContent value="register">
            <Card className="glass-card border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Plus className="w-5 h-5 text-blue-400" /> Register New Insurance
                </CardTitle>
                <p className="text-sm text-gray-400 mt-2">Select plan and duration for your vehicle coverage</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRegisterInsurance} className="space-y-6">
                  {/* Vehicle Details */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-gray-300">Vehicle Registration Number</Label>
                      <Input name="regNumber" placeholder="KA-01-AB-1234" className="bg-white/5 border-white/10 text-white" required />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-gray-300">Vehicle Type</Label>
                      <Select defaultValue="car">
                        <SelectTrigger name="vehicleType" className="bg-white/5 border-white/10 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="car">Car</SelectItem>
                          <SelectItem value="bike">Bike</SelectItem>
                          <SelectItem value="truck">Truck</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-gray-300">Owner Name</Label>
                      <Input name="ownerName" placeholder="John Doe" className="bg-white/5 border-white/10 text-white" required />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-gray-300">Contact Number</Label>
                      <Input name="contactNumber" placeholder="+91-XXXXXXXXXX" className="bg-white/5 border-white/10 text-white" required />
                    </div>
                  </div>

                  {/* Plan Selection */}
                  <div className="space-y-3">
                    <Label className="text-white font-bold">Select Insurance Plan</Label>
                    <div className="grid grid-cols-3 gap-3">
                      {['Basic Plus', 'AI Smart Comprehensive', 'Premium Elite'].map((plan) => (
                        <label key={plan} className="flex items-center gap-2 p-3 bg-white/5 border border-white/10 rounded-lg cursor-pointer hover:bg-white/10">
                          <input type="radio" name="plan" value={plan} required className="w-4 h-4" />
                          <span className="text-sm text-white">{plan}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Coverage Duration */}
                  <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                    <Label className="text-white font-bold block mb-4">Select Coverage Duration</Label>
                    <div className="grid grid-cols-4 gap-3">
                      {[
                        { value: '1year', label: '1 Year', benefit: 'Best for Short-term' },
                        { value: '2year', label: '2 Years', benefit: 'Standard' },
                        { value: '3year', label: '3 Years', benefit: 'Popular - 5% Save' },
                        { value: '5year', label: '5 Years', benefit: 'Best Deal - 15% Save' }
                      ].map((opt) => (
                        <label key={opt.value} className="flex items-center gap-2 p-3 bg-white/5 border border-white/10 rounded-lg cursor-pointer hover:bg-white/10">
                          <input type="radio" name="duration" value={opt.value} required className="w-4 h-4" />
                          <div>
                            <p className="text-xs text-gray-400">{opt.label}</p>
                            <p className="text-xs text-white font-bold">{opt.benefit}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                  <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold h-11">
                    <Shield className="w-4 h-4 mr-2" /> Register Insurance
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
