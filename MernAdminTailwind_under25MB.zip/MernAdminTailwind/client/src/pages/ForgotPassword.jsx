import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle2, RefreshCw, Lock } from 'lucide-react';
import bgImage from '@assets/generated_images/secure_digital_recovery_interface.png';

const forgotSchema = z.object({
  email: z.string().email("Invalid email address"),
  captcha: z.string().min(1, "Captcha answer is required"),
});

export default function ForgotPassword() {
  const navigate = useNavigate();
  const [step, setStep] = useState('input'); // input, success
  const [captcha, setCaptcha] = useState({ num1: 0, num2: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(forgotSchema)
  });

  const generateCaptcha = () => {
    setCaptcha({
      num1: Math.floor(Math.random() * 10) + 1,
      num2: Math.floor(Math.random() * 10) + 1
    });
  };

  useEffect(() => {
    generateCaptcha();
  }, []);

  const onSubmit = (data) => {
    setError("");
    setLoading(true);

    // Validate Captcha
    if (parseInt(data.captcha) !== captcha.num1 + captcha.num2) {
      setError("Incorrect captcha answer. Please try again.");
      generateCaptcha();
      setLoading(false);
      return;
    }

    // Simulate API Call
    setTimeout(() => {
      // Check if user exists in local storage (mock)
      const users = JSON.parse(localStorage.getItem("users") || "[]");
      const userExists = users.some(u => u.email === data.email);

      if (userExists) {
        setStep('success');
      } else {
        // For security, usually we don't reveal if email exists, but for mockup we can show success or a generic message
        setStep('success'); 
      }
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img src={bgImage} alt="Background" className="w-full h-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/60" />
      </div>

      <Card className="w-full max-w-md glass-card border-white/10 relative z-10 shadow-2xl animate-slide-up">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mb-2">
            <Lock className="w-6 h-6 text-primary" />
          </div>
          <CardTitle className="text-2xl font-display font-bold text-white">Account Recovery</CardTitle>
          <CardDescription className="text-gray-400">
            {step === 'input' ? "Reset your password securely" : "Check your inbox"}
          </CardDescription>
        </CardHeader>

        <CardContent>
          {step === 'input' ? (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              {error && (
                <Alert variant="destructive" className="bg-red-500/10 border-red-500/20 text-red-400">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Registered Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="name@example.com" 
                  {...register("email")}
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary/50"
                />
                {errors.email && <p className="text-xs text-red-400">{errors.email.message}</p>}
              </div>

              <div className="space-y-2">
                <Label>Security Check</Label>
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 px-4 py-2 rounded text-white font-mono text-lg tracking-widest border border-white/10 select-none">
                    {captcha.num1} + {captcha.num2} = ?
                  </div>
                  <Button type="button" variant="ghost" size="icon" onClick={generateCaptcha} className="text-gray-400 hover:text-white">
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
                <Input 
                  placeholder="Enter the sum" 
                  type="number"
                  {...register("captcha")}
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary/50"
                />
                {errors.captcha && <p className="text-xs text-red-400">{errors.captcha.message}</p>}
              </div>

              <Button type="submit" className="w-full bg-primary hover:bg-blue-600 text-white" disabled={loading}>
                {loading ? "Verifying..." : "Send Recovery Link"}
              </Button>
            </form>
          ) : (
            <div className="text-center space-y-4 animate-fade-in">
              <div className="mx-auto w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8 text-green-500" />
              </div>
              <div className="space-y-2">
                <p className="text-white text-lg font-medium">Recovery Email Sent!</p>
                <p className="text-gray-400 text-sm">
                  We've sent password reset instructions to your email address. Please check your inbox and spam folder.
                </p>
              </div>
              <Button onClick={() => navigate('/login')} className="w-full bg-white/10 hover:bg-white/20 text-white border border-white/10">
                Return to Login
              </Button>
            </div>
          )}
        </CardContent>
        
        {step === 'input' && (
          <CardFooter className="flex justify-center">
            <Link to="/login" className="text-xs text-gray-500 hover:text-gray-300 transition-colors">
              ← Back to Login
            </Link>
          </CardFooter>
        )}
      </Card>
    </div>
  );
}
