import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Wind, Download, Check, AlertTriangle, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import jsPDF from 'jspdf';

export default function EmissionTestingPage() {
  const { toast } = useToast();
  const [testResult, setTestResult] = useState(null);
  const [downloadingId, setDownloadingId] = useState(null);

  const handleRunTest = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const vehicleAge = formData.get('age');
    const fuelType = formData.get('fuelType');
    const engineCC = formData.get('engineCC');
    const lastService = formData.get('lastService');

    // Mock emission test results
    const coLevel = Math.random() * 1.5;
    const hcLevel = Math.random() * 200;
    const noxLevel = Math.random() * 800;

    const isPassed = coLevel <= 1.0 && hcLevel <= 150 && noxLevel <= 600;

    const result = {
      passed: isPassed,
      date: new Date().toLocaleDateString(),
      vehicleAge,
      fuelType,
      engineCC,
      lastService,
      co: { value: coLevel.toFixed(2), status: coLevel <= 1.0 ? 'PASS' : 'FAIL', limit: '1.0%' },
      hc: { value: Math.round(hcLevel), status: hcLevel <= 150 ? 'PASS' : 'FAIL', limit: '150 ppm' },
      nox: { value: Math.round(noxLevel), status: noxLevel <= 600 ? 'PASS' : 'FAIL', limit: '600 ppm' },
      smokeIntensity: 'Light',
      certificateNo: `CERT-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      nextTestDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString()
    };

    setTestResult(result);

    // Store in localStorage for Reports
    const emissionData = {
      certificateNumber: result.certificateNo,
      passed: isPassed,
      testDate: result.date,
      nextTestDate: result.nextTestDate,
      vehicleAge,
      fuelType,
      engineCC,
      co: result.co.value,
      hc: result.hc.value,
      nox: result.nox.value
    };

    const existingReports = JSON.parse(localStorage.getItem('emissionReports') || '[]');
    existingReports.push(emissionData);
    localStorage.setItem('emissionReports', JSON.stringify(existingReports));

    toast({
      title: isPassed ? "Test Passed! ✓" : "Test Failed! ✗",
      description: isPassed ? 
        "Your vehicle meets all emission standards." : 
        "Some pollutants exceeded limits. Service recommended."
    });
  };

  const generatePDF = () => {
    if (!testResult) return;
    
    setDownloadingId('emission');
    setTimeout(() => {
      const pdf = new jsPDF();
      const pageWidth = pdf.internal.pageSize.getWidth();
      
      pdf.setFillColor(testResult.passed ? 34 : 239, testResult.passed ? 197 : 68, testResult.passed ? 94 : 68);
      pdf.rect(0, 0, pageWidth, 40, 'F');
      
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(20);
      pdf.text('Emission Test Certificate', 20, 25);
      
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(14);
      pdf.text(testResult.passed ? '✓ TEST PASSED' : '✗ TEST FAILED', 20, 55);
      
      pdf.setFontSize(10);
      const details = [
        ['Certificate Number', testResult.certificateNo],
        ['Test Date', testResult.date],
        ['Next Test Date', testResult.nextTestDate],
        ['Vehicle Age', testResult.vehicleAge + ' years'],
        ['Fuel Type', testResult.fuelType],
        ['Engine CC', testResult.engineCC],
        ['CO Level', `${testResult.co.value}% (${testResult.co.status})`],
        ['HC Level', `${testResult.hc.value} ppm (${testResult.hc.status})`],
        ['NOx Level', `${testResult.nox.value} ppm (${testResult.nox.status})`]
      ];

      let yPosition = 70;
      details.forEach(([label, value]) => {
        pdf.text(`${label}:`, 20, yPosition);
        pdf.text(value, 120, yPosition);
        yPosition += 10;
      });

      pdf.setFontSize(11);
      pdf.text('Recommendations:', 20, yPosition + 10);
      yPosition += 20;

      const recommendations = testResult.passed ? [
        'Vehicle is compliant with emission standards',
        'Continue regular maintenance every 6 months',
        'Use quality fuel for optimal emission levels',
        'Check engine oil and filter regularly'
      ] : [
        'Vehicle failed emission test',
        'Service required immediately',
        'Check catalytic converter and oxygen sensor',
        'Retest after service completion'
      ];

      recommendations.forEach((rec) => {
        pdf.text(`• ${rec}`, 25, yPosition);
        yPosition += 8;
      });

      pdf.save('Emission-Certificate.pdf');
      toast({
        title: "Certificate Downloaded",
        description: "Emission test certificate saved as PDF"
      });
      setDownloadingId(null);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 via-background to-emerald-600/20" />
      </div>

      <div className="relative z-10 pt-24 px-4 pb-12 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-display font-bold text-white flex items-center justify-center gap-3 mb-2">
            <Wind className="w-8 h-8 text-green-500" />
            Emission Testing Center
          </h1>
          <p className="text-gray-400">AI-Powered Pollution Level Analysis</p>
        </div>

        {!testResult ? (
          <Card className="glass-card border-green-500/30 max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Wind className="w-5 h-5 text-green-400" /> Run Emission Test
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleRunTest} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-gray-300">Vehicle Age (years)</Label>
                    <Input name="age" type="number" placeholder="5" min="0" max="30" className="bg-white/5 border-white/10 text-white" required />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Fuel Type</Label>
                    <select name="fuelType" className="w-full bg-white/5 border border-white/10 text-white rounded-lg h-10 px-3">
                      <option value="Petrol">Petrol</option>
                      <option value="Diesel">Diesel</option>
                      <option value="CNG">CNG</option>
                      <option value="Electric">Electric</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Engine CC</Label>
                    <Input name="engineCC" placeholder="1500" className="bg-white/5 border-white/10 text-white" required />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-300">Last Service Date</Label>
                    <Input name="lastService" type="date" className="bg-white/5 border-white/10 text-white" required />
                  </div>
                </div>

                <Button type="submit" className="w-full h-12 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold text-base">
                  <Zap className="w-5 h-5 mr-2" /> Start Emission Test
                </Button>
              </form>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8 max-w-4xl mx-auto">
            {/* Test Result Card */}
            <Card className={`glass-card border-${testResult.passed ? 'green' : 'red'}-500/30`}>
              <CardHeader>
                <CardTitle className={`text-white flex items-center gap-2 text-2xl`}>
                  {testResult.passed ? (
                    <>
                      <Check className="w-6 h-6 text-green-400" /> Test Passed ✓
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-6 h-6 text-red-400" /> Test Failed ✗
                    </>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Basic Info */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-gray-400 text-xs mb-1">Certificate Number</p>
                    <p className="text-lg font-bold text-white">{testResult.certificateNo}</p>
                  </div>
                  <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-gray-400 text-xs mb-1">Test Date</p>
                    <p className="text-lg font-bold text-white">{testResult.date}</p>
                  </div>
                  <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-gray-400 text-xs mb-1">Next Test Due</p>
                    <p className="text-lg font-bold text-white">{testResult.nextTestDate}</p>
                  </div>
                  <div className={`p-4 rounded-lg border ${testResult.passed ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20'}`}>
                    <p className="text-gray-400 text-xs mb-1">Status</p>
                    <p className={`text-lg font-bold ${testResult.passed ? 'text-green-400' : 'text-red-400'}`}>
                      {testResult.passed ? 'COMPLIANT' : 'NON-COMPLIANT'}
                    </p>
                  </div>
                </div>

                {/* Pollutant Levels */}
                <div className="space-y-3">
                  <h3 className="text-white font-bold text-lg">Pollutant Levels</h3>
                  {[
                    { name: 'CO (Carbon Monoxide)', level: testResult.co },
                    { name: 'HC (Hydrocarbons)', level: testResult.hc },
                    { name: 'NOx (Nitrogen Oxides)', level: testResult.nox }
                  ].map((pollutant, i) => (
                    <div key={i} className="p-4 bg-white/5 border border-white/10 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-white font-bold">{pollutant.name}</span>
                        <span className={`text-sm font-bold ${pollutant.level.status === 'PASS' ? 'text-green-400' : 'text-red-400'}`}>
                          {pollutant.level.status}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-gray-400 text-sm mb-2">
                        <span>Value: {pollutant.level.value}</span>
                        <span>Limit: {pollutant.level.limit}</span>
                      </div>
                      <div className="w-full bg-white/10 rounded-full h-2">
                        <div 
                          className={`h-full rounded-full ${pollutant.level.status === 'PASS' ? 'bg-green-500' : 'bg-red-500'}`}
                          style={{ width: pollutant.level.status === 'PASS' ? '40%' : '85%' }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Recommendations */}
                <div className={`p-4 rounded-lg border ${testResult.passed ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20'}`}>
                  <p className={`font-bold mb-2 ${testResult.passed ? 'text-green-400' : 'text-red-400'}`}>
                    {testResult.passed ? '✓ Recommendations' : '⚠️ Action Required'}
                  </p>
                  {testResult.passed ? (
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Vehicle is emission compliant</li>
                      <li>• Continue regular maintenance every 6 months</li>
                      <li>• Use quality fuel for optimal performance</li>
                    </ul>
                  ) : (
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Service your vehicle immediately</li>
                      <li>• Check catalytic converter and oxygen sensor</li>
                      <li>• Retest after service completion</li>
                    </ul>
                  )}
                </div>

                {/* Download Button */}
                <Button onClick={generatePDF} className={`w-full h-12 text-white font-bold text-base ${testResult.passed ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`} disabled={downloadingId === 'emission'}>
                  {downloadingId === 'emission' ? (
                    <>
                      <span className="animate-spin mr-2">⚙️</span>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 mr-2" /> Download Certificate
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Run Another Test */}
            <Button onClick={() => setTestResult(null)} className="w-full bg-white/10 hover:bg-white/20 text-white font-bold h-10 border border-white/10">
              Run Another Test
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
