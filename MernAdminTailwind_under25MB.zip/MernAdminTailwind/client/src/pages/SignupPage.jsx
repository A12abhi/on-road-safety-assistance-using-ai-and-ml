import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Loader2 } from 'lucide-react';
import bgImage from '@assets/generated_images/modern_fuel_station_aesthetic.png';

const signupSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  phone: z.string().min(10, "Phone number must be at least 10 digits"),
  vehicleNumber: z.string().min(4, "Vehicle number is required"),
});

export default function SignupPage() {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(signupSchema)
  });

  const onSubmit = async (data) => {
    setError("");
    setLoading(true);
    
    setTimeout(() => {
      const result = signup(data);
      setLoading(false);

      if (result.success) {
        navigate('/login');
      } else {
        setError(result.message);
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img src={bgImage} alt="Background" className="w-full h-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/60" />
      </div>

      <Card className="w-full max-w-md glass-card border-white/10 relative z-10 shadow-2xl animate-slide-up">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-2xl font-display font-bold text-white">Create Account</CardTitle>
          <CardDescription className="text-gray-400">
            Join OnRoad for smart assistance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {error && (
              <Alert variant="destructive" className="bg-red-500/10 border-red-500/20 text-red-400">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input 
                id="name" 
                {...register("name")}
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
              />
              {errors.name && <p className="text-xs text-red-400">{errors.name.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email" 
                {...register("email")}
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
              />
              {errors.email && <p className="text-xs text-red-400">{errors.email.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password" 
                {...register("password")}
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
              />
              {errors.password && <p className="text-xs text-red-400">{errors.password.message}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input 
                  id="phone" 
                  {...register("phone")}
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
                {errors.phone && <p className="text-xs text-red-400">{errors.phone.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="vehicleNumber">Vehicle No.</Label>
                <Input 
                  id="vehicleNumber" 
                  placeholder="KA01AB1234"
                  {...register("vehicleNumber")}
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
                {errors.vehicleNumber && <p className="text-xs text-red-400">{errors.vehicleNumber.message}</p>}
              </div>
            </div>

            <Button type="submit" className="w-full bg-primary hover:bg-blue-600 text-white" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Sign Up"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col gap-4 text-center">
          <div className="text-sm text-gray-400">
            Already have an account? <Link to="/login" className="text-primary hover:underline">Login</Link>
          </div>
          <div className="text-xs text-gray-500">
            Are you an admin? <Link to="/admin/login" className="hover:text-gray-300 transition-colors underline">Admin Login</Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
