import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Leaf, TrendingDown, AlertCircle, CheckCircle, Zap } from 'lucide-react';

export default function PollutionAnalyzer() {
  const [result, setResult] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const handleAnalyze = (e) => {
    e.preventDefault();
    setAnalyzing(true);
    setResult(null);
    
    const formData = new FormData(e.target);
    const vehicleType = formData.get('type');
    const fuelType = formData.get('fuel');
    const mileage = parseInt(formData.get('mileage'));

    setTimeout(() => {
      let pollutionScore = 75;
      let status = 'Good';
      let recommendations = [];

      if (fuelType === 'diesel') pollutionScore -= 15;
      if (fuelType === 'cng') pollutionScore += 20;
      if (vehicleType === 'truck') pollutionScore -= 25;
      if (vehicleType === 'bike') pollutionScore += 15;
      if (mileage > 100000) pollutionScore -= 10;

      if (pollutionScore >= 80) status = 'Excellent';
      else if (pollutionScore >= 60) status = 'Good';
      else if (pollutionScore >= 40) status = 'Fair';
      else status = 'Poor';

      if (fuelType === 'petrol' && mileage > 50000) recommendations.push("Engine oil change overdue");
      if (vehicleType === 'truck') recommendations.push("Diesel filter replacement recommended");
      if (pollutionScore < 50) recommendations.push("Schedule emission test immediately");
      if (fuelType === 'cng') recommendations.push("Excellent choice for environment!");

      setResult({
        score: pollutionScore,
        status,
        co2: (150 - (pollutionScore * 0.5)).toFixed(1),
        nox: (8 - (pollutionScore * 0.02)).toFixed(2),
        pm25: (15 - (pollutionScore * 0.03)).toFixed(1),
        recommendations
      });
      setAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-display font-bold text-white flex items-center justify-center gap-3">
          <Leaf className="w-8 h-8 text-green-500" />
          Pollution Impact Analyzer
        </h1>
        <p className="text-gray-400">AI-powered emission analysis for your vehicle</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="glass-card border-green-500/30">
          <CardHeader>
            <CardTitle className="text-white">Vehicle Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAnalyze} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Vehicle Type</Label>
                <Select name="type" defaultValue="car">
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="car">Car</SelectItem>
                    <SelectItem value="bike">Bike</SelectItem>
                    <SelectItem value="truck">Truck</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-gray-300">Fuel Type</Label>
                <Select name="fuel" defaultValue="petrol">
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="petrol">Petrol</SelectItem>
                    <SelectItem value="diesel">Diesel</SelectItem>
                    <SelectItem value="cng">CNG</SelectItem>
                    <SelectItem value="ev">Electric</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Mileage (km)</Label>
                <Input name="mileage" type="number" placeholder="45000" className="bg-white/5 border-white/10 text-white" required />
              </div>

              <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white" disabled={analyzing}>
                {analyzing ? "Analyzing..." : "Analyze Pollution Impact"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {result && (
          <Card className="glass-card border-green-500/30 animate-fade-in">
            <CardHeader>
              <CardTitle className="text-white flex justify-between items-center">
                <span>Analysis Results</span>
                {result.score >= 60 ? 
                  <CheckCircle className="w-6 h-6 text-green-500" /> : 
                  <AlertCircle className="w-6 h-6 text-red-500" />
                }
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-5xl font-bold text-white mb-2">{result.score}</div>
                <p className={`text-lg font-bold ${result.score >= 60 ? 'text-green-400' : 'text-red-400'}`}>
                  {result.status} Rating
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white/5 p-3 rounded text-center">
                  <p className="text-xs text-gray-500">CO₂ (g/km)</p>
                  <p className="text-lg font-bold text-white">{result.co2}</p>
                </div>
                <div className="bg-white/5 p-3 rounded text-center">
                  <p className="text-xs text-gray-500">NOₓ (mg/km)</p>
                  <p className="text-lg font-bold text-white">{result.nox}</p>
                </div>
                <div className="bg-white/5 p-3 rounded text-center">
                  <p className="text-xs text-gray-500">PM2.5 (µg/m³)</p>
                  <p className="text-lg font-bold text-white">{result.pm25}</p>
                </div>
              </div>

              {result.recommendations.length > 0 && (
                <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded-lg">
                  <p className="font-bold text-amber-400 mb-2">Recommendations:</p>
                  <ul className="space-y-1">
                    {result.recommendations.map((rec, i) => (
                      <li key={i} className="text-sm text-gray-300 flex items-center gap-2">
                        <TrendingDown className="w-3 h-3 text-amber-400" /> {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <Button className="w-full bg-green-600 hover:bg-green-700">
                <Leaf className="mr-2 w-4 h-4" /> Download Report
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
