import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ShieldCheck, Zap, MapPin, Fuel, ChevronLeft, ChevronRight } from 'lucide-react';
import img1 from '@assets/generated_images/roadside_breakdown_assistance_scene.png';
import img2 from '@assets/generated_images/ai_vehicle_dashboard_analytics.png';
import img3 from '@assets/generated_images/ai_safety_map_navigation_system.png';
import img4 from '@assets/generated_images/ai_mechanic_diagnostics_service.png';
import img5 from '@assets/generated_images/highway_safety_and_prevention.png';
import img6 from '@assets/generated_images/emergency_response_control_center.png';

const heroImages = [img1, img2, img3, img4, img5, img6];

export default function LandingPage() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Auto-rotate images every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const goToPrevious = () => {
    setCurrentImageIndex((prev) => (prev - 1 + heroImages.length) % heroImages.length);
  };

  const goToNext = () => {
    setCurrentImageIndex((prev) => (prev + 1) % heroImages.length);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Hero Section */}
      <div className="relative min-h-screen flex items-center justify-center overflow-hidden group">
        {/* Background Image with Overlay - Auto-rotating */}
        <div className="absolute inset-0 z-0">
          {heroImages.map((img, index) => (
            <img
              key={index}
              src={img}
              alt={`OnRoad Feature ${index + 1}`}
              className={`absolute w-full h-full object-cover transition-opacity duration-1000 ${
                index === currentImageIndex ? 'opacity-100' : 'opacity-0'
              }`}
            />
          ))}
          <div className="absolute inset-0 bg-gradient-to-b from-background/85 via-background/60 to-background/90" />
        </div>

        {/* Navigation Buttons */}
        <button
          onClick={goToPrevious}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <div className="p-3 rounded-full bg-white/20 hover:bg-white/40 backdrop-blur-sm text-white transition-all">
            <ChevronLeft className="w-6 h-6" />
          </div>
        </button>

        <button
          onClick={goToNext}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <div className="p-3 rounded-full bg-white/20 hover:bg-white/40 backdrop-blur-sm text-white transition-all">
            <ChevronRight className="w-6 h-6" />
          </div>
        </button>

        {/* Image Indicators */}
        <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 z-20 flex gap-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentImageIndex(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentImageIndex
                  ? 'bg-primary w-8'
                  : 'bg-white/40 hover:bg-white/60'
              }`}
              aria-label={`Go to image ${index + 1}`}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-6 animate-slide-up drop-shadow-2xl">
            ON<span className="text-primary">ROAD</span> ASSISTANCE
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto animate-slide-up" style={{ animationDelay: '0.2s' }}>
            AI-Powered Smart Emergency Breakdown & Fuel Assistance System.
            <br/> <span className="text-primary font-semibold">Anytime. Anywhere.</span>
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <Link to="/login">
              <Button size="lg" className="w-full sm:w-auto text-lg px-8 py-6 bg-primary hover:bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.5)] transition-all hover:scale-105">
                Login Now
              </Button>
            </Link>
            <Link to="/signup">
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg px-8 py-6 bg-white/5 border-white/20 text-white hover:bg-white/10 hover:text-white backdrop-blur-md transition-all hover:scale-105">
                Sign Up
              </Button>
            </Link>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce text-white/50">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center p-1">
            <div className="w-1 h-3 bg-primary rounded-full" />
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-24 bg-background relative z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">Why Choose OnRoad?</h2>
            <p className="text-gray-400">Advanced technology meets roadside reliability.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <ShieldCheck className="w-10 h-10 text-primary" />,
                title: "Emergency Help",
                desc: "Instant location-based breakdown assistance dispatch."
              },
              {
                icon: <Zap className="w-10 h-10 text-yellow-400" />,
                title: "AI Assistant",
                desc: "Smart chatbot diagnosis before a mechanic arrives."
              },
              {
                icon: <MapPin className="w-10 h-10 text-red-400" />,
                title: "Mechanic Finder",
                desc: "Locate and book nearby trusted mechanics instantly."
              },
              {
                icon: <Fuel className="w-10 h-10 text-green-400" />,
                title: "Fuel & FASTag",
                desc: "Smart fuel monitoring and toll payment management."
              }
            ].map((feature, index) => (
              <div key={index} className="glass-card p-8 rounded-xl hover:bg-white/5 transition-colors group">
                <div className="mb-4 p-3 bg-white/5 rounded-lg w-fit group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
