import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { AlertTriangle, Radio, Volume2, Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AmbulanceDetectorAI() {
  const { toast } = useToast();
  const [sirenToggle, setSirenToggle] = useState(true);
  const [vibrationLevel, setVibrationLevel] = useState(3);
  const [microMovement, setMicroMovement] = useState(2);
  const [detection, setDetection] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const analyzeAmbulance = () => {
    setAnalyzing(true);
    setTimeout(() => {
      const sirenScore = sirenToggle ? 40 : 0;
      const vibrationScore = vibrationLevel * 8;
      const movementScore = microMovement * 6;
      
      const totalScore = sirenScore + vibrationScore + movementScore;
      
      let status = 'No ambulance detected';
      let probability = 'Low (< 20%)';
      let color = 'green';
      let recommendation = '🚗 Continue normal driving. No emergency vehicle nearby.';

      if (totalScore < 40) {
        status = 'No ambulance detected';
        probability = 'Low (< 20%)';
        color = 'green';
        recommendation = '✓ No emergency signals detected. Safe to continue.';
      } else if (totalScore < 70) {
        status = 'Ambulance Possibly Near';
        probability = 'Medium (40-60%)';
        color = 'yellow';
        recommendation = '⚠️ Possible emergency vehicle. Stay alert and ready to move.';
      } else {
        status = 'High Probability of Emergency Vehicle';
        probability = 'High (70%+)';
        color = 'red';
        recommendation = '🚑 AMBULANCE LIKELY NEARBY! Move to safe location. Clear lane. Check all mirrors.';
      }

      setDetection({
        status,
        probability,
        color,
        recommendation,
        details: {
          sirenDetected: sirenToggle ? 'Yes - Echo siren detected' : 'No - No audio signal',
          roadVibration: `${vibrationLevel}/10 - ${vibrationLevel > 6 ? 'Strong vibrations' : vibrationLevel > 3 ? 'Moderate vibrations' : 'Low vibrations'}`,
          microMovement: `${microMovement}/10 - ${microMovement > 6 ? 'Significant vehicle movement' : microMovement > 3 ? 'Noticeable movement' : 'Minimal movement'}`,
          estimatedDistance: totalScore > 70 ? '300-500 meters' : totalScore > 40 ? '500-1000 meters' : '>1000 meters'
        }
      });

      toast({
        title: "Ambulance Detection Complete",
        description: status
      });
      setAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12 relative">
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-b from-blue-600/20 to-transparent rounded-full blur-3xl" />
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent mb-3">
            🚑 AI Blind Spot Ambulance Detector
          </h1>
          <p className="text-gray-400">Echo siren & vibration detection for emergency vehicles</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <Card className="glass-card border-blue-500/30 lg:col-span-1 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-transparent" />
          <CardHeader className="relative z-10">
            <CardTitle className="text-white flex items-center gap-2">
              <Radio className="w-5 h-5 text-blue-400" />
              Detection Sensors
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 relative z-10">
            <form onSubmit={(e) => { e.preventDefault(); analyzeAmbulance(); }} className="space-y-4">
              {/* Siren Detection Toggle */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex items-center gap-3">
                  <input 
                    type="checkbox"
                    checked={sirenToggle}
                    onChange={(e) => setSirenToggle(e.target.checked)}
                    className="w-5 h-5 rounded cursor-pointer"
                  />
                  <span>🔊 Echo Siren Detected</span>
                </label>
                <p className="text-xs text-gray-400 ml-8">Check if siren audio is present</p>
              </div>

              {/* Road Vibration */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex justify-between">
                  <span>📳 Road Vibration Level</span>
                  <span className="text-blue-400 font-bold">{vibrationLevel}/10</span>
                </label>
                <Slider 
                  value={[vibrationLevel]} 
                  onValueChange={(val) => setVibrationLevel(val[0])}
                  min={0}
                  max={10}
                />
                <p className="text-xs text-gray-400">
                  {vibrationLevel < 3 ? 'Low vibration' : vibrationLevel < 7 ? 'Moderate vibration' : 'Strong vibration - Emergency vehicle likely'}
                </p>
              </div>

              {/* Micro Movement */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex justify-between">
                  <span>🚗 Micro-Movement Detection</span>
                  <span className="text-blue-400 font-bold">{microMovement}/10</span>
                </label>
                <Slider 
                  value={[microMovement]} 
                  onValueChange={(val) => setMicroMovement(val[0])}
                  min={0}
                  max={10}
                />
                <p className="text-xs text-gray-400">
                  Traffic patterns indicating emergency vehicle approach
                </p>
              </div>

              <div className="h-px bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />

              <Button 
                type="submit"
                className="w-full h-11 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold"
                disabled={analyzing}
              >
                {analyzing ? (
                  <>
                    <span className="animate-spin mr-2">⚙️</span>
                    Scanning...
                  </>
                ) : (
                  <>
                    <Radio className="w-4 h-4 mr-2" /> Scan for Ambulance
                  </>
                )}
              </Button>
            </form>

            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <p className="text-xs text-gray-400">ℹ️ This sensor helps detect ambulances and emergency vehicles approaching from blind spots using audio, vibration, and traffic analysis.</p>
            </div>
          </CardContent>
        </Card>

        {/* Detection Results */}
        {detection && (
          <Card className={`glass-card border-${detection.color}-500/30 lg:col-span-2 relative overflow-hidden animate-fade-in`}>
            <div className={`absolute inset-0 bg-gradient-to-br from-${detection.color}-600/10 to-transparent`} />
            <CardHeader className="relative z-10">
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-400" />
                Detection Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 relative z-10">
              {/* Status Cards */}
              <div className="grid grid-cols-2 gap-4">
                <div className={`p-6 rounded-lg bg-${detection.color}-500/10 border border-${detection.color}-500/30`}>
                  <p className="text-gray-400 text-sm mb-2">Detection Status</p>
                  <p className={`text-xl font-bold text-${detection.color}-400`}>{detection.status}</p>
                </div>
                <div className="p-6 rounded-lg bg-purple-500/10 border border-purple-500/30">
                  <p className="text-gray-400 text-sm mb-2">Probability</p>
                  <p className="text-xl font-bold text-purple-400">{detection.probability}</p>
                </div>
              </div>

              {/* Alert Bar */}
              <div className={`p-4 rounded-lg bg-${detection.color}-500/10 border-2 border-${detection.color}-500/50`}>
                <p className={`text-lg font-bold text-${detection.color}-400`}>{detection.recommendation}</p>
              </div>

              {/* Sensor Details */}
              <div className="space-y-3">
                <p className="font-bold text-white text-sm">📊 Sensor Analysis:</p>
                {Object.entries(detection.details).map(([key, value]) => (
                  <div key={key} className="p-3 bg-white/5 border border-white/10 rounded-lg flex justify-between items-center">
                    <p className="text-sm text-gray-400">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                    <p className="text-sm font-bold text-cyan-400">{value}</p>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <Button className={`h-10 bg-${detection.color}-600 hover:bg-${detection.color}-700 text-white font-bold`}>
                  {detection.color === 'red' ? '🚨 MOVE NOW' : '⚠️ Stay Alert'}
                </Button>
                <Button variant="outline" className="h-10 border-white/20 text-white hover:bg-white/10">
                  📍 Report Location
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
