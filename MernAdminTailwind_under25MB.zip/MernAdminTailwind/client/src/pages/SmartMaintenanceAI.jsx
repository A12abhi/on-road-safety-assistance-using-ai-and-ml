import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Wrench, AlertTriangle, CheckCircle, TrendingUp, Zap, Calendar } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function SmartMaintenanceAI() {
  const { toast } = useToast();
  const [prediction, setPrediction] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const handleAnalyze = (e) => {
    e.preventDefault();
    setAnalyzing(true);
    setPrediction(null);

    const formData = new FormData(e.target);
    const mileage = parseInt(formData.get('mileage'));
    const serviceHistory = formData.get('service');

    setTimeout(() => {
      let components = [];
      let urgencyScore = 40;

      if (mileage > 80000) {
        components.push({ name: 'Engine Oil', daysLeft: 15, urgency: 'high', cost: '₹800-1200' });
        urgencyScore += 20;
      }
      if (mileage > 60000) {
        components.push({ name: 'Air Filter', daysLeft: 30, urgency: 'medium', cost: '₹400-800' });
        urgencyScore += 10;
      }
      if (mileage > 50000) {
        components.push({ name: 'Brake Pads', daysLeft: 45, urgency: 'medium', cost: '₹3000-6000' });
        urgencyScore += 15;
      }
      if (serviceHistory !== 'recent') {
        components.push({ name: 'Battery Health Check', daysLeft: 20, urgency: 'high', cost: '₹0 (Diagnostic)' });
        urgencyScore += 10;
      }
      if (mileage > 40000) {
        components.push({ name: 'Suspension Inspection', daysLeft: 60, urgency: 'low', cost: '₹2000-4000' });
      }

      urgencyScore = Math.min(95, urgencyScore);

      setPrediction({
        urgencyScore,
        totalCost: '₹6,200-12,000 (all components)',
        components,
        nextServiceDue: '5 days',
        estimatedSavings: '₹8,500-15,000 (by fixing early)',
        aiRecommendation: urgencyScore > 70 ? 'Schedule service ASAP' : 'Book within 2 weeks'
      });

      toast({
        title: "AI Analysis Complete",
        description: `${components.length} maintenance items detected. Urgency: ${urgencyScore}%`
      });

      setAnalyzing(false);
    }, 2500);
  };

  const handleScheduleService = () => {
    toast({
      title: "Service Scheduled",
      description: "Appointment confirmed for next available date. Check your email for details."
    });
  };

  const handleDownloadReport = () => {
    toast({
      title: "Report Downloaded",
      description: "Maintenance prediction report saved to your device."
    });
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-6xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-display font-bold text-white flex items-center justify-center gap-3">
          <Wrench className="w-8 h-8 text-blue-500" />
          AI Smart Maintenance Predictor
        </h1>
        <p className="text-gray-400">Predict maintenance needs before breakdowns happen</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Input Form */}
        <Card className="glass-card border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-white">Vehicle Assessment</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAnalyze} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Current Mileage (km)</Label>
                <Input 
                  name="mileage" 
                  type="number" 
                  placeholder="85000" 
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Last Service</Label>
                <select 
                  name="service"
                  defaultValue="recent"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 text-white rounded-md focus:border-blue-500/50 outline-none"
                >
                  <option value="recent">Within 1 month</option>
                  <option value="2months">1-2 months ago</option>
                  <option value="3months">3-6 months ago</option>
                  <option value="old">More than 6 months</option>
                </select>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700" 
                disabled={analyzing}
              >
                {analyzing ? "Analyzing..." : "Run AI Prediction"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Prediction Results */}
        {prediction && (
          <Card className="glass-card border-blue-500/30 md:col-span-2 animate-fade-in">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-white">Maintenance Prediction</CardTitle>
                <div className={`px-3 py-1 rounded-full text-sm font-bold ${
                  prediction.urgencyScore > 70 ? 'bg-red-500/20 text-red-400' : 
                  prediction.urgencyScore > 50 ? 'bg-amber-500/20 text-amber-400' :
                  'bg-green-500/20 text-green-400'
                }`}>
                  {prediction.urgencyScore}% Urgent
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white/5 p-4 rounded-lg text-center">
                  <Calendar className="w-5 h-5 mx-auto mb-2 text-blue-400" />
                  <p className="text-xs text-gray-500">Service Due</p>
                  <p className="text-lg font-bold text-white">{prediction.nextServiceDue}</p>
                </div>
                <div className="bg-white/5 p-4 rounded-lg text-center">
                  <Wrench className="w-5 h-5 mx-auto mb-2 text-blue-400" />
                  <p className="text-xs text-gray-500">Est. Cost</p>
                  <p className="text-lg font-bold text-white">{prediction.totalCost}</p>
                </div>
                <div className="bg-white/5 p-4 rounded-lg text-center">
                  <TrendingUp className="w-5 h-5 mx-auto mb-2 text-green-400" />
                  <p className="text-xs text-gray-500">Potential Save</p>
                  <p className="text-lg font-bold text-green-400">{prediction.estimatedSavings}</p>
                </div>
              </div>

              {/* Components Table */}
              <div className="space-y-3">
                <h4 className="font-bold text-white">Maintenance Items Detected:</h4>
                {prediction.components.map((comp, i) => (
                  <div key={i} className={`p-4 rounded-lg border ${
                    comp.urgency === 'high' ? 'bg-red-500/10 border-red-500/30' :
                    comp.urgency === 'medium' ? 'bg-amber-500/10 border-amber-500/30' :
                    'bg-green-500/10 border-green-500/30'
                  }`}>
                    <div className="flex justify-between items-start mb-2">
                      <h5 className="font-bold text-white">{comp.name}</h5>
                      <span className={`text-xs px-2 py-1 rounded font-bold uppercase ${
                        comp.urgency === 'high' ? 'bg-red-500/20 text-red-400' :
                        comp.urgency === 'medium' ? 'bg-amber-500/20 text-amber-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {comp.urgency}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs text-gray-300">
                      <div>
                        <p className="text-gray-500">Action Required:</p>
                        <p className="font-bold">{comp.daysLeft} days</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Estimated Cost:</p>
                        <p className="font-bold">{comp.cost}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* AI Recommendation */}
              <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-lg">
                <p className="text-blue-400 font-bold text-sm mb-2 flex items-center gap-2">
                  <Zap className="w-4 h-4" /> AI Recommendation
                </p>
                <p className="text-white font-bold">{prediction.aiRecommendation}</p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button onClick={handleScheduleService} className="flex-1 bg-blue-600 hover:bg-blue-700">
                  Schedule Service
                </Button>
                <Button onClick={handleDownloadReport} variant="outline" className="flex-1 border-white/10 hover:bg-white/10 text-white">
                  Download Report
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Benefits Section */}
      {!prediction && (
        <Card className="glass-card border-white/10 mt-8">
          <CardHeader>
            <CardTitle className="text-white">Why Use AI Maintenance Prediction?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { icon: '🛡️', title: 'Avoid Breakdowns', desc: 'Fix issues before they become emergencies on the road' },
                { icon: '💰', title: 'Save Money', desc: 'Early maintenance prevents expensive repairs and total failures' },
                { icon: '⏱️', title: 'Save Time', desc: 'Plan your service visits instead of emergency situations' }
              ].map((benefit, i) => (
                <div key={i} className="text-center">
                  <div className="text-4xl mb-3">{benefit.icon}</div>
                  <h4 className="font-bold text-white mb-2">{benefit.title}</h4>
                  <p className="text-sm text-gray-400">{benefit.desc}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
