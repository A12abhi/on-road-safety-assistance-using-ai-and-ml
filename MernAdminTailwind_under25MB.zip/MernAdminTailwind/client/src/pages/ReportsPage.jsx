import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Download, Fuel, Wind, CreditCard, Shield, Calendar, TrendingDown } from 'lucide-react';
import jsPDF from 'jspdf';
import { useToast } from '@/hooks/use-toast';

export default function ReportsPage() {
  const { toast } = useToast();
  const [downloadingId, setDownloadingId] = useState(null);

  const [reportsList, setReportsList] = React.useState([
    {
      id: 'fuel-001',
      type: 'Fuel Report',
      icon: Fuel,
      color: 'yellow',
      date: '2024-12-01',
      data: {
        title: 'Monthly Fuel Consumption Report',
        distance: '1,240 km',
        fuelConsumed: '62.5 L',
        avgMileage: '19.8 km/L',
        estimatedCost: '₹4,687',
        recommendations: [
          'Maintain optimal tire pressure for 3% efficiency gain',
          'Reduce idling time - saves 10% fuel',
          'Drive at steady 60-70 km/h for best efficiency'
        ]
      }
    }
  ]);

  React.useEffect(() => {
    // Load from localStorage
    const reports = [];
    
    const insuranceReports = JSON.parse(localStorage.getItem('insuranceReports') || '[]');
    insuranceReports.forEach(report => {
      reports.push({
        id: `insurance-${Date.now()}`,
        type: 'Insurance Registration',
        icon: Shield,
        color: 'purple',
        date: report.registeredDate,
        data: {
          title: `${report.plan} - ${report.duration}`,
          policyNumber: report.policyNumber,
          vehicleType: report.vehicleType,
          coverage: '₹5,00,000',
          recommendations: ['Policy active', 'Coverage active', 'Renew before expiry']
        }
      });
    });

    const fastagReports = JSON.parse(localStorage.getItem('fastagReports') || '[]');
    fastagReports.forEach(report => {
      reports.push({
        id: `fastag-${Date.now()}`,
        type: 'FASTag Registration',
        icon: CreditCard,
        color: 'blue',
        date: report.registeredDate,
        data: {
          title: `${report.plan} Plan - ${report.duration}`,
          fastagId: report.fastagId,
          vehicleType: report.vehicleType,
          initialBalance: '₹500',
          recommendations: ['Account active', 'Recharge when needed', 'Monitor transactions']
        }
      });
    });

    const emissionReports = JSON.parse(localStorage.getItem('emissionReports') || '[]');
    emissionReports.forEach(report => {
      reports.push({
        id: `emission-${Date.now()}`,
        type: 'Emission Certificate',
        icon: Wind,
        color: 'green',
        date: report.testDate,
        data: {
          title: report.passed ? 'Test Passed ✓' : 'Test Failed ✗',
          certificate: report.certificateNumber,
          nextTest: report.nextTestDate,
          co: `${report.co}% ${report.co <= 1.0 ? 'PASS' : 'FAIL'}`,
          hc: `${report.hc} ppm ${report.hc <= 150 ? 'PASS' : 'FAIL'}`,
          recommendations: [
            'Vehicle emission compliant',
            'Next test due on ' + report.nextTestDate,
            'Maintain regular servicing'
          ]
        }
      });
    });

    setReportsList([...reportsList, ...reports]);
  }, []);

  const generatePDF = (report) => {
    setDownloadingId(report.id);
    setTimeout(() => {
      const pdf = new jsPDF();
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      
      // Header
      pdf.setFillColor(100, 50, 200);
      pdf.rect(0, 0, pageWidth, 40, 'F');
      
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(24);
      pdf.text('OnRoad 360° Safety', 20, 25);
      
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(14);
      pdf.text(report.data.title, 20, 55);
      
      pdf.setFontSize(10);
      pdf.setTextColor(100, 100, 100);
      pdf.text(`Generated: ${new Date().toLocaleDateString()}`, 20, 65);
      
      let yPosition = 80;
      
      // Report Details
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(11);
      pdf.setFont(undefined, 'bold');
      pdf.text('Report Details:', 20, yPosition);
      yPosition += 10;
      
      pdf.setFont(undefined, 'normal');
      Object.entries(report.data).forEach(([key, value]) => {
        if (key !== 'title' && key !== 'recommendations') {
          if (typeof value === 'object') {
            pdf.text(`${key}:`, 20, yPosition);
            yPosition += 7;
            Object.entries(value).forEach(([subKey, subValue]) => {
              pdf.text(`  ${subKey}: ${subValue}`, 25, yPosition);
              yPosition += 7;
              if (yPosition > 260) {
                pdf.addPage();
                yPosition = 20;
              }
            });
          } else {
            pdf.text(`${key}: ${value}`, 20, yPosition);
            yPosition += 7;
          }
        }
        if (yPosition > 260) {
          pdf.addPage();
          yPosition = 20;
        }
      });
      
      yPosition += 5;
      pdf.setFont(undefined, 'bold');
      pdf.text('AI Recommendations:', 20, yPosition);
      yPosition += 10;
      
      pdf.setFont(undefined, 'normal');
      report.data.recommendations.forEach((rec, i) => {
        pdf.text(`${i + 1}. ${rec}`, 20, yPosition);
        yPosition += 8;
        if (yPosition > 260) {
          pdf.addPage();
          yPosition = 20;
        }
      });
      
      pdf.save(`${report.type}-${report.date}.pdf`);
      
      toast({
        title: "Report Downloaded",
        description: `${report.type} saved as PDF`
      });
      
      setDownloadingId(null);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12 relative">
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-b from-blue-600/20 to-transparent rounded-full blur-3xl" />
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-3">
            📊 Your Reports & History
          </h1>
          <p className="text-gray-400">Download and view all your vehicle & safety reports</p>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {reportsList.map((report) => {
          const Icon = report.icon;
          return (
            <Card key={report.id} className="glass-card border-white/10 hover:border-white/20 transition-all relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-white/5 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <CardHeader className="relative z-10">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg bg-${report.color}-500/10`}>
                      <Icon className={`w-5 h-5 text-${report.color}-400`} />
                    </div>
                    <div>
                      <CardTitle className="text-white text-base">{report.type}</CardTitle>
                      <p className="text-xs text-gray-400 mt-1">📅 {report.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-xs font-bold text-${report.color}-400`}>Ready</p>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4 relative z-10">
                <p className="text-sm text-white font-semibold">{report.data.title}</p>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(report.data)
                    .filter(([key]) => !['title', 'recommendations', 'pollutants', 'coverage'].includes(key) && typeof report.data[key] === 'string')
                    .slice(0, 2)
                    .map(([key, value]) => (
                      <div key={key} className="p-2 bg-white/5 rounded-lg border border-white/10">
                        <p className="text-xs text-gray-400 capitalize">{key}</p>
                        <p className="text-sm font-bold text-white mt-1">{value}</p>
                      </div>
                    ))
                  }
                </div>

                {/* Recommendations Preview */}
                <div className="p-3 bg-white/5 border border-white/10 rounded-lg">
                  <p className="text-xs text-gray-400 mb-2">💡 Key Recommendations:</p>
                  <ul className="space-y-1">
                    {report.data.recommendations.slice(0, 2).map((rec, i) => (
                      <li key={i} className="text-xs text-gray-300 leading-relaxed">• {rec}</li>
                    ))}
                  </ul>
                </div>

                {/* Download Button */}
                <Button 
                  onClick={() => generatePDF(report)}
                  className={`w-full h-10 bg-gradient-to-r from-${report.color}-600 to-${report.color}-700 hover:from-${report.color}-700 hover:to-${report.color}-800 text-white font-bold transition-all`}
                  disabled={downloadingId === report.id}
                >
                  {downloadingId === report.id ? (
                    <>
                      <span className="animate-spin mr-2">⚙️</span>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" /> Download PDF
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Reports Summary Card */}
      <Card className="glass-card border-white/10 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-purple-600/5 to-transparent" />
        <CardHeader className="relative z-10">
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" /> Reports Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-4 gap-6 relative z-10">
          {[
            { label: 'Total Reports', value: '4', icon: '📊' },
            { label: 'Reports This Month', value: '3', icon: '📅' },
            { label: 'Downloaded', value: '12', icon: '💾' },
            { label: 'Last Generated', value: 'Today', icon: '⏱️' }
          ].map((stat, i) => (
            <div key={i} className="p-4 bg-white/5 border border-white/10 rounded-lg">
              <p className="text-3xl mb-2">{stat.icon}</p>
              <p className="text-gray-400 text-sm">{stat.label}</p>
              <p className="text-2xl font-bold text-white mt-2">{stat.value}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
