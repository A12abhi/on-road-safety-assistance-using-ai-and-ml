import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { AlertTriangle, Navigation, Zap, Shield, TrendingUp, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AccidentEscapeAI() {
  const { toast } = useToast();
  const [speed, setSpeed] = useState(60);
  const [trafficLevel, setTrafficLevel] = useState('moderate');
  const [roadType, setRoadType] = useState('highway');
  const [escapeStrategies, setEscapeStrategies] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const [toggles, setToggles] = useState({
    uTurnAvailable: true,
    serviceRoad: true,
    shoulderLane: true,
    internalRoads: false
  });

  const generateStrategies = () => {
    setAnalyzing(true);
    setTimeout(() => {
      const strategies = [
        {
          id: 1,
          title: 'Emergency Lane Change + Shoulder Brake',
          steps: [
            '1. Signal left immediately (hazard lights ON)',
            '2. Check mirror for safe lane',
            '3. Smooth lane change to left',
            '4. Gradually brake on shoulder',
            '5. Complete stop in 30-40 meters'
          ],
          safetyRating: 95,
          timeToExecute: '15-20 sec',
          conditions: 'Best for highway emergencies'
        },
        {
          id: 2,
          title: toggles.uTurnAvailable ? 'U-Turn Escape Route' : 'Reverse + Controlled Exit',
          steps: toggles.uTurnAvailable ? [
            '1. Signal U-turn immediately',
            '2. Check oncoming traffic',
            '3. Execute controlled U-turn',
            '4. Drive to safe location',
            '5. Call emergency services'
          ] : [
            '1. Brake to controlled speed',
            '2. Activate reverse carefully',
            '3. Navigate to service road',
            '4. Exit to safe area',
            '5. Assess vehicle damage'
          ],
          safetyRating: toggles.uTurnAvailable ? 88 : 75,
          timeToExecute: '25-35 sec',
          conditions: toggles.uTurnAvailable ? 'Requires open U-turn pocket' : 'Low-speed alternative'
        },
        {
          id: 3,
          title: toggles.serviceRoad ? 'Service Road Diversion' : 'Forward Deceleration',
          steps: toggles.serviceRoad ? [
            '1. Identify service road ahead',
            '2. Signal right exit',
            '3. Controlled deceleration',
            '4. Enter service road safely',
            '5. Stop vehicle on shoulder'
          ] : [
            '1. Maintain current lane',
            '2. Progressive brake application',
            '3. Flash hazard lights',
            '4. Alert following vehicles',
            '5. Gradual deceleration to stop'
          ],
          safetyRating: toggles.serviceRoad ? 92 : 70,
          timeToExecute: '20-30 sec',
          conditions: toggles.serviceRoad ? 'Safest route' : 'Requires following traffic awareness'
        },
        {
          id: 4,
          title: toggles.shoulderLane ? 'Shoulder Emergency Stop' : 'Internal Road Escape',
          steps: toggles.shoulderLane ? [
            '1. Signal right immediately',
            '2. Move to shoulder gradually',
            '3. Reduce speed progressively',
            '4. Complete stop on shoulder',
            '5. Engage parking brake'
          ] : [
            '1. Look for internal roads',
            '2. Signal direction clearly',
            '3. Execute smooth turn',
            '4. Proceed to safe zone',
            '5. Stop and assess'
          ],
          safetyRating: toggles.shoulderLane ? 90 : 80,
          timeToExecute: '15-25 sec',
          conditions: toggles.shoulderLane ? 'Immediate action' : 'Requires route knowledge'
        }
      ];

      setEscapeStrategies(strategies);
      toast({
        title: "Escape Strategies Generated",
        description: `${strategies.length} emergency escape routes calculated by AI`
      });
      setAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12 relative">
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-b from-red-600/20 to-transparent rounded-full blur-3xl" />
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-red-400 via-pink-400 to-red-400 bg-clip-text text-transparent mb-3">
            🚨 AI Accident Escape Route Generator
          </h1>
          <p className="text-gray-400">Real-time emergency escape strategy simulator with AI analysis</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-8">
        {/* Input Panel */}
        <Card className="glass-card border-red-500/30 lg:col-span-1 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 to-transparent" />
          <CardHeader className="relative z-10">
            <CardTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              Emergency Scenario
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 relative z-10">
            <form onSubmit={(e) => { e.preventDefault(); generateStrategies(); }} className="space-y-4">
              {/* Current Speed */}
              <div className="space-y-3">
                <label className="text-gray-300 font-semibold flex justify-between">
                  <span>Current Speed</span>
                  <span className="text-red-400 font-bold">{speed} km/h</span>
                </label>
                <Slider 
                  value={[speed]} 
                  onValueChange={(val) => setSpeed(val[0])}
                  min={10}
                  max={150}
                  className="w-full"
                />
              </div>

              {/* Traffic Level */}
              <div className="space-y-2">
                <label className="text-gray-300 font-semibold">Traffic Level</label>
                <select 
                  value={trafficLevel}
                  onChange={(e) => setTrafficLevel(e.target.value)}
                  className="w-full bg-white/5 border border-red-500/30 text-white rounded-lg h-10 px-3"
                >
                  <option value="light">Light (30% congestion)</option>
                  <option value="moderate">Moderate (50% congestion)</option>
                  <option value="heavy">Heavy (80% congestion)</option>
                  <option value="critical">Critical (95% congestion)</option>
                </select>
              </div>

              {/* Road Type */}
              <div className="space-y-2">
                <label className="text-gray-300 font-semibold">Road Type</label>
                <select 
                  value={roadType}
                  onChange={(e) => setRoadType(e.target.value)}
                  className="w-full bg-white/5 border border-red-500/30 text-white rounded-lg h-10 px-3"
                >
                  <option value="highway">Highway</option>
                  <option value="urban">Urban Road</option>
                  <option value="rural">Rural Road</option>
                  <option value="construction">Construction Zone</option>
                </select>
              </div>

              <div className="h-px bg-gradient-to-r from-transparent via-red-500/50 to-transparent" />

              {/* Route Options */}
              <div className="space-y-3">
                <p className="text-gray-300 font-semibold text-sm">Available Escape Routes:</p>
                {[
                  { key: 'uTurnAvailable', label: 'U-Turn Pocket Available' },
                  { key: 'serviceRoad', label: 'Service Road Nearby' },
                  { key: 'shoulderLane', label: 'Safe Shoulder Lane' },
                  { key: 'internalRoads', label: 'Internal Roads' }
                ].map(opt => (
                  <label key={opt.key} className="flex items-center gap-3 cursor-pointer p-2 hover:bg-white/5 rounded-lg transition-colors">
                    <input 
                      type="checkbox" 
                      checked={toggles[opt.key]}
                      onChange={(e) => setToggles(prev => ({ ...prev, [opt.key]: e.target.checked }))}
                      className="w-4 h-4 rounded"
                    />
                    <span className="text-sm text-gray-300">{opt.label}</span>
                  </label>
                ))}
              </div>

              <Button 
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white font-bold text-base"
                disabled={analyzing}
              >
                {analyzing ? (
                  <>
                    <span className="animate-spin mr-2">⚙️</span>
                    Analyzing Scenarios...
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5 mr-2" /> Generate Escape Routes
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Strategies Grid */}
        {escapeStrategies && (
          <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
            {escapeStrategies.map((strategy) => (
              <Card key={strategy.id} className="glass-card border-green-500/30 relative overflow-hidden group hover:border-green-500/50 transition-all">
                <div className="absolute inset-0 bg-gradient-to-br from-green-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-all" />
                <CardHeader className="relative z-10 pb-3">
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-white text-base">{strategy.title}</CardTitle>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-400">{strategy.safetyRating}%</p>
                      <p className="text-xs text-gray-400">Safety Rating</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3 relative z-10">
                  <div className="w-full bg-white/10 rounded-full h-2">
                    <div 
                      className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"
                      style={{ width: strategy.safetyRating + '%' }}
                    />
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs text-gray-400 font-bold">📋 STEPS:</p>
                    {strategy.steps.map((step, i) => (
                      <p key={i} className="text-xs text-gray-300 leading-relaxed">{step}</p>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
                    <div>
                      <p className="text-xs text-gray-400">⏱️ Time</p>
                      <p className="text-sm font-bold text-white">{strategy.timeToExecute}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">📍 Condition</p>
                      <p className="text-xs text-green-400 font-bold">{strategy.conditions}</p>
                    </div>
                  </div>

                  <Button className="w-full h-9 bg-green-600 hover:bg-green-700 text-white text-sm font-bold">
                    <Navigation className="w-4 h-4 mr-2" /> Activate Route
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Emergency Tips */}
      {!escapeStrategies && (
        <Card className="glass-card border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-white">⚠️ Emergency Guidelines</CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <p className="font-bold text-blue-400">DO's</p>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>✓ Signal immediately</li>
                <li>✓ Check mirrors</li>
                <li>✓ Gradual movements</li>
                <li>✓ Maintain control</li>
              </ul>
            </div>
            <div className="space-y-2">
              <p className="font-bold text-yellow-400">AVOID</p>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>✗ Panic braking</li>
                <li>✗ Sudden movements</li>
                <li>✗ High-speed turns</li>
                <li>✗ Wrong-way lanes</li>
              </ul>
            </div>
            <div className="space-y-2">
              <p className="font-bold text-green-400">AFTER</p>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>✓ Call emergency (112)</li>
                <li>✓ Enable hazard lights</li>
                <li>✓ Exit vehicle safely</li>
                <li>✓ Document scene</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
