import React, { useState, useEffect } from 'react';
import { Heart, AlertCircle, Smile, Volume2, Clock } from 'lucide-react';
import { Card } from '@/components/ui/card';

export default function AntiRageDrivingMode() {
  const [stressLevel, setStressLevel] = useState(20); // 0-100
  const [isStressed, setIsStressed] = useState(false);
  const [calmedDown, setCalmedDown] = useState(false);
  const [hornCount, setHornCount] = useState(0);
  const [accelerationSpikes, setAccelerationSpikes] = useState(0);
  const [mapChecks, setMapChecks] = useState(0);
  const [mobileUsage, setMobileUsage] = useState(0);
  const [aiMessage, setAiMessage] = useState("Welcome to Anti-Rage Driving Mode. I'm monitoring your driving behavior to keep you calm and safe.");
  const [relaxMode, setRelaxMode] = useState(false);

  // Simulate stress detection
  useEffect(() => {
    const totalStress = (hornCount * 15) + (accelerationSpikes * 20) + (mapChecks * 10) + (mobileUsage * 25);
    const calculatedStress = Math.min(100, totalStress);
    setStressLevel(calculatedStress);

    if (calculatedStress > 60 && !isStressed) {
      setIsStressed(true);
      setRelaxMode(true);
      setAiMessage("I detect you're under stress. Please don't drive now. Keep steady control. No rush. I'm here with you. Take a deep breath.");
      speakMessage("I detect you are under stress. Please do not drive now. Keep steady control. No rush. I am here with you. Take a deep breath.");
    } else if (calculatedStress <= 40 && isStressed) {
      setIsStressed(false);
      setRelaxMode(true);
      setCalmedDown(true);
    }
  }, [hornCount, accelerationSpikes, mapChecks, mobileUsage, isStressed]);

  const speakMessage = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 0.8;
      utterance.volume = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleDrivingSafe = () => {
    setCalmedDown(true);
    setRelaxMode(false);
    setAiMessage("Great! You're calm and focused now. Drive safely and smoothly. Continue your journey.");
    speakMessage("Great! You are calm and focused now. Drive safely and smoothly. Continue your journey.");
    // Reset counters
    setTimeout(() => {
      setHornCount(0);
      setAccelerationSpikes(0);
      setMapChecks(0);
      setMobileUsage(0);
      setStressLevel(0);
    }, 2000);
  };

  const handleHorn = () => {
    setHornCount(prev => prev + 1);
  };

  const handleFastAcceleration = () => {
    setAccelerationSpikes(prev => prev + 1);
  };

  const handleMapCheck = () => {
    setMapChecks(prev => prev + 1);
  };

  const handleMobileUsage = () => {
    setMobileUsage(prev => prev + 1);
  };

  const stressPercentage = (stressLevel / 100) * 100;
  const stressColor = stressLevel > 60 ? 'bg-red-500' : stressLevel > 40 ? 'bg-yellow-500' : 'bg-green-500';
  const textColor = stressLevel > 60 ? 'text-red-400' : stressLevel > 40 ? 'text-yellow-400' : 'text-green-400';

  return (
    <div className="min-h-screen bg-background pt-20 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
            <Heart className="w-8 h-8 text-pink-400" />
            Anti-Rage Driving Mode
          </h1>
          <p className="text-gray-400">AI-powered stress detection for safer driving</p>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          
          {/* Stress Level Monitor - Left Panel */}
          <div className="lg:col-span-2">
            <Card className="glass-card p-8 rounded-2xl border border-white/10 h-full">
              <div className="space-y-6">
                
                {/* Stress Level Gauge */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-white font-semibold text-lg">Stress Level</h3>
                    <span className={`text-2xl font-bold ${textColor}`}>{Math.round(stressLevel)}%</span>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full bg-white/5 rounded-full h-8 overflow-hidden border border-white/10">
                    <div
                      className={`h-full ${stressColor} transition-all duration-300 flex items-center justify-end pr-2`}
                      style={{ width: `${stressPercentage}%` }}
                    >
                      {stressPercentage > 20 && (
                        <span className="text-xs text-white font-bold">
                          {Math.round(stressLevel)}%
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Calm Interface Indicator */}
                {relaxMode && (
                  <div className="bg-blue-500/10 border border-blue-400/30 rounded-xl p-4 space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse" />
                      <span className="text-blue-300 font-semibold">CALM DRIVING MODE ACTIVE</span>
                    </div>
                    <p className="text-sm text-blue-300 leading-relaxed">
                      Simplified interface engaged. Focus on smooth driving. I'm analyzing your behavior in real-time.
                    </p>
                  </div>
                )}

                {/* AI Message Box */}
                <div className="bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-pink-400/30 rounded-xl p-5 space-y-3">
                  <div className="flex items-start gap-3">
                    <Heart className="w-5 h-5 text-pink-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-300 leading-relaxed">
                        {aiMessage}
                      </p>
                    </div>
                  </div>
                  {isStressed && (
                    <button
                      onClick={() => speakMessage(aiMessage)}
                      className="text-xs text-pink-400 hover:text-pink-300 transition-colors flex items-center gap-1"
                    >
                      <Volume2 className="w-3 h-3" />
                      Repeat
                    </button>
                  )}
                </div>
              </div>
            </Card>
          </div>

          {/* Detected Signals - Right Panel */}
          <div>
            <Card className="glass-card p-6 rounded-2xl border border-white/10 h-full">
              <h3 className="text-white font-semibold mb-4">Detected Signals</h3>
              <div className="space-y-3">
                
                {/* Harsh Horn */}
                <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                  <p className="text-xs text-gray-400 mb-1">Harsh Horn</p>
                  <p className={`text-2xl font-bold ${hornCount > 0 ? 'text-yellow-400' : 'text-gray-500'}`}>
                    {hornCount}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">+15% stress each</p>
                </div>

                {/* Fast Acceleration */}
                <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                  <p className="text-xs text-gray-400 mb-1">Fast Acceleration</p>
                  <p className={`text-2xl font-bold ${accelerationSpikes > 0 ? 'text-orange-400' : 'text-gray-500'}`}>
                    {accelerationSpikes}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">+20% stress each</p>
                </div>

                {/* Frequent Map Checking */}
                <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                  <p className="text-xs text-gray-400 mb-1">Map Checks</p>
                  <p className={`text-2xl font-bold ${mapChecks > 0 ? 'text-blue-400' : 'text-gray-500'}`}>
                    {mapChecks}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">+10% stress each</p>
                </div>

                {/* Mobile Usage */}
                <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                  <p className="text-xs text-gray-400 mb-1">Mobile Usage</p>
                  <p className={`text-2xl font-bold ${mobileUsage > 0 ? 'text-red-400' : 'text-gray-500'}`}>
                    {mobileUsage}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">+25% stress each</p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Interactive Controls */}
        <Card className="glass-card p-6 rounded-2xl border border-white/10 mb-8">
          <h3 className="text-white font-semibold mb-4">Simulate Stress Signals</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <button
              onClick={handleHorn}
              className="bg-yellow-500/10 border border-yellow-400/30 hover:bg-yellow-500/20 text-yellow-300 py-3 rounded-lg font-medium transition-all duration-300"
            >
              🔊 Harsh Horn
            </button>
            <button
              onClick={handleFastAcceleration}
              className="bg-orange-500/10 border border-orange-400/30 hover:bg-orange-500/20 text-orange-300 py-3 rounded-lg font-medium transition-all duration-300"
            >
              ⚡ Fast Acceleration
            </button>
            <button
              onClick={handleMapCheck}
              className="bg-blue-500/10 border border-blue-400/30 hover:bg-blue-500/20 text-blue-300 py-3 rounded-lg font-medium transition-all duration-300"
            >
              🗺️ Check Map
            </button>
            <button
              onClick={handleMobileUsage}
              className="bg-red-500/10 border border-red-400/30 hover:bg-red-500/20 text-red-300 py-3 rounded-lg font-medium transition-all duration-300"
            >
              📱 Mobile Usage
            </button>
          </div>
        </Card>

        {/* Calm Down Button */}
        {isStressed && (
          <Card className="glass-card p-6 rounded-2xl border border-green-400/30 bg-green-500/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Smile className="w-6 h-6 text-green-400" />
                <div>
                  <h4 className="text-white font-semibold">Ready to Drive Safely?</h4>
                  <p className="text-sm text-gray-400">Confirm when you're calm and focused</p>
                </div>
              </div>
              <button
                onClick={handleDrivingSafe}
                className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-semibold transition-all duration-300"
              >
                I'm Safe Now
              </button>
            </div>
          </Card>
        )}

        {/* Success State */}
        {calmedDown && !isStressed && (
          <Card className="glass-card p-8 rounded-2xl border border-green-400/30 bg-gradient-to-r from-green-500/10 to-emerald-500/10 text-center">
            <Heart className="w-12 h-12 text-green-400 mx-auto mb-4 animate-pulse" />
            <h3 className="text-white text-2xl font-bold mb-2">You're Ready to Drive</h3>
            <p className="text-gray-300 mb-4">Continue your journey smoothly and safely. I'll keep monitoring your well-being.</p>
            <div className="flex justify-center gap-2">
              <div className="flex items-center gap-1 text-sm text-green-400">
                <div className="w-2 h-2 bg-green-400 rounded-full" />
                Normal stress level
              </div>
              <div className="flex items-center gap-1 text-sm text-green-400">
                <div className="w-2 h-2 bg-green-400 rounded-full" />
                All systems safe
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
