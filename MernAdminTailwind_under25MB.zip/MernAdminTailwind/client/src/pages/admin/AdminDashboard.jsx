import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, AlertTriangle, Wrench, CheckCircle, MessageSquare, Settings, Send, Mail } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AdminDashboard() {
  const { toast } = useToast();
  const [stats, setStats] = useState({
    users: 0,
    requests: 0,
    mechanics: 0,
    resolved: 0
  });

  const [allUsers, setAllUsers] = useState([]);
  const [conversations, setConversations] = useState({});
  const [selectedUser, setSelectedUser] = useState(null);
  const [userActivity, setUserActivity] = useState([]);
  const [newFeature, setNewFeature] = useState("");
  const [features, setFeatures] = useState([]);
  const [mechanicMessage, setMechanicMessage] = useState("");
  const [recentRequests, setRecentRequests] = useState([]);

  useEffect(() => {
    // Load all data
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const requests = JSON.parse(localStorage.getItem('emergencyRequests') || '[]');
    const userConversations = JSON.parse(localStorage.getItem('userConversations') || '{}');
    const storedFeatures = JSON.parse(localStorage.getItem('adminFeatures') || '[]');

    setStats({
      users: users.length,
      requests: requests.length,
      mechanics: 12,
      resolved: requests.filter(r => r.status === 'Resolved').length
    });

    setAllUsers(users);
    setConversations(userConversations);
    setFeatures(storedFeatures);
    setRecentRequests(requests.slice(0, 5).reverse());
  }, []);

  const handleSelectUser = (user) => {
    setSelectedUser(user);
    setUserActivity(user.activity || []);
  };

  const handleAddFeature = () => {
    if (!newFeature.trim()) return;
    const updatedFeatures = [...features, {
      id: Date.now(),
      name: newFeature,
      status: 'Active',
      createdAt: new Date().toISOString()
    }];
    setFeatures(updatedFeatures);
    localStorage.setItem('adminFeatures', JSON.stringify(updatedFeatures));
    setNewFeature("");
    toast({
      title: "Feature Added",
      description: `"${newFeature}" has been added to the system.`
    });
  };

  const handleSendMechanicMessage = () => {
    if (!mechanicMessage.trim()) return;
    toast({
      title: "Message Sent to Mechanics",
      description: `${mechanicMessage}`
    });
    setMechanicMessage("");
  };

  return (
    <div className="min-h-screen bg-background pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-white">Admin Command Center</h1>
            <p className="text-gray-400">Complete System Management & Monitoring</p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { title: "Total Users", value: stats.users, icon: Users, color: "text-blue-400", bg: "bg-blue-400/10" },
            { title: "Emergency Requests", value: stats.requests, icon: AlertTriangle, color: "text-red-400", bg: "bg-red-400/10" },
            { title: "Active Mechanics", value: stats.mechanics, icon: Wrench, color: "text-orange-400", bg: "bg-orange-400/10" },
            { title: "Resolved Cases", value: stats.resolved, icon: CheckCircle, color: "text-green-400", bg: "bg-green-400/10" },
          ].map((stat, index) => (
            <Card key={index} className="glass-card border-white/5">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">{stat.title}</CardTitle>
                <div className={`p-2 rounded-full ${stat.bg}`}>
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-white/5 mb-8">
            <TabsTrigger value="users">👥 Users</TabsTrigger>
            <TabsTrigger value="conversations">💬 Conversations</TabsTrigger>
            <TabsTrigger value="mechanics">🔧 Mechanics</TabsTrigger>
            <TabsTrigger value="features">⚙️ Features</TabsTrigger>
            <TabsTrigger value="requests">📋 Requests</TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card className="glass-card border-white/5">
              <CardHeader>
                <CardTitle className="text-white">Registered Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="text-xs text-gray-200 uppercase bg-white/5">
                      <tr>
                        <th className="px-6 py-3">Name</th>
                        <th className="px-6 py-3">Email</th>
                        <th className="px-6 py-3">Registered</th>
                        <th className="px-6 py-3">Activity</th>
                        <th className="px-6 py-3">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {allUsers.length > 0 ? (
                        allUsers.map((user, i) => (
                          <tr key={i} className="border-b border-white/5 hover:bg-white/5">
                            <td className="px-6 py-4 font-medium text-white">{user.name}</td>
                            <td className="px-6 py-4 text-gray-300">{user.email}</td>
                            <td className="px-6 py-4 text-gray-400">
                              {user.registeredAt ? new Date(user.registeredAt).toLocaleDateString() : 'N/A'}
                            </td>
                            <td className="px-6 py-4 text-blue-400">{user.activity?.length || 0} actions</td>
                            <td className="px-6 py-4">
                              <Button 
                                size="sm" 
                                onClick={() => handleSelectUser(user)}
                                className="bg-blue-600 hover:bg-blue-700 text-xs"
                              >
                                View Details
                              </Button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="5" className="px-6 py-8 text-center text-gray-500">
                            No users registered yet.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* User Details */}
                {selectedUser && (
                  <div className="mt-8 p-4 bg-white/5 rounded-lg border border-white/10">
                    <h4 className="text-white font-bold mb-4">📊 User: {selectedUser.name}</h4>
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-gray-400 text-sm">Email</p>
                        <p className="text-white font-mono">{selectedUser.email}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Registered</p>
                        <p className="text-white">{selectedUser.registeredAt ? new Date(selectedUser.registeredAt).toLocaleString() : 'N/A'}</p>
                      </div>
                    </div>
                    
                    {userActivity.length > 0 && (
                      <div>
                        <p className="text-white font-bold mb-2">Activity Log:</p>
                        <div className="space-y-2">
                          {userActivity.map((act, i) => (
                            <div key={i} className="text-xs text-gray-300 bg-black/20 p-2 rounded">
                              <p><span className="text-blue-400">{act.type}</span>: {act.description}</p>
                              <p className="text-gray-500 text-xs">{new Date(act.timestamp).toLocaleString()}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Conversations Tab */}
          <TabsContent value="conversations">
            <Card className="glass-card border-white/5">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-blue-400" /> AI Chatbot Conversations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.keys(conversations).length > 0 ? (
                    Object.entries(conversations).map(([email, convos], i) => (
                      <div key={i} className="p-4 bg-white/5 rounded-lg border border-white/10">
                        <p className="text-white font-bold mb-3">👤 {email}</p>
                        {Array.isArray(convos) && convos.map((conv, j) => (
                          <div key={j} className="ml-4 mb-3 text-sm">
                            <p className="text-gray-400">
                              📅 {new Date(conv.timestamp).toLocaleString()} - 💬 {conv.messageCount || 0} messages
                            </p>
                            {Array.isArray(conv.messages) && (
                              <div className="mt-2 space-y-1 text-xs text-gray-300">
                                {conv.messages.slice(0, 3).map((msg, k) => (
                                  <p key={k} className={msg.isBot ? 'text-blue-300' : 'text-green-300'}>
                                    {msg.isBot ? '🤖 AI: ' : '👤 User: '} {msg.text?.substring(0, 50)}...
                                  </p>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-center py-8">No conversations recorded yet.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mechanics Tab */}
          <TabsContent value="mechanics">
            <Card className="glass-card border-white/5">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Wrench className="w-5 h-5 text-orange-400" /> Communicate with Mechanics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  {[
                    { name: "Raj Kumar", status: "Online", rating: 4.8, jobs: 142 },
                    { name: "Priya Singh", status: "Online", rating: 4.9, jobs: 168 },
                    { name: "Arun Patel", status: "Offline", rating: 4.7, jobs: 105 }
                  ].map((mech, i) => (
                    <div key={i} className="p-4 bg-white/5 rounded-lg border border-white/10">
                      <p className="font-bold text-white">{mech.name}</p>
                      <p className={`text-xs ${mech.status === 'Online' ? 'text-green-400' : 'text-gray-500'}`}>
                        ● {mech.status}
                      </p>
                      <p className="text-xs text-gray-400 mt-2">⭐ {mech.rating} | {mech.jobs} jobs</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <p className="text-white font-bold">Broadcast Message to All Mechanics:</p>
                  <textarea
                    value={mechanicMessage}
                    onChange={(e) => setMechanicMessage(e.target.value)}
                    placeholder="Type a message to send to all mechanics..."
                    className="w-full p-3 bg-white/5 border border-white/10 text-white rounded-lg focus:border-orange-500/50 outline-none h-24"
                  />
                  <Button 
                    onClick={handleSendMechanicMessage}
                    className="w-full bg-orange-600 hover:bg-orange-700"
                  >
                    <Send className="w-4 h-4 mr-2" /> Send Broadcast
                  </Button>
                </div>

                <div className="mt-6 p-4 bg-white/5 rounded-lg">
                  <p className="text-white font-bold mb-3">Recent Mechanic Communications:</p>
                  <div className="space-y-2 text-sm text-gray-300">
                    <p>✓ "New feature released: Emergency callback system"</p>
                    <p>✓ "Maintenance alert: High volume of AC issues detected"</p>
                    <p>✓ "Bonus incentive: Referral program now live"</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Features Tab */}
          <TabsContent value="features">
            <Card className="glass-card border-white/5">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-green-400" /> Add & Manage Features
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-white font-bold">Add New Feature:</p>
                  <div className="flex gap-2">
                    <Input
                      value={newFeature}
                      onChange={(e) => setNewFeature(e.target.value)}
                      placeholder="e.g., Real-time Traffic Integration, Voice Commands, etc."
                      className="bg-white/5 border-white/10 text-white"
                    />
                    <Button 
                      onClick={handleAddFeature}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Add
                    </Button>
                  </div>
                </div>

                <div className="mt-6">
                  <p className="text-white font-bold mb-3">Active Features ({features.length}):</p>
                  <div className="space-y-2">
                    {features.length > 0 ? (
                      features.map((feature, i) => (
                        <div key={i} className="p-3 bg-white/5 rounded border border-white/10 flex justify-between items-center">
                          <div>
                            <p className="text-white">{feature.name}</p>
                            <p className="text-xs text-gray-400">Added: {new Date(feature.createdAt).toLocaleDateString()}</p>
                          </div>
                          <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded">Active</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500">No features added yet.</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Requests Tab */}
          <TabsContent value="requests">
            <Card className="glass-card border-white/5">
              <CardHeader>
                <CardTitle className="text-white">Recent Emergency Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-400">
                    <thead className="text-xs text-gray-200 uppercase bg-white/5">
                      <tr>
                        <th className="px-6 py-3">Type</th>
                        <th className="px-6 py-3">Location</th>
                        <th className="px-6 py-3">Status</th>
                        <th className="px-6 py-3">Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentRequests.length > 0 ? (
                        recentRequests.map((req, i) => (
                          <tr key={i} className="border-b border-white/5 hover:bg-white/5">
                            <td className="px-6 py-4 font-medium text-white">{req.type}</td>
                            <td className="px-6 py-4">{req.location}</td>
                            <td className="px-6 py-4">
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                req.status === 'Pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'
                              }`}>
                                {req.status}
                              </span>
                            </td>
                            <td className="px-6 py-4">{new Date(req.timestamp).toLocaleTimeString()}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="4" className="px-6 py-8 text-center text-gray-500">
                            No recent requests found.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
