import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wrench, Trash2, CheckCircle } from 'lucide-react';

// Dummy admin panel to manage mechanics
export default function AdminMechanicPanel() {
  const mechanics = [
    { id: 1, name: "Quick Fix Garage", status: "Verified", totalJobs: 145 },
    { id: 2, name: "Auto Care Pro", status: "Verified", totalJobs: 89 },
    { id: 3, name: "Roadside Heroes", status: "Pending", totalJobs: 0 },
  ];

  return (
    <div className="min-h-screen bg-background pt-20 px-4 pb-12 max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Mechanic Management</h1>
          <p className="text-gray-400">Verify and manage registered mechanics.</p>
        </div>
        <Button className="bg-primary hover:bg-blue-600">
          + Add Mechanic
        </Button>
      </div>

      <div className="grid gap-4">
        {mechanics.map(mech => (
          <Card key={mech.id} className="glass-card border-white/5">
            <CardContent className="p-6 flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-orange-500/10 rounded-full">
                  <Wrench className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">{mech.name}</h3>
                  <p className="text-sm text-gray-400">Jobs Completed: {mech.totalJobs}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className={`px-3 py-1 rounded-full text-xs ${
                  mech.status === 'Verified' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
                }`}>
                  {mech.status}
                </span>
                <Button size="sm" variant="ghost" className="hover:bg-green-500/20 hover:text-green-400">
                  <CheckCircle className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="ghost" className="hover:bg-red-500/20 hover:text-red-400">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
