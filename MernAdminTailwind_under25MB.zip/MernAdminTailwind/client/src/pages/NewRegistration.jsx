import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, FileCheck, ShieldCheck, Download, Loader2 } from 'lucide-react';
import bgImage from '@assets/generated_images/digital_document_scanner_interface.png';

export default function NewRegistration() {
  const [uploading, setUploading] = useState(false);
  const [status, setStatus] = useState('idle'); // idle, processing, success

  const handleRegister = (e) => {
    e.preventDefault();
    setUploading(true);
    setStatus('processing');
    
    // Simulate AI Doc Verification
    setTimeout(() => {
      setUploading(false);
      setStatus('success');
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-4xl mx-auto relative">
       <div className="absolute inset-0 z-0">
        <img src={bgImage} alt="Scanner" className="w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/95 to-background/80" />
      </div>

      <div className="relative z-10">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-display font-bold text-white">Smart Registration</h1>
          <p className="text-gray-400">Register new Insurance, FASTag, or Emission Test with AI Verification.</p>
        </div>

        <Card className="glass-card border-white/10">
          <CardContent className="p-6">
            <Tabs defaultValue="insurance" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-white/5 mb-8">
                <TabsTrigger value="insurance">Insurance</TabsTrigger>
                <TabsTrigger value="fastag">FASTag</TabsTrigger>
                <TabsTrigger value="emission">Emission</TabsTrigger>
              </TabsList>

              {['insurance', 'fastag', 'emission'].map((tab) => (
                <TabsContent key={tab} value={tab} className="space-y-6 animate-fade-in">
                  {status === 'success' ? (
                    <div className="text-center py-12 space-y-6">
                      <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto animate-bounce">
                        <ShieldCheck className="w-10 h-10 text-green-500" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-white">Registration Complete!</h3>
                        <p className="text-gray-400">Your documents have been AI verified and approved.</p>
                      </div>
                      <Button className="bg-white/10 hover:bg-white/20 text-white">
                        <Download className="mr-2 w-4 h-4" /> Download Certificate
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleRegister} className="grid md:grid-cols-2 gap-8">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label className="text-gray-300">Vehicle Owner Name</Label>
                          <Input placeholder="Full Name" className="bg-white/5 border-white/10 text-white" required />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-gray-300">Registration Number</Label>
                          <Input placeholder="KA-01-XX-XXXX" className="bg-white/5 border-white/10 text-white" required />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-gray-300">Chassis Number (Last 5 digits)</Label>
                          <Input placeholder="12345" className="bg-white/5 border-white/10 text-white" required />
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div className="border-2 border-dashed border-white/20 rounded-xl h-48 flex flex-col items-center justify-center text-gray-500 hover:border-primary/50 hover:bg-primary/5 transition-colors cursor-pointer group">
                          <Upload className="w-10 h-10 mb-2 group-hover:text-primary transition-colors" />
                          <p className="text-sm">Upload RC / Previous Policy</p>
                          <p className="text-xs text-gray-600 mt-1">AI will auto-extract details</p>
                        </div>

                        <Button type="submit" className="w-full bg-primary hover:bg-blue-600 text-white h-12" disabled={uploading}>
                          {uploading ? (
                            <span className="flex items-center gap-2">
                              <Loader2 className="w-4 h-4 animate-spin" /> Verifying Documents...
                            </span>
                          ) : "Submit for AI Verification"}
                        </Button>
                      </div>
                    </form>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
