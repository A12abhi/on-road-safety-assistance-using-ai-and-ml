import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  AlertTriangle, 
  MessageSquare, 
  Map, 
  Wrench, 
  Activity, 
  Leaf, 
  CreditCard, 
  Shield, 
  Wind, 
  Fuel,
  Sparkles,
  Mic,
  Brain,
  Heart,
  FileText
} from 'lucide-react';
import { cn } from '@/lib/utils';

const modules = [
  {
    title: "Emergency Request",
    path: "/emergency",
    icon: AlertTriangle,
    color: "text-red-500",
    bg: "bg-red-500/10",
    desc: "Instant breakdown help",
    aiFeature: "AI Location Analysis"
  },
  {
    title: "AI Mechanic Pro",
    path: "/chatbot",
    icon: MessageSquare,
    color: "text-blue-400",
    bg: "bg-blue-400/10",
    desc: "Level 5 Diagnostics",
    aiFeature: "Deep Learning Chat"
  },
  {
    title: "Map View",
    path: "/map",
    icon: Map,
    color: "text-green-400",
    bg: "bg-green-400/10",
    desc: "View road conditions",
    aiFeature: "Risk Zone Copilot"
  },
  {
    title: "Mechanic Finder",
    path: "/mechanics",
    icon: Wrench,
    color: "text-orange-400",
    bg: "bg-orange-400/10",
    desc: "Find nearby mechanics",
    aiFeature: "Smart Matching"
  },
  {
    title: "Vehicle Health",
    path: "/health",
    icon: Activity,
    color: "text-cyan-400",
    bg: "bg-cyan-400/10",
    desc: "AI Health Analysis",
    aiFeature: "Predictive Maintenance"
  },
  {
    title: "Smart Maintenance AI",
    path: "/maintenance-ai",
    icon: Wrench,
    color: "text-blue-400",
    bg: "bg-blue-400/10",
    desc: "Predict maintenance needs early",
    aiFeature: "Predictive Maintenance ML"
  },
  {
    title: "Eco-Driving Coach AI",
    path: "/eco-drive",
    icon: Leaf,
    color: "text-green-400",
    bg: "bg-green-400/10",
    desc: "AI driving behavior analysis & fuel savings",
    aiFeature: "Real-time Eco Coaching"
  },
  {
    title: "FASTag",
    path: "/fastag",
    icon: CreditCard,
    color: "text-indigo-400",
    bg: "bg-indigo-400/10",
    desc: "Recharge & Balance",
    aiFeature: "Usage Prediction"
  },
  {
    title: "Insurance",
    path: "/insurance",
    icon: Shield,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10",
    desc: "Manage policies",
    aiFeature: "Smart Recommendations"
  },
  {
    title: "Emission Test",
    path: "/emission",
    icon: Wind,
    color: "text-teal-400",
    bg: "bg-teal-400/10",
    desc: "Testing reminders",
    aiFeature: "Eco-Impact Score"
  },
  {
    title: "Fuel Assistant",
    path: "/fuel",
    icon: Fuel,
    color: "text-amber-400",
    bg: "bg-amber-400/10",
    desc: "Find stations & logs",
    aiFeature: "Price Forecasting"
  },
  {
    title: "Accident Escape AI",
    path: "/escape-ai",
    icon: AlertTriangle,
    color: "text-red-400",
    bg: "bg-red-400/10",
    desc: "Emergency escape strategies",
    aiFeature: "Route Generation"
  },
  {
    title: "Panic Predictor AI",
    path: "/panic-predictor",
    icon: Brain,
    color: "text-purple-400",
    bg: "bg-purple-400/10",
    desc: "Real-time stress detection",
    aiFeature: "Behavior Analysis"
  },
  {
    title: "Anti-Rage Driving Mode",
    path: "/anti-rage",
    icon: Heart,
    color: "text-pink-400",
    bg: "bg-pink-400/10",
    desc: "AI stress detection & calm driving interface",
    aiFeature: "Behavior Recognition"
  },
  {
    title: "Reports & History",
    path: "/reports",
    icon: FileText,
    color: "text-green-400",
    bg: "bg-green-400/10",
    desc: "Download all reports",
    aiFeature: "PDF Generator"
  }
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background pt-20 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-white mb-2">Dashboard</h1>
          <p className="text-gray-400">Manage your vehicle with AI-powered features</p>
        </div>

        {/* AI Insight Card */}
        <div className="mb-10 p-6 rounded-2xl bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 backdrop-blur-sm">
          <div className="flex items-start gap-4">
            <Sparkles className="w-6 h-6 text-blue-400 mt-1 flex-shrink-0" />
            <div>
              <h3 className="text-white font-semibold mb-1">AI Insight</h3>
              <p className="text-gray-300 text-sm">Your vehicle is in excellent condition. Next maintenance due in 2,500 km.</p>
            </div>
          </div>
        </div>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {modules.map((module, index) => (
            <Link key={index} to={module.path}>
              <div className="group h-full">
                <Card className="glass-card h-full p-6 rounded-2xl border border-white/10 cursor-pointer transition-all duration-300 hover:border-white/20 hover:bg-white/[0.08] hover:shadow-lg">
                  {/* Icon Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <div className={cn("p-3 rounded-xl", module.bg)}>
                      <module.icon className={cn("w-6 h-6", module.color)} />
                    </div>
                    <span className="text-xs text-gray-400 bg-white/5 px-2 py-1 rounded-full">{module.aiFeature}</span>
                  </div>

                  {/* Title */}
                  <h3 className="text-white font-semibold text-base mb-2 group-hover:text-blue-400 transition-colors">
                    {module.title}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-400 text-sm leading-relaxed">
                    {module.desc}
                  </p>
                </Card>
              </div>
            </Link>
          ))}
        </div>

      </div>
    </div>
  );
}
