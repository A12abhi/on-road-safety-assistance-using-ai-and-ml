import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import ChatBubble from '@/components/ChatBubble';
import { Send, ArrowRight, Loader2, Mic, Volume2, Square } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';

export default function AIChatbot() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser, trackConversation } = useAuth();
  const [messages, setMessages] = useState([
    { id: 1, text: "🤖 Hey there! Don't worry, I'm here to help you! I'm your AI Mechanic Pro - your 24/7 vehicle expert.\n\nTell me, what's the problem you're facing with your vehicle? I'll listen carefully and help diagnose the issue. 🚗", isBot: true }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [step, setStep] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const messagesEndRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const recordingTimerRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Cleanup when page exits - stop all audio and recording
  useEffect(() => {
    return () => {
      // Stop speech synthesis
      window.speechSynthesis.cancel();
      
      // Stop any ongoing recording
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      
      // Clear any timers
      if (recordingTimerRef.current) {
        clearTimeout(recordingTimerRef.current);
      }
    };
  }, []);

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = { id: Date.now(), text: input, isBot: false };
    setMessages(prev => [...prev, userMsg]);
    const currentInput = input;
    const userText = currentInput.toLowerCase();
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      let botResponse = "";
      
      // Emergency/critical check - only book immediately if absolutely necessary
      const criticalIssues = userText.includes('brake') && (userText.includes('fail') || userText.includes('won\'t work') || userText.includes('not working')) ||
                            userText.includes('crash') || userText.includes('emergency') || userText.includes('accident');
      
      // Check if user explicitly wants to book
      const wantToBook = userText.includes('book') || (userText.includes('yes') && messages.some(m => m.text.includes('book')));

      if (criticalIssues || wantToBook) {
        // Auto-book mechanic
        botResponse = `🚀 Don't worry! I'm connecting you with the nearest certified mechanic right now!\n\n✅ Booking confirmed!\n- Specialist mechanic assigned\n- ETA: 15-20 minutes\n- Available 24/7 emergency support\n\nRedirecting you to mechanic details...`;
        setMessages(prev => [...prev, { id: Date.now() + 1, text: botResponse, isBot: true }]);
        setIsTyping(false);
        speakResponse(botResponse);
        
        setTimeout(() => {
          navigate('/mechanics?issue=VOICE_AI_DIAGNOSIS');
        }, 2000);
      } else {
        // Try to help diagnose and fix the issue
        if (userText.includes('engine') || userText.includes('grinding') || userText.includes('knock') || userText.includes('noise')) {
          botResponse = `I understand! Engine sounds can be scary, but don't worry - I'm here to help!\n\nEngine Noise Analysis. Based on what you described, this could be:\nGrinding or knocking means Engine knock or bearing issue.\nClicking means Valve train or timing issue.\n\nQuick Questions to Help You:\n1. When does it happen? Startup, driving, or accelerating?\n2. Does it go away after the engine warms up?\n3. Are there any warning lights on the dashboard?\n\nWhat I can do: Tell me more details, and I'll try to help fix it remotely. If we can't solve it, I'll book you with a specialist. You're in safe hands.`;
        } else if (userText.includes('battery') || userText.includes('won\'t start') || userText.includes('electrical')) {
          botResponse = `No panic! Battery and electrical issues are common - I can help!\n\nElectrical Issue Check. This could be:\nDead or weak battery.\nAlternator not charging.\nCorroded battery terminals.\n\nLet's troubleshoot together:\n1. When you turn the key, do you hear clicking or nothing?\n2. Are the dashboard lights working?\n3. Can you see any corrosion on battery terminals?\n\nSimple fixes we can try:\nIf it's corrosion, I can guide you to clean it.\nCheck battery connections.\nJump start procedure.\n\nTell me more, and let's fix this!`;
        } else if (userText.includes('tire') || userText.includes('flat') || userText.includes('puncture') || userText.includes('pressure')) {
          botResponse = `Tire issues are usually easy to fix - don't worry!\n\nTire Problem Check. This might be:\nFlat tire or slow leak.\nLow tire pressure.\nPuncture or nail.\n\nQuick checks:\n1. Is the tire completely flat or just low on air?\n2. Can you see any nails or damage?\n3. Do you have a spare tire and jack?\n\nWhat we can do:\nIf it's low pressure, I can guide you to a nearby pump.\nIf it's flat, let's change the spare.\nIf it's a puncture, repair kit might work.\n\nTell me the details, and let's get you rolling again!`;
        } else if (userText.includes('fuel') || userText.includes('fuel smell') || userText.includes('won\'t start fuel')) {
          botResponse = `Fuel issues are fixable! Don't stress, I'm here with you!\n\nFuel System Check. Could be:\nOut of fuel - most common.\nFuel pump issue.\nClogged fuel filter.\nBad fuel injectors.\n\nLet's check together:\n1. When's the last time you filled up?\n2. Does the fuel gauge work?\n3. Any clicking sound when you turn on the ignition?\n\nQuick fixes:\nTop up your fuel first.\nCheck if fuel pump makes a sound.\nIf everything is normal, we may need a mechanic.\n\nGive me more info, and we'll figure it out!`;
        } else if (userText.includes('brake') || userText.includes('stop')) {
          botResponse = `Brake issues need attention, but I'm here to guide you safely!\n\nBrake Safety Check. Could be:\nLow brake fluid.\nWorn brake pads.\nAir in brake lines.\nMaster cylinder issue.\n\nSafety Questions First:\n1. Can you still brake, or is it completely gone?\n2. Is there a brake warning light?\n3. Does the pedal feel soft or hard?\n\nBefore I book a mechanic:\nCheck your brake fluid level under the hood.\nIf low, top it up carefully.\nTest gently - do not drive aggressively.\n\nIf brakes fail completely, don't drive - I'll book a mechanic urgently. Tell me what you feel!`;
        } else if (userText.includes('overheating') || userText.includes('steam') || userText.includes('hot')) {
          botResponse = `Engine overheating - stay calm, I'm here to help!\n\nOverheating Alert. Could be:\nLow coolant level.\nThermostat stuck.\nWater pump failure.\nRadiator issue.\n\nQuick Safety Check:\n1. Do you see steam from under the hood?\n2. Can you smell burning?\n3. Temperature gauge in the red?\n\nWhat to do right now:\nTurn off the engine immediately.\nWait 15 minutes before opening the radiator cap.\nCheck coolant level when cool.\n\nLet me help: Tell me what you see, and we can decide if you need a mechanic urgently or if we can cool it down safely. Stay safe!`;
        } else {
          botResponse = `Don't worry! I'm here to help you out! Tell me more about your vehicle issue.\n\nWhat I need to know:\n1. What's happening? What do you hear, see, or feel?\n2. When did it start? Suddenly or gradually?\n3. How severe? Car still runs or completely broken?\n4. Any warning lights on the dashboard?\n\nHere's my promise:\nI'll analyze your problem carefully.\nGive you honest troubleshooting steps.\nTry to help you fix it ourselves.\nOnly book a mechanic if we really need one.\n\nI'm not going anywhere - we're in this together! Speak up and let me help you.`;
        }
        
        setMessages(prev => [...prev, { id: Date.now() + 1, text: botResponse, isBot: true }]);
        setIsTyping(false);
        speakResponse(botResponse);
      }
    }, 1000);
  };


  // Voice Recording Handler - Using Web Speech API
  const startRecording = async () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      toast({
        title: "Not Supported",
        description: "Speech Recognition is not supported in your browser",
        variant: "destructive"
      });
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      mediaRecorderRef.current = recognition;
      setRecordingTime(0);
      setIsRecording(true);

      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      let finalTranscript = '';
      let interimTranscript = '';

      recognition.onstart = () => {
        setIsRecording(true);
      };

      recognition.onresult = (event) => {
        interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;

          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }

        // Show the transcription in real-time
        if (finalTranscript || interimTranscript) {
          setInput(finalTranscript || interimTranscript);
        }
      };

      recognition.onerror = (event) => {
        toast({
          title: "Recording Error",
          description: `Error: ${event.error}`,
          variant: "destructive"
        });
        setIsRecording(false);
      };

      recognition.onend = () => {
        if (finalTranscript.trim()) {
          setInput(finalTranscript.trim());
          // Auto-send the transcribed message
          setTimeout(() => {
            handleSend({ preventDefault: () => {} });
          }, 500);
        }
        setIsRecording(false);
      };

      recognition.start();

      // Update recording time continuously (no auto-stop)
      const timeInterval = setInterval(() => {
        setRecordingTime(prev => prev + 0.1);
      }, 100);
    } catch (error) {
      toast({
        title: "Microphone Error",
        description: "Please allow microphone access to use voice input",
        variant: "destructive"
      });
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
    }
    if (recordingTimerRef.current) clearTimeout(recordingTimerRef.current);
    setIsRecording(false);
    setRecordingTime(0);
  };

  // Text-to-Speech for Bot Responses
  const speakResponse = (text) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1;
      utterance.volume = 1;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-4xl mx-auto h-screen flex flex-col relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-600/20 via-background to-background" />
      </div>

      <div className="relative z-10 text-center mb-6 shrink-0">
        <h1 className="text-3xl font-display font-bold text-white">AI Mechanic Pro</h1>
        <p className="text-gray-400">Smart Vehicle Diagnostics - 6-Turn Expert Conversation</p>
      </div>

      <Card className="relative z-10 glass-card flex-1 flex flex-col overflow-hidden border-blue-500/20 shadow-[0_0_40px_rgba(59,130,246,0.1)]">
        <CardHeader className="border-b border-white/10 bg-black/20 py-4 flex flex-row justify-between items-center">
          <CardTitle className="text-lg text-white flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_#22c55e]" />
            AI Assistant Active - Step {step + 1}/6
          </CardTitle>
          <div className="flex gap-2 items-center">
            {isRecording && (
              <div className="flex items-center gap-2 px-3 py-1 bg-red-500/20 border border-red-500/50 rounded-full">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-xs text-red-400 font-bold">{recordingTime.toFixed(1)}s</span>
              </div>
            )}
            <Button 
              size="icon" 
              variant="ghost" 
              onClick={isRecording ? stopRecording : startRecording}
              className={`transition-all ${isRecording ? 'text-red-400 hover:bg-red-500/10' : 'text-purple-400 hover:bg-purple-500/10'}`}
            >
              {isRecording ? <Square className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
          {messages.map((msg) => (
            <ChatBubble key={msg.id} message={msg.text} isBot={msg.isBot} />
          ))}
          
          {isTyping && (
            <div className="flex gap-2 items-center text-blue-400 text-xs ml-4 animate-pulse">
              <Loader2 className="w-3 h-3 animate-spin" /> AI analyzing your symptoms...
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </CardContent>

        <div className="p-4 bg-black/20 border-t border-white/10">
          <form onSubmit={handleSend} className="flex gap-2">
            <Input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={step < 6 ? "Describe your vehicle issue or use mic..." : "Confirm booking..."}
              className="bg-white/5 border-white/10 text-white focus:border-blue-500/50"
              disabled={step === 6 && !isTyping}
            />
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={!input.trim() || (step === 6 && !isTyping)}>
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </Card>
    </div>
  );
}
