import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, Circle, Polyline } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Construction, Mic, Volume2, MapPin, Fuel, Thermometer, Zap, Gauge, AlertCircle, Navigation, Users, TrendingUp, Moon, Sun, Truck, Car, Bike, AlertOctagon, Heart, Shield, Sparkles, Brain, Eye, TrendingDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

const accidentData = [
  { id: 1, lat: 12.9716, lng: 77.5946, radius: 500, accidents: 12, level: 'HIGH', road: 'NH-44 Junction', reason: 'High-speed collisions', mostDangerous: '22:00-04:00', dayStatus: 'Moderate', nightStatus: 'CRITICAL', crime: 'HIGH', potholes: 3 },
  { id: 2, lat: 12.9816, lng: 77.6046, radius: 400, accidents: 8, level: 'MEDIUM', road: 'Ring Road Section B', reason: 'Construction zone hazards', mostDangerous: '18:00-06:00', dayStatus: 'Safe', nightStatus: 'UNSAFE', crime: 'MEDIUM', potholes: 5 },
  { id: 3, lat: 12.9616, lng: 77.5846, radius: 300, accidents: 5, level: 'MEDIUM', road: 'Old Forest Road', reason: 'Poor lighting at night', mostDangerous: '20:00-05:00', dayStatus: 'Safe', nightStatus: 'VERY UNSAFE', crime: 'VERY HIGH', potholes: 8 },
  { id: 4, lat: 12.9500, lng: 77.5750, radius: 350, accidents: 10, level: 'HIGH', road: 'Bangalore Outer Ring', reason: 'Frequent pile-ups during rain', mostDangerous: '17:00-09:00', dayStatus: 'Moderate', nightStatus: 'CRITICAL', crime: 'HIGH', potholes: 2 },
];

const potholeLocations = [
  { id: 1, lat: 12.9720, lng: 77.5950, severity: 'HIGH', depth: '15cm' },
  { id: 2, lat: 12.9810, lng: 77.6050, severity: 'MEDIUM', depth: '8cm' },
  { id: 3, lat: 12.9620, lng: 77.5850, severity: 'HIGH', depth: '12cm' },
  { id: 4, lat: 12.9505, lng: 77.5755, severity: 'LOW', depth: '5cm' },
  { id: 5, lat: 12.9730, lng: 77.5960, severity: 'HIGH', depth: '18cm' },
];

const routeSegments = [
  { id: 1, type: 'safe', name: 'Main Highway', desc: 'Smooth & Safe', lat: 12.9716, lng: 77.5946, distance: 5, suitable: ['Car', 'SUV', 'Bike'] },
  { id: 2, type: 'construction', name: 'Ring Road Section B', desc: 'Under Construction', lat: 12.9816, lng: 77.6046, distance: 8, suitable: ['Car', 'SUV'] },
  { id: 3, type: 'danger', name: 'Old Forest Road', desc: 'Dangerous at Night', lat: 12.9616, lng: 77.5846, distance: 12, suitable: ['Truck'] },
  { id: 4, type: 'danger', name: 'BIAL Junction', desc: 'High accident zone', lat: 12.9500, lng: 77.5750, distance: 15, suitable: ['Car', 'SUV'] },
];

function AICopilotOverlay({ onWarning }) {
  const map = useMapEvents({
    click(e) {
      const isDanger = Math.random() > 0.7;
      if (isDanger) {
        onWarning({
          title: "⚠️ HIGH RISK ZONE DETECTED",
          message: "Recent accident reports in this area. AI recommends taking alternate route.",
          severity: 'critical'
        });
      }
    }
  });
  return null;
}

export default function MapView() {
  const { toast } = useToast();
  const currentPosition = [12.9716, 77.5946];
  const [aiMessage, setAiMessage] = useState(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showPanel, setShowPanel] = useState(true);
  const [isNightMode, setIsNightMode] = useState(false);
  const [vehicleType, setVehicleType] = useState('Car');
  const [userGender, setUserGender] = useState('General');
  
  // Vehicle Status
  const [vehicleStatus, setVehicleStatus] = useState({
    fuel: 45,
    battery: 78,
    engineTemp: 92,
    tirePressure: 'LOW',
    currentSpeed: 0
  });

  // Night time check
  useEffect(() => {
    const hour = new Date().getHours();
    setIsNightMode(hour >= 20 || hour < 6);
  }, []);

  // Safety Alerts based on time and gender
  const [safetyAlerts, setSafetyAlerts] = useState([]);
  
  useEffect(() => {
    const alerts = [
      { id: 1, type: 'fuel', icon: '⚠️', title: 'Low Fuel Alert', msg: 'Avoid long routes. Fuel below 50%', severity: 'high' },
      { id: 2, type: 'tire', icon: '🔴', title: 'Tire Pressure Risk', msg: 'Check tire pressure. Unsafe to drive long distance', severity: 'critical' },
      { id: 3, type: 'temp', icon: '🌡️', title: 'Engine Temperature High', msg: 'Drive slowly. Engine running hot. Cool down needed', severity: 'high' },
    ];

    if (isNightMode && userGender === 'Women') {
      alerts.unshift({
        id: 0,
        type: 'women',
        icon: '⚠️',
        title: '⛔ NOT SAFE FOR WOMEN',
        msg: 'DONT RIDE NOW! Crime rate high at night. Unsafe conditions for women. Use ride-sharing with verified drivers.',
        severity: 'critical'
      });
    }

    if (isNightMode) {
      alerts.push({
        id: 99,
        type: 'night',
        icon: '🌙',
        title: 'Night Time Caution',
        msg: 'Poor visibility. Crime rate elevated. Stick to main highways.',
        severity: 'high'
      });
    }

    setSafetyAlerts(alerts);
  }, [isNightMode, userGender]);

  const handleWarning = (alert) => {
    setAiMessage(alert);
    setIsSpeaking(true);
    setTimeout(() => setIsSpeaking(false), 4000);
    setTimeout(() => setAiMessage(null), 6000);
  };

  const handleMarkerClick = (seg) => {
    const currentHour = new Date().getHours();
    const isDangerousTime = isNightMode && seg.type === 'danger';
    
    const vehicleIssues = [];
    if (vehicleStatus.fuel < 50 && seg.distance > 5) vehicleIssues.push('Fuel low');
    if (vehicleStatus.battery < 30 && seg.distance > 8) vehicleIssues.push('Battery low');
    if (vehicleStatus.engineTemp > 85) vehicleIssues.push('Engine hot');
    if (vehicleStatus.tirePressure === 'LOW') vehicleIssues.push('Tire pressure risk');

    const isVehicleSuitable = seg.suitable.includes(vehicleType);

    if (seg.type === 'danger') {
      const dangerZone = accidentData.find(z => z.road === seg.name);
      const status = isNightMode ? dangerZone?.nightStatus : dangerZone?.dayStatus;
      const msg = {
        title: "🚨 CRITICAL ROUTE WARNING",
        message: `${seg.name} - Status: ${status}. ${dangerZone?.reason}. Most dangerous: ${dangerZone?.mostDangerous}. ${!isVehicleSuitable ? 'Vehicle not recommended for this route. ' : ''}${isDangerousTime ? '🌙 NIGHT TIME - AVOID!' : ''} ${vehicleIssues.length > 0 ? 'ALSO: ' + vehicleIssues.join(', ') : ''}`,
        severity: 'critical'
      };
      handleWarning(msg);
      toast({
        title: "🚨 DANGER ZONE ALERT",
        description: msg.message,
        variant: "destructive"
      });
    } else if (seg.type === 'construction') {
      const msg = {
        title: "⚠️ CONSTRUCTION WARNING",
        message: `${seg.name} is under construction. Expect delays. ${!isVehicleSuitable ? 'Vehicle type not optimal for construction zone. ' : ''}${isDangerousTime ? '🌙 Extra caution at night. ' : ''}${vehicleIssues.length > 0 ? 'Vehicle issues: ' + vehicleIssues.join(', ') : ''}`,
        severity: 'warning'
      };
      handleWarning(msg);
    } else {
      const msg = {
        title: "✅ SAFE ROUTE",
        message: `${seg.name} is the safest option. ${isVehicleSuitable ? '✓ Optimal for ' + vehicleType : '⚠️ ' + vehicleType + ' not ideal'}. ${vehicleIssues.length > 0 ? 'Note: Vehicle issues - ' + vehicleIssues.join(', ') : 'All systems normal.'}`,
        severity: 'info'
      };
      handleWarning(msg);
    }
  };


  const handleEmergencyAlert = () => {
    toast({
      title: "🚨 Emergency Mode Activated",
      description: "Nearest service center located. Emergency crew notified."
    });
  };

  const getCurrentTime = () => {
    const hour = new Date().getHours();
    return `${hour.toString().padStart(2, '0')}:${new Date().getMinutes().toString().padStart(2, '0')}`;
  };

  // AI Safety Score Calculator
  const calculateAISafetyScore = () => {
    let score = 100;
    if (vehicleStatus.fuel < 50) score -= 15;
    if (vehicleStatus.engineTemp > 85) score -= 20;
    if (vehicleStatus.tirePressure === 'LOW') score -= 25;
    if (isNightMode) score -= 10;
    if (userGender === 'Women' && isNightMode) score -= 30;
    return Math.max(0, score);
  };

  // AI Route Recommendation
  const getAIRouteRecommendation = () => {
    const safeRoutes = routeSegments.filter(seg => 
      seg.suitable.includes(vehicleType) && seg.type !== 'danger'
    );
    return safeRoutes.length > 0 ? safeRoutes[0] : routeSegments[0];
  };

  // AI Driver Coaching Tips
  const getAICoachingTips = () => {
    const tips = [];
    if (vehicleStatus.fuel < 50) tips.push('🛢️ Refuel soon - AI detected low fuel');
    if (vehicleStatus.engineTemp > 85) tips.push('❄️ Engine hot - Reduce speed to cool down');
    if (vehicleStatus.currentSpeed === 0) tips.push('✋ Starting journey? Check route ahead first');
    if (isNightMode) tips.push('🌙 Night driving - Stay alert in low visibility');
    if (vehicleStatus.battery < 50) tips.push('🔋 Battery low - Minimize AC usage');
    return tips.length > 0 ? tips : ['✅ Vehicle in optimal condition - Safe to travel'];
  };

  // AI Risk Prediction
  const getAIRiskPrediction = () => {
    const risks = [];
    const nearbyDangerZones = accidentData.filter(zone => Math.random() > 0.5);
    if (nearbyDangerZones.length > 0) {
      risks.push({ level: 'HIGH', msg: `${nearbyDangerZones[0].accidents} accidents nearby - Take caution` });
    }
    if (isNightMode && userGender === 'Women') {
      risks.push({ level: 'CRITICAL', msg: 'Unsafe for women at night - Consider ride-sharing' });
    }
    if (vehicleStatus.tirePressure === 'LOW') {
      risks.push({ level: 'HIGH', msg: 'Tire risk - May fail on long routes' });
    }
    return risks.length > 0 ? risks : [{ level: 'LOW', msg: 'No major risks detected - All clear' }];
  };

  return (
    <div className={`min-h-screen ${isNightMode ? 'bg-slate-950' : 'bg-background'} pt-24 flex flex-col relative overflow-hidden transition-colors duration-500`}>
      {/* AI Safety Alert Overlay */}
      {aiMessage && (
        <div className="absolute top-32 left-1/2 transform -translate-x-1/2 z-[1000] w-[90%] max-w-2xl animate-slide-up">
          <div className={`glass-card border-l-4 p-5 rounded-r-lg shadow-2xl flex items-start gap-4 ${
            aiMessage.severity === 'critical' ? 'border-red-500 bg-red-950/95' : 
            aiMessage.severity === 'warning' ? 'border-yellow-500 bg-yellow-950/95' :
            'border-green-500 bg-green-950/95'
          }`}>
            <div className={`p-3 rounded-full shrink-0 text-lg ${isSpeaking ? 'animate-pulse' : ''}`}>
              {aiMessage.severity === 'critical' ? '🚨' : aiMessage.severity === 'warning' ? '⚠️' : '✅'}
            </div>
            <div className="flex-1">
              <h4 className="text-base font-bold text-white mb-2 uppercase tracking-wider">{aiMessage.title}</h4>
              <p className="text-sm text-gray-100 leading-relaxed">{aiMessage.message}</p>
            </div>
          </div>
        </div>
      )}

      <div className={`px-4 py-4 ${isNightMode ? 'bg-gradient-to-r from-slate-900 to-slate-800 border-orange-500/30' : 'bg-gradient-to-r from-purple-600/10 to-pink-600/10 border-white/10'} border-b transition-all z-10`}>
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1 className={`text-2xl font-display font-bold ${isNightMode ? 'text-orange-400' : 'bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent'}`}>
              🤖 AI Safety Map - 24/7 Route Guide
            </h1>
            <p className="text-xs text-gray-400 mt-1">Current Time: {getCurrentTime()} | Mode: {isNightMode ? '🌙 NIGHT MODE' : '☀️ DAY MODE'} | Real-time danger detection • Accident zones • Pothole warnings • Crime data</p>
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm"
              variant="outline"
              onClick={() => setIsNightMode(!isNightMode)}
              className={`border-white/20 hover:bg-white/10 ${isNightMode ? 'bg-orange-500/20 border-orange-500/50' : ''}`}
            >
              {isNightMode ? <Moon className="w-4 h-4 mr-1" /> : <Sun className="w-4 h-4 mr-1" />}
              {isNightMode ? 'Night' : 'Day'}
            </Button>
            <Button 
              size="sm"
              variant="outline"
              onClick={() => setShowPanel(!showPanel)}
              className="border-white/20 hover:bg-white/10"
            >
              {showPanel ? '📍 Hide' : '📍 Show'} Panel
            </Button>
          </div>
        </div>

        {/* Vehicle & Gender Selection */}
        <div className="flex gap-4 flex-wrap text-xs">
          <div className="flex gap-2">
            <label className="text-gray-400">Vehicle:</label>
            <select 
              value={vehicleType}
              onChange={(e) => setVehicleType(e.target.value)}
              className="bg-white/5 border border-white/20 text-white rounded px-2 py-1 text-xs"
            >
              <option>Car</option>
              <option>SUV</option>
              <option>Bike</option>
              <option>Truck</option>
            </select>
          </div>
          <div className="flex gap-2">
            <label className="text-gray-400">User:</label>
            <select 
              value={userGender}
              onChange={(e) => setUserGender(e.target.value)}
              className="bg-white/5 border border-white/20 text-white rounded px-2 py-1 text-xs"
            >
              <option>General</option>
              <option>Women</option>
              <option>Senior</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex-1 flex gap-4 px-4 py-4 overflow-hidden">
        {/* Map Container */}
        <div className="flex-1 relative z-0 rounded-lg overflow-hidden border border-white/10">
          <MapContainer center={currentPosition} zoom={13} scrollWheelZoom={true} className="w-full h-full">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {/* Current Location Marker */}
            <Marker position={currentPosition}>
              <Popup>
                <div className="p-2">
                  <p className="font-bold">📍 Your Location</p>
                  <p className="text-xs text-gray-600">Bangalore, India</p>
                  <p className="text-xs text-gray-600 mt-1">Vehicle: {vehicleType}</p>
                  <p className={`text-xs font-bold mt-1 ${isNightMode ? 'text-orange-600' : 'text-blue-600'}`}>{isNightMode ? '🌙 Night Mode Active' : '☀️ Day Mode'}</p>
                </div>
              </Popup>
            </Marker>

            {/* Danger Zones */}
            {accidentData.map(zone => (
              <React.Fragment key={zone.id}>
                <Circle 
                  center={[zone.lat, zone.lng]} 
                  radius={zone.radius}
                  pathOptions={{
                    color: isNightMode && zone.nightStatus === 'CRITICAL' ? '#ff1744' : zone.level === 'HIGH' ? '#ef4444' : '#eab308',
                    fillColor: isNightMode && zone.nightStatus === 'CRITICAL' ? '#ff1744' : zone.level === 'HIGH' ? '#ef4444' : '#eab308',
                    fillOpacity: 0.2,
                    weight: 2
                  }}
                >
                  <Popup>
                    <div className="p-2 min-w-[240px] text-xs">
                      <p className="font-bold text-red-600">⚠️ DANGER ZONE</p>
                      <p className="font-bold text-black mt-1">{zone.road}</p>
                      <p className="text-gray-700 mt-1">📊 Accidents: {zone.accidents}</p>
                      <p className="text-gray-700">Risk Level: {zone.level}</p>
                      <p className="text-gray-700">Reason: {zone.reason}</p>
                      <p className={`font-bold mt-1 ${zone.mostDangerous ? 'text-red-600' : ''}`}>🕐 Most Dangerous: {zone.mostDangerous}</p>
                      <p className={`font-bold ${isNightMode ? 'text-orange-600' : 'text-blue-600'}`}>🌙 Night: {zone.nightStatus}</p>
                      <p className={`font-bold ${isNightMode ? 'text-orange-600' : 'text-blue-600'}`}>☀️ Day: {zone.dayStatus}</p>
                      <p className={`font-bold mt-1 ${zone.crime === 'HIGH' || zone.crime === 'VERY HIGH' ? 'text-red-600' : 'text-yellow-600'}`}>🚨 Crime: {zone.crime}</p>
                      <p className="text-gray-700 mt-1">🕳️ Potholes: {zone.potholes}</p>
                    </div>
                  </Popup>
                </Circle>
              </React.Fragment>
            ))}

            {/* Pothole Markers */}
            {potholeLocations.map(pothole => (
              <Marker key={'pothole-' + pothole.id} position={[pothole.lat, pothole.lng]}>
                <Popup>
                  <div className="p-2 min-w-[150px]">
                    <p className="font-bold text-orange-600">🕳️ POTHOLE</p>
                    <p className="text-sm text-black mt-1">Severity: <span className={`font-bold ${pothole.severity === 'HIGH' ? 'text-red-600' : 'text-yellow-600'}`}>{pothole.severity}</span></p>
                    <p className="text-sm text-gray-700">Depth: {pothole.depth}</p>
                  </div>
                </Popup>
              </Marker>
            ))}

            {/* Route Markers */}
            {routeSegments.map(seg => (
              <Marker 
                key={seg.id} 
                position={[seg.lat, seg.lng]}
                eventHandlers={{
                  click: () => handleMarkerClick(seg)
                }}
              >
                <Popup>
                  <div className="p-2 min-w-[200px] text-xs">
                    <h3 className="font-bold text-black mb-1">{seg.name}</h3>
                    <p className={`font-bold ${
                      seg.type === 'safe' ? 'text-green-600' : 
                      seg.type === 'construction' ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {seg.desc}
                    </p>
                    <p className="text-gray-600 mt-1">📏 Distance: {seg.distance} km</p>
                    <p className="text-gray-600">🚗 Suitable: {seg.suitable.join(', ')}</p>
                    <p className={`font-bold mt-1 ${seg.suitable.includes(vehicleType) ? 'text-green-600' : 'text-orange-600'}`}>
                      {seg.suitable.includes(vehicleType) ? '✓ Good for ' + vehicleType : '⚠️ Not ideal for ' + vehicleType}
                    </p>
                    {seg.type === 'danger' && (
                      <div className="mt-2 text-red-600 font-semibold border-t border-gray-200 pt-1">
                        🚨 AI: Multiple accidents. Avoid!
                      </div>
                    )}
                  </div>
                </Popup>
              </Marker>
            ))}

            <AICopilotOverlay onWarning={handleWarning} />
          </MapContainer>
        </div>

        {/* Right Side Panel */}
        {showPanel && (
          <div className="w-96 flex flex-col gap-4 overflow-y-auto">
            {/* Current Location Card */}
            <Card className="glass-card border-blue-500/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-transparent" />
              <CardHeader className="relative z-10 pb-2">
                <CardTitle className="text-white flex items-center gap-2 text-lg">
                  <MapPin className="w-5 h-5 text-blue-400" /> Current Location
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 relative z-10">
                <div className="p-3 bg-white/5 border border-blue-500/20 rounded-lg">
                  <p className="text-sm text-gray-400">Coordinates & Time</p>
                  <p className="text-white font-bold">12.9716° N, 77.5946° E</p>
                  <p className="text-xs text-gray-400 mt-1">📍 Bangalore Central | {getCurrentTime()}</p>
                  <p className={`text-xs font-bold mt-1 ${isNightMode ? 'text-orange-400' : 'text-green-400'}`}>{isNightMode ? '🌙 Night Mode' : '☀️ Day Mode'}</p>
                </div>
              </CardContent>
            </Card>

            {/* Vehicle Status Card */}
            <Card className="glass-card border-green-500/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-transparent" />
              <CardHeader className="relative z-10 pb-2">
                <CardTitle className="text-white flex items-center gap-2 text-lg">
                  <Users className="w-5 h-5 text-green-400" /> Vehicle: {vehicleType}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 relative z-10">
                {[
                  { icon: '⛽', label: 'Fuel', value: vehicleStatus.fuel + '%', color: 'text-yellow-400', bg: 'bg-yellow-500/10', lowThreshold: 50, isCritical: vehicleStatus.fuel < 50 },
                  { icon: '🔋', label: 'Battery', value: vehicleStatus.battery + '%', color: 'text-cyan-400', bg: 'bg-cyan-500/10', lowThreshold: 30, isCritical: vehicleStatus.battery < 30 },
                  { icon: '🌡️', label: 'Engine Temp', value: vehicleStatus.engineTemp + '°C', color: 'text-orange-400', bg: 'bg-orange-500/10', highThreshold: 85, isCritical: vehicleStatus.engineTemp > 85 },
                  { icon: '🛞', label: 'Tire Pressure', value: vehicleStatus.tirePressure, color: vehicleStatus.tirePressure === 'LOW' ? 'text-red-400' : 'text-green-400', bg: vehicleStatus.tirePressure === 'LOW' ? 'bg-red-500/10' : 'bg-green-500/10', isCritical: vehicleStatus.tirePressure === 'LOW' },
                ].map((stat, i) => (
                  <div key={i} className={`p-3 rounded-lg border ${stat.bg} ${stat.isCritical ? 'border-red-500/50' : 'border-white/10'}`}>
                    <div className="flex justify-between items-center">
                      <span className="text-2xl">{stat.icon}</span>
                      <div className="text-right">
                        <p className="text-xs text-gray-400">{stat.label}</p>
                        <p className={`font-bold ${stat.color}`}>{stat.value}</p>
                      </div>
                    </div>
                    {stat.isCritical && (
                      <p className="text-xs text-red-400 mt-2 font-semibold">⚠️ Critical</p>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Safety Alerts Card */}
            <Card className={`glass-card ${userGender === 'Women' && isNightMode ? 'border-red-500/50 bg-red-950/30' : 'border-red-500/30'} relative overflow-hidden`}>
              <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 to-transparent" />
              <CardHeader className="relative z-10 pb-2">
                <CardTitle className="text-white flex items-center gap-2 text-lg">
                  <AlertCircle className="w-5 h-5 text-red-400" /> Safety Alerts
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 relative z-10">
                {safetyAlerts.map(alert => (
                  <div key={alert.id} className={`p-3 rounded-lg border ${alert.severity === 'critical' ? 'bg-red-500/10 border-red-500/50' : 'bg-yellow-500/10 border-yellow-500/30'}`}>
                    <div className="flex gap-2">
                      <span className="text-lg">{alert.icon}</span>
                      <div className="flex-1">
                        <p className={`text-sm font-bold ${alert.severity === 'critical' ? 'text-red-400' : 'text-yellow-400'}`}>{alert.title}</p>
                        <p className="text-xs text-gray-300 mt-1">{alert.msg}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Accident Zones Card */}
            <Card className="glass-card border-yellow-500/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-600/10 to-transparent" />
              <CardHeader className="relative z-10 pb-2">
                <CardTitle className="text-white flex items-center gap-2 text-lg">
                  <AlertOctagon className="w-5 h-5 text-yellow-400" /> Accident Zones
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 relative z-10">
                {accidentData.map(zone => (
                  <div key={zone.id} className={`p-3 rounded-lg border ${isNightMode && zone.nightStatus === 'CRITICAL' ? 'bg-red-500/20 border-red-500/50' : 'bg-white/5 border-white/10'}`}>
                    <p className="text-sm font-bold text-white">{zone.road}</p>
                    <div className="text-xs text-gray-400 mt-1 space-y-1">
                      <p>📊 Accidents: {zone.accidents} | 🕳️ Potholes: {zone.potholes}</p>
                      <p>🕐 Dangerous: {zone.mostDangerous}</p>
                      <p className={isNightMode ? 'text-orange-400 font-bold' : ''}>{isNightMode ? '🌙 Night: ' + zone.nightStatus : '☀️ Day: ' + zone.dayStatus}</p>
                      <p>🚨 Crime: {zone.crime}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* AI Analysis Card - Advanced Features */}
            <Card className="glass-card border-purple-500/50 relative overflow-hidden bg-gradient-to-br from-purple-950/40 to-pink-950/20">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/15 to-pink-600/10" />
              <CardHeader className="relative z-10 pb-3">
                <CardTitle className="text-white flex items-center gap-2 text-lg">
                  <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" /> AI Analysis Hub
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 relative z-10">
                {/* AI Safety Score */}
                <div className="p-3 bg-white/5 border border-purple-500/30 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-purple-300 flex items-center gap-2">
                      <Eye className="w-4 h-4" /> Safety Score
                    </span>
                    <span className={`text-lg font-bold ${calculateAISafetyScore() >= 70 ? 'text-green-400' : calculateAISafetyScore() >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
                      {calculateAISafetyScore()}/100
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2">
                    <div 
                      className={`h-full rounded-full transition-all ${calculateAISafetyScore() >= 70 ? 'bg-green-500' : calculateAISafetyScore() >= 40 ? 'bg-yellow-500' : 'bg-red-500'}`}
                      style={{ width: `${calculateAISafetyScore()}%` }}
                    />
                  </div>
                </div>

                {/* AI Route Recommendation */}
                <div className="p-3 bg-white/5 border border-cyan-500/30 rounded-lg">
                  <p className="text-xs font-bold text-cyan-300 mb-2 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" /> AI Recommended Route
                  </p>
                  <p className="text-sm text-white font-semibold">{getAIRouteRecommendation().name}</p>
                  <p className="text-xs text-gray-400 mt-1">✓ Best for {vehicleType} • {getAIRouteRecommendation().distance}km</p>
                </div>

                {/* AI Driver Coaching */}
                <div className="p-3 bg-white/5 border border-blue-500/30 rounded-lg">
                  <p className="text-xs font-bold text-blue-300 mb-2 flex items-center gap-2">
                    <Brain className="w-4 h-4" /> AI Coach Tips
                  </p>
                  <ul className="text-xs text-gray-300 space-y-1">
                    {getAICoachingTips().slice(0, 2).map((tip, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="mt-0.5">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* AI Risk Prediction */}
                <div className="p-3 bg-white/5 border border-orange-500/30 rounded-lg">
                  <p className="text-xs font-bold text-orange-300 mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" /> Risk Prediction
                  </p>
                  {getAIRiskPrediction().map((risk, i) => (
                    <div key={i} className="text-xs mb-1">
                      <span className={`inline-block px-2 py-0.5 rounded text-white font-bold ${
                        risk.level === 'CRITICAL' ? 'bg-red-600/50' : 
                        risk.level === 'HIGH' ? 'bg-orange-600/50' : 
                        'bg-green-600/50'
                      }`}>
                        {risk.level}
                      </span>
                      <p className="text-gray-300 mt-1">{risk.msg}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Emergency Button */}
            <Button 
              onClick={handleEmergencyAlert}
              className="w-full h-12 bg-red-600 hover:bg-red-700 text-white text-base font-bold animate-pulse"
            >
              🚨 Emergency Services
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
