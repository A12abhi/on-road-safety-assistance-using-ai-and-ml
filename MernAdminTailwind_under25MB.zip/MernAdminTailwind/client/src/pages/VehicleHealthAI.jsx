import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Activity, CheckCircle, AlertTriangle, Info, Scan, BrainCircuit } from 'lucide-react';
import bgImage from '@assets/generated_images/futuristic_vehicle_scanning_hud.png';

export default function VehicleHealthAI() {
  const [result, setResult] = useState(null);
  const [scanning, setScanning] = useState(false);

  const handleAnalyze = (e) => {
    e.preventDefault();
    setScanning(true);
    setResult(null);

    // Fake AI Analysis Logic with delay
    setTimeout(() => {
      const formData = new FormData(e.target);
      const mileage = parseInt(formData.get('mileage'));
      const type = formData.get('type');

      let diagnosis = [];
      
      if (mileage > 50000) {
        diagnosis.push({ severity: 'medium', msg: "AI Detect: Brake pads likely worn (85% confidence). Inspect soon." });
      }
      if (mileage > 100000) {
        diagnosis.push({ severity: 'high', msg: "AI Alert: Timing belt failure probability high. Immediate replacement advised." });
      }
      if (type === 'Bike' && mileage > 20000) {
        diagnosis.push({ severity: 'medium', msg: "AI Pattern Match: Chain sprocket wear detected in similar models." });
      }
      
      // Default Insight
      diagnosis.push({ severity: 'low', msg: "AI Insight: Battery voltage pattern is normal based on vehicle age." });

      if (diagnosis.length === 1) {
         diagnosis.push({ severity: 'low', msg: "Overall System Health: Optimal. No anomalies detected." });
      }

      setResult(diagnosis);
      setScanning(false);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img src={bgImage} alt="HUD" className="w-full h-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background" />
        {scanning && (
          <div className="absolute inset-0 bg-cyan-500/10 z-10 animate-pulse pointer-events-none">
            <div className="w-full h-2 bg-cyan-500/50 blur-md absolute top-0 animate-[scan_2s_ease-in-out_infinite]" />
          </div>
        )}
      </div>

      <div className="relative z-20 pt-24 px-4 pb-12 max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-display font-bold text-white flex items-center justify-center gap-3">
            <BrainCircuit className="w-8 h-8 text-cyan-400" />
            AI Vehicle Health Scan
          </h1>
          <p className="text-gray-400">Predictive maintenance analysis using deep learning models.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="glass-card border-cyan-500/30 shadow-[0_0_20px_rgba(6,182,212,0.15)]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-500" />
                Vehicle Diagnostics Input
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAnalyze} className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-gray-300">Vehicle Type</Label>
                  <Select name="type" defaultValue="Car">
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Car">Car</SelectItem>
                      <SelectItem value="Bike">Bike</SelectItem>
                      <SelectItem value="Truck">Truck</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-gray-300">Model Year</Label>
                  <Input name="year" type="number" placeholder="2020" className="bg-white/5 border-white/10 text-white" required />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300">Current Mileage (km)</Label>
                  <Input name="mileage" type="number" placeholder="45000" className="bg-white/5 border-white/10 text-white" required />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300">Last Service Date</Label>
                  <Input name="service" type="date" className="bg-white/5 border-white/10 text-white" required />
                </div>

                <Button type="submit" className="w-full bg-cyan-600 hover:bg-cyan-700 text-white relative overflow-hidden group" disabled={scanning}>
                  {scanning && <div className="absolute inset-0 bg-white/20 animate-progress-bar" />}
                  {scanning ? (
                    <span className="flex items-center justify-center gap-2"><Scan className="w-4 h-4 animate-spin" /> Analyzing Telemetry...</span>
                  ) : (
                    <span className="flex items-center justify-center gap-2"><Scan className="w-4 h-4" /> Run AI Scan</span>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-6">
            {result ? (
              <Card className="glass-card border-cyan-500/30 animate-fade-in">
                <CardHeader>
                  <CardTitle className="text-white flex justify-between items-center">
                    <span>AI Analysis Report</span>
                    <span className="text-xs font-normal bg-cyan-500/20 text-cyan-300 px-2 py-1 rounded border border-cyan-500/30">
                      Confidence: 94%
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {result.map((item, i) => (
                    <div key={i} className={`p-4 rounded-lg border flex items-start gap-3 animate-slide-up ${
                      item.severity === 'high' ? 'bg-red-500/10 border-red-500/20' :
                      item.severity === 'medium' ? 'bg-yellow-500/10 border-yellow-500/20' :
                      'bg-cyan-500/10 border-cyan-500/20'
                    }`} style={{ animationDelay: `${i * 100}ms` }}>
                      {item.severity === 'high' ? <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" /> :
                       item.severity === 'medium' ? <Info className="w-5 h-5 text-yellow-500 shrink-0" /> :
                       <CheckCircle className="w-5 h-5 text-cyan-500 shrink-0" />}
                      <div>
                        <h4 className={`font-bold capitalize text-sm ${
                          item.severity === 'high' ? 'text-red-400' :
                          item.severity === 'medium' ? 'text-yellow-400' :
                          'text-cyan-400'
                        }`}>{item.severity} Priority Alert</h4>
                        <p className="text-sm text-gray-300 mt-1 leading-relaxed">{item.msg}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ) : scanning ? (
               <div className="h-full flex flex-col items-center justify-center text-cyan-400 glass-card border-cyan-500/20 p-8">
                  <Scan className="w-16 h-16 animate-pulse mb-4 text-cyan-500" />
                  <h3 className="text-xl font-display font-bold mb-2">AI Processing</h3>
                  <div className="space-y-1 text-center text-sm text-cyan-300/70">
                    <p>Analyzing historical patterns...</p>
                    <p>Checking component fatigue models...</p>
                    <p>Comparing with global fleet data...</p>
                  </div>
               </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-500 border border-dashed border-white/10 rounded-xl p-8 bg-black/20">
                <BrainCircuit className="w-12 h-12 mb-4 opacity-50" />
                <p>Enter vehicle details to initiate AI diagnostics</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
