import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Fuel, TrendingUp, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function FuelAssistantPage() {
  const { toast } = useToast();
  const [selectedBudget, setSelectedBudget] = useState(null);
  const [vehicleType, setVehicleType] = useState('car');

  const budgets = {
    car: [
      { amount: 100, mileage: 1500, kmPerRupee: 15, avgPrice: '₹100', efficiency: 'High' },
      { amount: 500, mileage: 7500, kmPerRupee: 15, avgPrice: '₹500', efficiency: 'High' },
      { amount: 2000, mileage: 30000, kmPerRupee: 15, avgPrice: '₹2000', efficiency: 'High' },
      { amount: 5000, mileage: 75000, kmPerRupee: 15, avgPrice: '₹5000', efficiency: 'High' }
    ],
    bike: [
      { amount: 100, mileage: 2500, kmPerRupee: 25, avgPrice: '₹100', efficiency: 'Very High' },
      { amount: 500, mileage: 12500, kmPerRupee: 25, avgPrice: '₹500', efficiency: 'Very High' },
      { amount: 2000, mileage: 50000, kmPerRupee: 25, avgPrice: '₹2000', efficiency: 'Very High' },
      { amount: 5000, mileage: 125000, kmPerRupee: 25, avgPrice: '₹5000', efficiency: 'Very High' }
    ],
    truck: [
      { amount: 100, mileage: 800, kmPerRupee: 8, avgPrice: '₹100', efficiency: 'Moderate' },
      { amount: 500, mileage: 4000, kmPerRupee: 8, avgPrice: '₹500', efficiency: 'Moderate' },
      { amount: 2000, mileage: 16000, kmPerRupee: 8, avgPrice: '₹2000', efficiency: 'Moderate' },
      { amount: 5000, mileage: 40000, kmPerRupee: 8, avgPrice: '₹5000', efficiency: 'Moderate' }
    ]
  };

  const handleSelectPlan = (plan) => {
    setSelectedBudget(plan);
    toast({
      title: "Budget Analysis Complete",
      description: `With ₹${plan.amount}, you can travel ${plan.mileage} km (${plan.kmPerRupee} km/rupee efficiency)`
    });
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-600/20 via-background to-orange-600/20" />
      </div>

      <div className="relative z-10 pt-24 px-4 pb-12 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent mb-2">
            💰 AI Fuel Budget Analyzer
          </h1>
          <p className="text-gray-400">Analyze how many kilometers you can travel with your budget</p>
        </div>

        {/* Vehicle Type Selection */}
        <Card className="glass-card border-amber-500/30 mb-12">
          <CardHeader>
            <CardTitle className="text-white">Select Your Vehicle Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 flex-wrap">
              {['car', 'bike', 'truck'].map((type) => (
                <Button
                  key={type}
                  onClick={() => { setVehicleType(type); setSelectedBudget(null); }}
                  className={`capitalize px-8 py-6 text-base font-bold transition-all ${vehicleType === type ? 'bg-amber-600 text-white ring-2 ring-amber-500' : 'bg-white/10 text-gray-400 hover:bg-white/20'}`}
                >
                  {type === 'car' ? '🚗' : type === 'bike' ? '🏍️' : '🚚'} {type}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Budget Analysis Cards */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-amber-400" /> Budget to Mileage Converter
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {budgets[vehicleType].map((plan, i) => (
              <Card key={i} className={`glass-card border-amber-500/30 hover:border-amber-500/60 transition-all cursor-pointer transform hover:scale-105 ${selectedBudget?.amount === plan.amount ? 'ring-2 ring-amber-500 bg-amber-900/20' : ''}`} onClick={() => handleSelectPlan(plan)}>
                <CardHeader>
                  <CardTitle className="text-3xl text-amber-400 font-bold">{plan.amount}</CardTitle>
                  <p className="text-gray-400 text-sm">Budget Amount</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                    <p className="text-gray-400 text-xs uppercase tracking-wider mb-1">Estimated Mileage</p>
                    <p className="text-3xl font-bold text-amber-300">{plan.mileage}</p>
                    <p className="text-xs text-gray-400 mt-2">kilometers you can travel</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 bg-white/5 rounded text-center">
                      <p className="text-xs text-gray-400">Efficiency</p>
                      <p className="text-lg font-bold text-green-400">{plan.kmPerRupee} km/₹</p>
                    </div>
                    <div className="p-2 bg-white/5 rounded text-center">
                      <p className="text-xs text-gray-400">Rating</p>
                      <p className="text-lg font-bold text-blue-400">{plan.efficiency}</p>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold h-10">
                    <Fuel className="mr-2 w-4 h-4" /> Analyze This Budget
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* AI Insights */}
        {selectedBudget && (
          <Card className="glass-card border-green-500/30 animate-fade-in">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-green-400" /> AI Insights & Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-3 gap-6">
              <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                <p className="text-green-400 font-bold mb-2">✓ Budget Allocation</p>
                <p className="text-gray-300 text-sm">Your ₹{selectedBudget.amount} budget is optimally allocated for {vehicleType} travel. You can comfortably travel {selectedBudget.mileage} km without worrying about fuel.</p>
              </div>
              <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <p className="text-blue-400 font-bold mb-2">💡 Efficiency Tips</p>
                <p className="text-gray-300 text-sm">
                  • Maintain steady speed (60-80 km/h)<br/>
                  • Check tire pressure regularly<br/>
                  • Avoid rapid acceleration<br/>
                  • Service every 5000 km
                </p>
              </div>
              <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
                <p className="text-purple-400 font-bold mb-2">🎯 Money Saving</p>
                <p className="text-gray-300 text-sm">At current rates, you save approximately ₹{Math.round(selectedBudget.amount * 0.08)} by maintaining optimal driving habits and vehicle maintenance.</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
