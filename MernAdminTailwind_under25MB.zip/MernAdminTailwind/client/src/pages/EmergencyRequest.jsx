import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MapPin, Navigation, AlertTriangle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const emergencySchema = z.object({
  type: z.string().min(1, "Select an emergency type"),
  location: z.string().min(3, "Location is required"),
  description: z.string().min(10, "Please provide more details"),
});

export default function EmergencyRequest() {
  const { toast } = useToast();
  const [isLocating, setIsLocating] = useState(false);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, setValue, formState: { errors }, reset } = useForm({
    resolver: zodResolver(emergencySchema)
  });

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('emergencyRequests') || '[]');
    setRequests(stored.reverse()); // Show newest first
    getLocation();
  }, []);

  const getLocation = () => {
    setIsLocating(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const loc = `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`;
          setValue('location', loc);
          setIsLocating(false);
          toast({ title: "Location Found", description: "Coordinates updated successfully." });
        },
        (error) => {
          console.error(error);
          setIsLocating(false);
          toast({ title: "Location Error", description: "Could not fetch GPS. Please enter manually.", variant: "destructive" });
        }
      );
    } else {
      setIsLocating(false);
      toast({ title: "Not Supported", description: "Geolocation is not supported by this browser.", variant: "destructive" });
    }
  };

  const onSubmit = (data) => {
    setLoading(true);
    
    const newRequest = {
      id: Date.now().toString(),
      ...data,
      timestamp: new Date().toISOString(),
      status: 'Pending',
      assignedMechanic: null
    };

    const updatedRequests = [...requests, newRequest]; // Add to top of list (local state) but stored list needs to be appended correctly
    
    // Update LocalStorage
    const stored = JSON.parse(localStorage.getItem('emergencyRequests') || '[]');
    stored.push(newRequest);
    localStorage.setItem('emergencyRequests', JSON.stringify(stored));

    setTimeout(() => {
      setRequests([newRequest, ...requests]);
      setLoading(false);
      reset();
      toast({ title: "Request Sent!", description: "Help is on the way." });
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-3xl mx-auto space-y-8">
      
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-display font-bold text-white">Emergency Assistance</h1>
        <p className="text-gray-400">Report a breakdown or issue. We'll dispatch help immediately.</p>
      </div>

      <Card className="glass-card border-red-500/30 shadow-[0_0_30px_rgba(220,38,38,0.15)]">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-500/20 rounded-full">
              <AlertTriangle className="w-6 h-6 text-red-500" />
            </div>
            <div>
              <CardTitle className="text-white">New Request</CardTitle>
              <CardDescription>Fill in the details below</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            
            <div className="space-y-2">
              <Label className="text-gray-300">Emergency Type</Label>
              <Select onValueChange={(val) => setValue('type', val)}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue placeholder="Select issue type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Breakdown">Car Breakdown</SelectItem>
                  <SelectItem value="Flat Tyre">Flat Tyre</SelectItem>
                  <SelectItem value="Fuel">Out of Fuel</SelectItem>
                  <SelectItem value="Engine">Engine Failure</SelectItem>
                  <SelectItem value="Accident">Accident / Collision</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
              {errors.type && <p className="text-xs text-red-400">{errors.type.message}</p>}
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Current Location</Label>
              <div className="flex gap-2">
                <Input 
                  {...register('location')}
                  placeholder="Fetching location..." 
                  className="bg-white/5 border-white/10 text-white"
                />
                <Button type="button" variant="outline" onClick={getLocation} disabled={isLocating} className="bg-white/5 border-white/10 text-white hover:bg-white/10">
                  {isLocating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4" />}
                </Button>
              </div>
              {errors.location && <p className="text-xs text-red-400">{errors.location.message}</p>}
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Description</Label>
              <Textarea 
                {...register('description')}
                placeholder="Describe the problem in detail (e.g., smoke from engine, car won't start...)" 
                className="bg-white/5 border-white/10 text-white min-h-[100px]"
              />
              {errors.description && <p className="text-xs text-red-400">{errors.description.message}</p>}
            </div>

            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white text-lg py-6" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : "SEND SOS REQUEST"}
            </Button>

          </form>
        </CardContent>
      </Card>

      {/* Recent Requests List */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-white">Recent Requests</h3>
        {requests.length > 0 ? (
          requests.slice(0, 3).map((req) => (
            <div key={req.id} className="bg-card/50 border border-white/10 p-4 rounded-lg flex justify-between items-center">
              <div>
                <p className="font-medium text-white">{req.type}</p>
                <p className="text-sm text-gray-400 truncate max-w-[200px]">{req.description}</p>
                <p className="text-xs text-gray-500 mt-1">{new Date(req.timestamp).toLocaleDateString()}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                req.status === 'Resolved' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
              }`}>
                {req.status}
              </span>
            </div>
          ))
        ) : (
          <p className="text-gray-500 text-center py-4">No recent requests.</p>
        )}
      </div>
    </div>
  );
}
