import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { History, MapPin, Wrench, Clock } from 'lucide-react';

export default function HistoryPage() {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const reqs = JSON.parse(localStorage.getItem('emergencyRequests') || '[]');
    setHistory(reqs.reverse());
  }, []);

  return (
    <div className="min-h-screen bg-background pt-24 px-4 pb-12 max-w-5xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-gray-800 rounded-full">
          <History className="w-8 h-8 text-gray-400" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Service History</h1>
          <p className="text-gray-400">Track all your past requests and mechanic visits.</p>
        </div>
      </div>

      {/* Insights Banner */}
      <div className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border border-white/10 rounded-xl p-6 mb-8 animate-fade-in">
        <h3 className="text-lg font-bold text-white mb-2">Smart Insights</h3>
        <p className="text-gray-300 text-sm">
          based on your history, 40% of your issues are related to "Tyres". 
          We recommend checking your tyre pressure every 2 weeks.
        </p>
      </div>

      <div className="space-y-4">
        {history.length > 0 ? (
          history.map((item) => (
            <Card key={item.id} className="glass-card border-white/5 hover:bg-white/5 transition-colors">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold text-white">{item.type}</h3>
                      <Badge variant={item.status === 'Resolved' ? 'success' : 'warning'} className={
                        item.status === 'Resolved' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
                      }>
                        {item.status}
                      </Badge>
                    </div>
                    <p className="text-gray-400 text-sm flex items-center gap-2">
                      <MapPin className="w-3 h-3" /> {item.location}
                    </p>
                    <p className="text-gray-400 text-sm flex items-center gap-2">
                      <Clock className="w-3 h-3" /> {new Date(item.timestamp).toLocaleString()}
                    </p>
                  </div>

                  {item.assignedMechanic && (
                    <div className="bg-white/5 p-3 rounded-lg border border-white/10 min-w-[200px]">
                      <p className="text-xs text-gray-500 uppercase">Assigned Mechanic</p>
                      <div className="flex items-center gap-2 mt-1 text-white font-medium">
                        <Wrench className="w-4 h-4 text-primary" />
                        {item.assignedMechanic}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="text-center py-12 text-gray-500 border border-dashed border-white/10 rounded-xl">
            No history available yet.
          </div>
        )}
      </div>
    </div>
  );
}
